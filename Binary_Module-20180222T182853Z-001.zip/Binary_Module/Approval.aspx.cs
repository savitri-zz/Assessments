﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Approval : System.Web.UI.Page
{
    GetData clsGetData = new GetData();
    CreateNewUser clsCreate = new CreateNewUser();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        if (txtVerifyMblNo.Text.ToString() == "")
        {
            lblError.Text = "Please Enter Mobile Number";
            lblError.Visible = true;
            return;
        }
        
        DataTable chkMobile = new DataTable();
        chkMobile = clsGetData.GetRawMembersDetails("MOBILENO", txtVerifyMblNo.Text.ToString());
        if (chkMobile.Rows.Count <= 0)
        {
            lblError.Text = "Mobile Number does not Exists";
            lblError.Visible = true;
            return;
        }
        else
        {
            string mobileno = chkMobile.Rows[0]["MOBILENO"].ToString();
            DataTable chkUser = new DataTable();
            chkUser = clsGetData.GetActiveMembersDetails("MOBILENO", mobileno);
            if (chkUser.Rows.Count > 0)
            {
                lblError.Text = "Mobile Number is Already Verified";
                lblError.Visible = true;
                return;
            }
            else
            {
               
                string userid = chkMobile.Rows[0]["USERID"].ToString();
               
                clsCreate.VerifyUser(userid);
                txtVerifyMblNo.Text = "";

            }


        }

    }
}