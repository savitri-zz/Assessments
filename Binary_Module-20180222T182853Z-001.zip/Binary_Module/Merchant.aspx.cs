﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Merchant : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreateAccount_Click(object sender, EventArgs e)
    {
        GetData proxy = new GetData();
        string s = proxy.insertMerchant(spnName.InnerText, txtBusinessName.Text.ToUpper(), txtConnectionString.Text.ToUpper());
        lblResponse.Text = s.ToString();
    }
}