﻿<%@ WebService Language="C#" CodeBehind="~/App_Code/wsDailyGrowthService.cs" Class="wsDailyGrowthService" %>
