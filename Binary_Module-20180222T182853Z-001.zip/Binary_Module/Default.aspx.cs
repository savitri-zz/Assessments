﻿using System;
using ServiceReference1;
using System.Text;
using ServiceReference4;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        CalculatorClient proxy = new CalculatorClient();
        double addResult = proxy.AddNumbers(9, 3);
        lblAddResult.Text = "Result of Add Operation + " +addResult.ToString();

        double subResult = proxy.SubstractNumbers(9, 3);
        lblSubResult.Text = "Result of Substract Operation - "+subResult.ToString();

        double mulResult = proxy.MultiplyNumbers(9, 3);
        lblMulResult.Text = "Result of Multiply Operation * "+ mulResult.ToString();

        double divResult = proxy.MultiplyNumbers(9, 3);
        lblDivResult.Text = "Result of Division Operation / "+ divResult.ToString();

      //  ss1Client proxy1 = new ss1Client();

        //double addResult1 = proxy1.AddNumbers(9, 3);
        //lblAddResult.Text = "Result of Add Operation + " + addResult1.ToString();

    }
}
