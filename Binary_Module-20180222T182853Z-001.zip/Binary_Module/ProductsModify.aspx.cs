﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ProductsModify : System.Web.UI.Page
{
    GetData clsGetData = new GetData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //GetProductsDetailsByID
            string sProdId = "";

            if (Request.QueryString["pid"] != null)
            {
                sProdId = Request.QueryString["pid"].ToString();

                
                DataTable dt = new DataTable();

                dt = clsGetData.GetProductsDetailsByID(sProdId);

                if (dt.Rows.Count > 0)
                {
                    txtProdID.Text = dt.Rows[0]["PRODUCT_ID"].ToString();
                    txtProdID.ReadOnly = true;
                    txtProdDesc.Text = dt.Rows[0]["PRODUCT_DESCRIPTION"].ToString();
                    ddlCalcMethod.Text = dt.Rows[0]["BONUS_CALCULATION_METHODOLOGY"].ToString();
                    txtCalcPeriod.Text = dt.Rows[0]["BONUS_CONSIDERATION_PERIOD"].ToString();
                    txtBonusAmount.Text = dt.Rows[0]["BONUS_AMOUNT"].ToString();
                    txtSposorAmt.Text = dt.Rows[0]["SPONSOR_BONUS_AMOUNT"].ToString();
                    ddlConsiderLR.Text =  (dt.Rows[0]["CONSIDER_REFERAL_LR_FOR_BINARY"].ToString()  == "1" ? "Yes":"No") ;
                    txtBinaryAmt.Text = dt.Rows[0]["BINARY_BONUS_AMOUNT"].ToString();
                    txtCeilingAmt.Text = dt.Rows[0]["BINARY_CEILING_AMOUNT"].ToString();
                }

            }


        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        clsGetData.ProductSave(txtProdID.Text, txtProdDesc.Text, ddlCalcMethod.Text, Convert.ToInt32(txtCalcPeriod.Text),
            Convert.ToDouble(txtBonusAmount.Text), Convert.ToDouble(txtSposorAmt.Text), (ddlConsiderLR.Text == "yes" ? true : false),
            Convert.ToDouble(txtBinaryAmt.Text), Convert.ToDouble(txtCeilingAmt.Text));

        Response.Redirect("~/products.aspx");

    }
}