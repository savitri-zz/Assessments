﻿using System.ServiceModel;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICalculator" in both code and config file together.
[ServiceContract]
public interface ICalculator
{
	[OperationContract]
	void DoWork();

    [OperationContract]
    double AddNumbers(double number1, double number2);
    [OperationContract]
    double SubstractNumbers(double number1, double number2);
    [OperationContract]
    double MultiplyNumbers(double number1, double number2);
    [OperationContract]
    double DivisionNumbers(double number1, double number2);
    [OperationContract]
    bool CheckUserAuthentication(string sLoginID, string sPassword);
    [OperationContract]
    int CreateUser(string sProdID, string txtmblno, string txtFullName, string txtEmailId, string sPassword, string txtRfrlMblNo, string option);
}
