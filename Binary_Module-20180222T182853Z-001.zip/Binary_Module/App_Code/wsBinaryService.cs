﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.ServiceModel.Web;
using System.Globalization;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for wsBinaryService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class wsBinaryService : System.Web.Services.WebService
{

    public wsBinaryService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    //1/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////1//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getUserLoginDetails(string mobileno, string password)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "SELECT DBO.FN_CHECKING_LOGIN('" + mobileno + "','" + password + "') CHK";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@LOGIN_ID", mobileno);
            command.Parameters.AddWithValue("@PASSWORD", password);

            command.Parameters.Add("@RET_VAL", SqlDbType.VarChar, 100);
            command.Parameters["@RET_VAL"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.Text;
            command.Connection.Open();

            string retunvalue = "";
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                if (dr.Read())
                {
                    retunvalue = dr.GetBoolean(0).ToString();
                }
                else
                {
                    retunvalue = "-1"; // some value to indicate a missing record
                    // or throw an exception
                }

                string status = string.Empty;

                if (retunvalue.ToUpper().Trim().Contains("TRUE"))
                {
                    string[] result = retunvalue.ToUpper().Split(';');
                    status = result[0].ToString();
                }
                else
                {
                    status = retunvalue;
                }
                ClientUser response = new ClientUser
                {
                    STATUS = status
                };

                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }


        }

    }

    //1/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////1//


    //2/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////2//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string chkUserAuth(string mobileno, string password)
    {
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_CHECK_AUTHENTICATION_v2";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Connection.Open();

            command.Parameters.AddWithValue("@LOGIN_ID", mobileno);
            command.Parameters.AddWithValue("@PASSWORD", password);

            command.CommandType = CommandType.StoredProcedure;



            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 1000);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;

            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else
                {
                    string[] result = retunvalue.ToUpper().Split(':');
                    if (result.Length > 0)
                    {
                        sb.Append("{");
                        sb.Append('"');
                        sb.AppendFormat(result[0].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[1].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[2].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[3].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[4].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[5].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[6].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[7].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[8].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[9].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[10].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[11].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[12].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[13].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[14].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[15].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[16].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[17].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[18].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[19].ToString());
                        sb.Append('"');
                        sb.Append("},");
                    }
                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }
        }
    }


    //2/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////2//


    //3/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////3//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getPendingRegistrations(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_PENDING_REGISTRATIONS";
            SqlCommand command = new SqlCommand(commandNAME, connection);



            command.CommandType = CommandType.StoredProcedure;


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                // var DB = new SqlCommand();
                command.Connection = con;
                command.CommandText = commandNAME;
                var data = command.ExecuteReader();
                string outputJson = string.Empty;

                return outputJson = WriteReaderToJSON(sb, data);


            }
        }
    }
    //[WebMethod]
    //// [ScriptMethod(UseHttpGet = true)]
    //[WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    //public string getPendingRegistrations()
    //{
    //    //SqlTransaction Transaction = null;
    //    var sb = new StringBuilder();
    //    string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

    //    using (SqlConnection connection = new SqlConnection(connectionString))
    //    {
    //        string commandNAME = "USP_GET_PENDING_REGISTRATIONS";
    //        SqlCommand command = new SqlCommand(commandNAME, connection);
    //        command.CommandType = CommandType.StoredProcedure;


    //        try
    //        {
    //            connection.Open();
    //        }
    //        catch (Exception e)
    //        {
    //            Console.WriteLine(e.ToString());
    //        }
    //        // var DB = new SqlCommand();
    //        command.Connection = connection;
    //        command.CommandText = commandNAME;
    //        var data = command.ExecuteReader();
    //        string outputJson = string.Empty;

    //        return outputJson = WriteReaderToJSON(sb, data);


    //    }
    //}
   

    //3/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////3//



    //4/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////4//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]
    public string getPendingRequesedAmounts(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_PENDING_REQUESTED_AMOUNTS";
            SqlCommand command = new SqlCommand(commandNAME, connection);



            command.CommandType = CommandType.StoredProcedure;


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                // var DB = new SqlCommand();
                command.Connection = con;
                command.CommandText = commandNAME;
                var data = command.ExecuteReader();
                string outputJson = string.Empty;

                return outputJson = WriteReaderToJSON(sb, data);


            }
        }
    }
    //public string getPendingRequesedAmounts()
    //{
    //    //SqlTransaction Transaction = null;
    //    var sb = new StringBuilder();
    //    string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

    //    using (SqlConnection connection = new SqlConnection(connectionString))
    //    {
    //        string commandNAME = "USP_GET_PENDING_REQUESTED_AMOUNTS";
    //        SqlCommand command = new SqlCommand(commandNAME, connection);
    //        command.CommandType = CommandType.StoredProcedure;


    //        try
    //        {
    //            connection.Open();
    //        }
    //        catch (Exception e)
    //        {
    //            Console.WriteLine(e.ToString());
    //        }
    //        // var DB = new SqlCommand();
    //        command.Connection = connection;
    //        command.CommandText = commandNAME;
    //        var data = command.ExecuteReader();
    //        string outputJson = string.Empty;

    //        return outputJson = WriteReaderToJSON(sb, data);


    //    }
       

    //}


    //4/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////4//




    //5/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////5//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]
    public string createNewUser(string sProdID, string txtmblno, string txtFullName, string txtEmailId, string sLoginId, string sPassword, string txtRfrlMblNo, string option)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_CREATE_USER_RAW_DATA";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Parameters.AddWithValue("@PRODUCT_ID", sProdID);
            command.Parameters.AddWithValue("@MOBILENO", txtmblno);
            command.Parameters.AddWithValue("@NAME", txtFullName);
            command.Parameters.AddWithValue("@EMAILID", txtEmailId);
            command.Parameters.AddWithValue("@LOGIN_ID", sLoginId);
            command.Parameters.AddWithValue("@PWD", sPassword);
            command.Parameters.AddWithValue("@REFERAL_MOBILE", txtRfrlMblNo);
            command.Parameters.AddWithValue("@PLACEMENT", option);

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();


            command.Parameters.Add("@RETURN_STR", SqlDbType.VarChar, 100);
            command.Parameters["@RETURN_STR"].Direction = ParameterDirection.Output;

            string retunvalue = "";
            string outputJson = string.Empty;
            using (
                SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RETURN_STR"].Value;

                string status = string.Empty;

                if (retunvalue == "")
                {
                    return "REGISTRATION FAILED";
                }
                else
                {
                    status = retunvalue;
                }


                ClientUser response = new ClientUser
                {
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }

        }

    }

    //5/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////5//




    //6/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////6//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getUserRegistrationTree(string REFERALID)
    {


        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "SELECT * FROM dbo.FN_USER_REGISTRATION_TREE('" + REFERALID + "') CHK";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@PRODUCT_ID", REFERALID);
            command.Parameters["@PRODUCT_ID"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@USERID", REFERALID);
            command.Parameters["@USERID"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@NAME", REFERALID);
            command.Parameters["@NAME"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@MOBILENO", REFERALID);
            command.Parameters["@MOBILENO"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@EMAILID", REFERALID);
            command.Parameters["@EMAILID"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@REFERAL_ID", REFERALID);
            command.Parameters["@REFERAL_ID"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@PLACEMENT_ID", REFERALID);
            command.Parameters["@PLACEMENT_ID"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@ACTUAL_PLACEMENT", REFERALID);
            command.Parameters["@ACTUAL_PLACEMENT"].Direction = ParameterDirection.Output;
            command.Parameters.Add("@PLACEMENT_TO_NODE", SqlDbType.VarChar, 100);
            command.Parameters["@PLACEMENT_TO_NODE"].Direction = ParameterDirection.Output;
            command.Parameters.AddWithValue("@APPROVED_DATE", REFERALID);
            command.Parameters["@APPROVED_DATE"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.Text;
           // command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }


        ////SqlTransaction Transaction = null;
        //var sb = new StringBuilder();
        //string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        //using (SqlConnection connection = new SqlConnection(connectionString))
        //{
        //    string commandNAME = "SELECT * FROM dbo.FN_USER_REGISTRATION_TREE('" + REFERALID + "') CHK";
        //    SqlCommand command = new SqlCommand(commandNAME, connection);

        //    command.Parameters.AddWithValue("@PRODUCT_ID", REFERALID);
        //    command.Parameters["@PRODUCT_ID"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@USERID", REFERALID);
        //    command.Parameters["@USERID"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@NAME", REFERALID);
        //    command.Parameters["@NAME"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@MOBILENO", REFERALID);
        //    command.Parameters["@MOBILENO"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@EMAILID", REFERALID);
        //    command.Parameters["@EMAILID"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@REFERAL_ID", REFERALID);
        //    command.Parameters["@REFERAL_ID"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@PLACEMENT_ID", REFERALID);
        //    command.Parameters["@PLACEMENT_ID"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@ACTUAL_PLACEMENT", REFERALID);
        //    command.Parameters["@ACTUAL_PLACEMENT"].Direction = ParameterDirection.Output;
        //    command.Parameters.Add("@PLACEMENT_TO_NODE", SqlDbType.VarChar, 100);
        //    command.Parameters["@PLACEMENT_TO_NODE"].Direction = ParameterDirection.Output;
        //    command.Parameters.AddWithValue("@APPROVED_DATE", REFERALID);
        //    command.Parameters["@APPROVED_DATE"].Direction = ParameterDirection.Output;
        //    command.CommandType = CommandType.Text;
        //    command.Connection.Open();


        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            con.Open();
        //        }
        //        catch (Exception e)
        //        {
        //            Console.WriteLine(e.ToString());
        //        }
        //        var DB = new SqlCommand();
        //        DB.Connection = con;
        //        DB.CommandText = commandNAME;
        //        var data = DB.ExecuteReader();
        //        string outputJson = string.Empty;
        //        while (data.Read())
        //        {
        //            ClientUser response = new ClientUser
        //            {
        //                PRODUCT_ID = data["PRODUCT_ID"].ToString(),
        //            };
        //            sb.Append("{");
        //            sb.AppendFormat(@"""0"": ""{0}""", data["PRODUCT_ID"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""1"": ""{0}""", data["USERID"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""2"": ""{0}""", data["NAME"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""3"": ""{0}""", data["MOBILENO"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""4"": ""{0}""", data["EMAILID"]);
        //            sb.Append("},");
        //            sb.AppendFormat(@"""5"": ""{0}""", data["REFERAL_ID"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""6"": ""{0}""", data["PLACEMENT_ID"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""7"": ""{0}""", data["ACTUAL_PLACEMENT"]);
        //            sb.Append(",");
        //            sb.AppendFormat(@"""8"": ""{0}""", data["PLACEMENT_TO_NODE"]);
        //            sb.Append("},");
        //            sb.AppendFormat(@"""9"": ""{0}""", data["APPROVED_DATE"]);
        //            sb.Append("},");
        //        }
        //        outputJson = sb.Remove(sb.Length - 1, 1).ToString();
        //        sb.Clear();
        //        return outputJson;
        //    }
        //}
    }

    //6/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////6//


    //7////////////////////Start/////////////////////////Savitri/////////////////////////////Start///////////////7//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getUserSpecificValues(string userid, string criteria)
    {
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "SELECT DBO.FN_GET_USER_SPECIFIC_VALUES('" + userid + "','" + criteria + "') CHK";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@CRITERIA", criteria);

            command.Parameters.Add("@RET_VAL", SqlDbType.VarChar, 100);
            command.Parameters["@RET_VAL"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.Text;
            command.Connection.Open();
            string retunvalue = string.Empty;
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                if (dr.Read())
                {
                    retunvalue = dr.GetSqlValue(0).ToString();
                }
                else
                {
                    retunvalue = "0";
                }

                string status = string.Empty;

                if (retunvalue.ToUpper().Trim().Contains("0"))
                {
                    string[] result = retunvalue.ToUpper().Split(';');
                    status = result[0].ToString();
                }
                else
                {
                    status = retunvalue;
                }
                ClientUser response = new ClientUser
                {
                    STATUS = status
                };

                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }
        }

    }

    //7/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////7//



    //8////////////////////Start/////////////////////////Savitri/////////////////////////////Start///////////////8//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getPendingHelpData(string userid, string criteria)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_PENDING_HELP_DATA";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@CRITERIA", criteria);

            //command.Parameters.Add("@RET_VAL", SqlDbType.VarChar, 100);
            //command.Parameters["@RET_VAL"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                // var DB = new SqlCommand();
                command.Connection = con;
                command.CommandText = commandNAME;
                var data = command.ExecuteReader();
                string outputJson = string.Empty;

                return outputJson = WriteReaderToJSON(sb, data);


            }

            //using (SqlDataReader dr = command.ExecuteReader())
            //{
            //    if (dr.Read())
            //    {
            //        retunvalue = dr.GetSqlValue(0).ToString();
            //    }
            //    else
            //    {
            //        retunvalue = "0";
            //    }

            //    string status = string.Empty;

            //    if (retunvalue.ToUpper().Trim().Contains("0"))
            //    {
            //        string[] result = retunvalue.ToUpper().Split(';');
            //        status = result[0].ToString();
            //    }
            //    else
            //    {
            //        status = retunvalue;
            //    }
            //    ClientUser response = new ClientUser
            //    {
            //        STATUS = status
            //    };

            //    var javaScriptSerializer = new JavaScriptSerializer();
            //    outputJson = javaScriptSerializer.Serialize(response);

            //    return outputJson;
            //}
        }

    }

    //8/////////////////////end/////////////////////////Savitri/////////////////////////////end////////////////8//


    //9/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////9//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getGeneologtReport(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_GENEOLOGY_REPORT";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@USERID", userid);


            command.CommandType = CommandType.StoredProcedure;


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                // var DB = new SqlCommand();
                command.Connection = con;
                command.CommandText = commandNAME;
                var data = command.ExecuteReader();
                string outputJson = string.Empty;

                return outputJson = WriteReaderToJSON(sb, data);

               
            }
        }
    }
    private string WriteReaderToJSON(StringBuilder sb, IDataReader reader)
    {

        if (reader == null || reader.FieldCount == 0)
        {
            sb.Append("null");
            return "";
        }

        int rowCount = 0;

        sb.Append(@"[");

        while (reader.Read())
        {
            sb.Append("{");

            for (int i = 0; i < reader.FieldCount; i++)
            {
                sb.Append("\"" + reader.GetName(i) + "\":");
                sb.Append("\"" + reader[i] + "\"");
                //; int j=(reader.FieldCount) – 1;

                sb.Append(i == (reader.FieldCount) - 1 ? " " : ",");

            }

            sb.Append("},");

            rowCount++;
        }

        if (rowCount > 0)
        {
            int index = sb.ToString().LastIndexOf(",");
            sb.Remove(index, 1);
        }

        sb.Append("]");

        return sb.ToString();

    }

    private string WriteToJSON(StringBuilder sb, IDataReader reader)
    {

        if (reader == null || reader.FieldCount == 0)
        {
            sb.Append("null");
            return "";
        }

        int rowCount = 0;

        sb.Append(@"{");

        while (reader.Read())
        {
            sb.Append("{");

            for (int i = 0; i < reader.FieldCount; i++)
            {
                sb.Append("\"" + reader.GetName(i) + "\":");
                sb.Append("\"" + reader[i] + "\"");
                //; int j=(reader.FieldCount) – 1;

                sb.Append(i == (reader.FieldCount) - 1 ? " " : ",");

            }

            sb.Append("},");

            rowCount++;
        }

        if (rowCount > 0)
        {
            int index = sb.ToString().LastIndexOf(",");
            sb.Remove(index, 1);
        }

        sb.Append("}");

        return sb.ToString();

    }
    //9/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////9//


    //10/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////10//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string updatePassword(string userid, string password)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_UPDATE_PASSWORD";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@PWD", password);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 100);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();            
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //10/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////10//


    //11/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////11//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string createRequestMapping(string requestuserid, string assignuserid, string criteria)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_CREATE_REQUEST_MAPPING";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@REQUESTED_USERID", requestuserid);
            command.Parameters.AddWithValue("@ASSIGNED_USERID", assignuserid);
            command.Parameters.AddWithValue("@CRITERIA", criteria);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 100);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //11/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////11//

    //12/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////12//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getTransactionReport(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_TRANSACTIONS_REPORT";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@USERID", userid);


            command.CommandType = CommandType.StoredProcedure;


                try
                {
                    connection.Open();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                // var DB = new SqlCommand();
                command.Connection = connection;
                command.CommandText = commandNAME;
                var data = command.ExecuteReader();
                string outputJson = string.Empty;

                return outputJson = WriteReaderToJSON(sb, data);


        }
    }


    //12/////////////////////End/////////////////////////Savitri/////////////////////////////End////////////////12//


    //13/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////13//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string updateUserBankDetails(string userid, string bankname, string branchname, string accountno, string acholdername, string accounttype, string ifsccode)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "DBO.USP_UPDATE_USER_BANK_DETAILS";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@BANK_NAME", bankname);
            command.Parameters.AddWithValue("@BRANCH_NAME", branchname);
            command.Parameters.AddWithValue("@ACCOUNT_NO", accountno);
            command.Parameters.AddWithValue("@ACCOUNT_HOLDER_NAME", acholdername);
            command.Parameters.AddWithValue("@ACCOUNT_TYPE", accounttype);
            command.Parameters.AddWithValue("@IFSC_CODE", ifsccode);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 100);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //13/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////13//



    //14/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////14//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string userProfileData(string userid)
    {
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_USER_PROFILE_DATA";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Connection.Open();

            command.Parameters.AddWithValue("@USERID", userid);

            command.CommandType = CommandType.StoredProcedure;



            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 1000);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;

            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else
                {//@RET_STR = 'PRODUCT_ID:' + @PRODUCT_ID + ':USERID:' + @USERID + ':NAME:' + @NAME + ':MOBILENO:' + @MOBILENO 
		//+ ':EMAILID:' + @EMAILID + ':REFERAL_ID:' + @REFERAL_ID + ':REFERAL_MOBILE:' + @REFERAL_MOBILE + ':PLACEMENT:' + @PLACEMENT
		// ':CREATED_DT:' + CONVERT(VARCHAR(30), @CREATED_DT, 106) + ':STATUS:TRUE'
                    string[] result = retunvalue.ToUpper().Split(':');
                    if (result.Length > 0)
                    {
                        sb.Append("{");
                        sb.Append('"');
                        sb.AppendFormat(result[0].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[1].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[2].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[3].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[4].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[5].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[6].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[7].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[8].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[9].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[10].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[11].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[12].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[13].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[14].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[15].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[16].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[17].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[18].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[19].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[20].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[21].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[22].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[23].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[24].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[25].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[26].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[27].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[28].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[29].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[30].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[31].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[32].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[33].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[34].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[35].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[36].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[37].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[38].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[39].ToString());
                        sb.Append('"');
                        sb.Append("},");
                    }
                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }
        }
    }


    //14/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////14//



    //15/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////15//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    //public string chkAdminAuth(string mobileno, string password, string MName, string ApiKey)
    public string chkAdminAuth(string mobileno, string password)
    {
        string s = "";
        var sb = new StringBuilder();
        string outputJson = string.Empty;
        //try{
        //     s= ApiAuthentication(MName, ApiKey);
        //}
        //catch(Exception e)
        //{
        //}
        //if (s == "SUCCESS")
        //{
            string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string commandNAME = "USP_CHECKING_LOGIN";
                SqlCommand command = new SqlCommand(commandNAME, connection);
                command.Connection.Open();

                command.Parameters.AddWithValue("@LOGIN_ID", mobileno);
                command.Parameters.AddWithValue("@PASSWORD", password);

                command.CommandType = CommandType.StoredProcedure;



                command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 1000);
                command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;

                string status = string.Empty;
                string retunvalue = string.Empty;
                var javaScriptSerializer = new JavaScriptSerializer();

                using (SqlDataReader dr = command.ExecuteReader())
                {
                    retunvalue = (string)command.Parameters["@RET_STR"].Value;

                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("}");
                    outputJson = sb.ToString();
                    sb.Clear();

                }
            }
        //}
        //else
        //{
        //    sb.Append("{");
        //    sb.Append('"');
        //    sb.AppendFormat("STATUS");
        //    sb.Append('"');
        //    sb.Append(':');
        //    sb.Append('"');
        //    sb.AppendFormat("Authentication Failed");
        //    sb.Append('"');
        //    sb.Append("}");
        //    outputJson = sb.ToString();
        //    sb.Clear();
        //}

        return outputJson;

        
    }


    //15/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////15//

    //16/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////16//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getAllProducts(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_ALL_PRODUCTS";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }
    }


    //16/////////////////////End/////////////////////////Savitri/////////////////////////////End////////////////16//





    //17/////////////////////end/////////////////////////Naidu/////////////////////////////end/////////////////17//Send SMS//


    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string sendSMS(string mobileno, string message)
    {
        SMSCAPI obj = new SMSCAPI();
        string smsStatus = obj.SendSMS("helpme2helpyou", "56491427", "91" + mobileno, message, "N", "Y");
        string outputJson = string.Empty;
        string status = string.Empty;
        ClientUser response1 = new ClientUser
        {
            STATUS = status
        };
        var javaScriptSerializer = new JavaScriptSerializer();
        outputJson = javaScriptSerializer.Serialize(response1);
        return outputJson;
    }
    //17/////////////////////Start/////////////////////////Naidu/////////////////////////////Start////////////////17//


    //18/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////18//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string createReimburseRequest(string userid, string requestedamount)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_CREATE_REIMBURSE_REQUEST";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Connection.Open();
            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@REQUESTED_AMOUNT", requestedamount);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 1000);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;


            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;

                sb.Append("{");
                sb.Append('"');
                sb.AppendFormat("STATUS");
                sb.Append('"');
                sb.Append(':');
                sb.Append('"');
                sb.AppendFormat(retunvalue);
                sb.Append('"');
                sb.Append("}");
                outputJson = sb.ToString();
                sb.Clear();

                return outputJson;
            }
        }
    }


    //18/////////////////////End/////////////////////////Savitri/////////////////////////////End////////////////18//


    //19/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////19//
   
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getRecordsByUserId(string userid, string criteria)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_RECORDS_BY_USERID ";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@CRITERIA", criteria);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }

    }


    //19/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////19//


    //20/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////2019//

    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string downLineReport(string userid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_DOWNLINE_REPORT  ";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Parameters.AddWithValue("@USERID", userid);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }

    }


    //20/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////20//

    //21/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////21//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string changeUserStatus(string userid, string userstatus)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_CHANGE_USER_STATUS";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@USER_STATUS", userstatus);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 50);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //21/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////21//


    //22/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////22//

    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getCompanyIdsForReg(string criteria)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_COMPANY_IDS_FOR_REGISTRATON  ";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Parameters.AddWithValue("@CRITERIA", criteria);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }

    }


    //22/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////22//

    //23/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////23//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getUserDetailsByLoginId(string loginid)
    {
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_GET_USER_DETAILS_BY_LOGINID";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Connection.Open();

            command.Parameters.AddWithValue("@LOGIN_ID", loginid);

            command.CommandType = CommandType.StoredProcedure;



            command.Parameters.Add("@RET_STAR", SqlDbType.VarChar, 1000);
            command.Parameters["@RET_STAR"].Direction = ParameterDirection.Output;

            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STAR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else
                {//@RET_STR = 'PRODUCT_ID:' + @PRODUCT_ID + ':USERID:' + @USERID + ':NAME:' + @NAME + ':MOBILENO:' + @MOBILENO 
                    //+ ':EMAILID:' + @EMAILID + ':REFERAL_ID:' + @REFERAL_ID + ':REFERAL_MOBILE:' + @REFERAL_MOBILE + ':PLACEMENT:' + @PLACEMENT
                    // ':CREATED_DT:' + CONVERT(VARCHAR(30), @CREATED_DT, 106) + ':STATUS:TRUE'
                    string[] result = retunvalue.ToUpper().Split(':');
                    if (result.Length > 0)
                    {
                        sb.Append("{");
                        sb.Append('"');
                        sb.AppendFormat(result[0].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[1].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[2].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[3].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[4].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[5].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[6].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[7].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[8].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[9].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[10].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[11].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[12].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[13].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[14].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[15].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[16].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[17].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[18].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[19].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[20].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[21].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[22].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[23].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[24].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[25].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[26].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[27].ToString());
                        sb.Append('"');
                        sb.Append(',');
                        sb.Append('"');
                        sb.AppendFormat(result[28].ToString());
                        sb.Append('"');
                        sb.Append(':');
                        sb.Append('"');
                        sb.AppendFormat(result[29].ToString());
                        sb.Append('"');
                        sb.Append("},");
                    }
                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }
        }
    }


    //23/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////23//

    //24/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////24//

    public string ApiAuthentication(string NAME, string KEY)
    {
        EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
        KEY = objEncrypt.Decrypt(KEY, "r0b1nr0y");

        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_VALIDATE_MERCHANT_AUTH";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@DNAME", NAME);
            command.Parameters["@DNAME"].Direction = ParameterDirection.Input;
            command.Parameters.AddWithValue("@DKEY", KEY);
            command.Parameters["@DKEY"].Direction = ParameterDirection.Input;
            command.CommandType = CommandType.Text;

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 50);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;                
            }
            connection.Close();
            return retunvalue;

        }

            
    }

    //24/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////24//


    //25/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////25//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]
    public string updateUserData(string userid, string name, string mobile, string email)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_UPDATE_USER_RAW_DATA";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@USERID", userid);
            command.Parameters.AddWithValue("@NAME", name);
            command.Parameters.AddWithValue("@MOBILENO", mobile);
            command.Parameters.AddWithValue("@EMAILID", email);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 50);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //25/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////25//

    //26/////////////////////end/////////////////////////Naidu/////////////////////////////end/////////////////26//Send SMS by //


    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string sendSMSbyuid(string sUserid, string message)
    {
        SMSCAPI obj = new SMSCAPI();
        string smsStatus = obj.SendSMS_byUid("helpme2helpyou", "56491427", sUserid, message, "conn_str");
        string outputJson = string.Empty;
        string status = string.Empty;
        ClientUser response1 = new ClientUser
        {
            STATUS = status
        };
        var javaScriptSerializer = new JavaScriptSerializer();
        outputJson = javaScriptSerializer.Serialize(response1);
        return outputJson;
    }
    //26/////////////////////Start/////////////////////////Naidu/////////////////////////////Start////////////////26//




    //27/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////27//

    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getAllUsers(string criteria)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "DBO.USP_GET_ALL_USERS";
            SqlCommand command = new SqlCommand(commandNAME, connection);
            command.Parameters.AddWithValue("@CRITERIA", criteria);
            command.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            // var DB = new SqlCommand();
            command.Connection = connection;
            command.CommandText = commandNAME;
            var data = command.ExecuteReader();
            string outputJson = string.Empty;
            return outputJson = WriteReaderToJSON(sb, data);
        }

    }


    //27/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////27//




    //28/////////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////28//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]
    //@REQUESTED_USERID VARCHAR(30), @ASSIGNED_USERID VARCHAR(30), @RET_STR VARCHAR(30) OUTPUT)
    public string requestForRjectMapping(string ruserid, string auserid)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_REREQUEST_FOR_REJECTED_MAPPING";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@REQUESTED_USERID", ruserid);
            command.Parameters.AddWithValue("@ASSIGNED_USERID", auserid);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 100);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string status = string.Empty;
            string retunvalue = string.Empty;
            var javaScriptSerializer = new JavaScriptSerializer();
            string outputJson = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;


                if (retunvalue.ToUpper().Trim().Contains("FAIL"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    sb.Append("{");
                    sb.Append('"');
                    sb.AppendFormat("STATUS");
                    sb.Append('"');
                    sb.Append(':');
                    sb.Append('"');
                    sb.AppendFormat(retunvalue);
                    sb.Append('"');
                    sb.Append("},");

                }
                outputJson = sb.Remove(sb.Length - 1, 1).ToString();
                sb.Clear();

                return outputJson;
            }


        }

    }

    //28/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////28//



    public class ClientUser
    {
        public string PRODUCT_ID { get; set; }
        public string USERID { get; set; }
        public string NAME { get; set; }
        public string MOBILENO { get; set; }
        public string EMAILID { get; set; }
        public string REFERAL_ID { get; set; }
        public string REFERAL_MOBILE { get; set; }
        public string PLACEMENT { get; set; }
        public string CREATED_DT { get; set; }
        public string STATUS { get; set; }
        public string LOGINID { get; set; }
        public string AMOUNT { get; set; }
        public string REQUESTED_DATE { get; set; }
        public string PLACEMENT_TO_NODE { get; set; }
        public string APPROVED_DATE { get; set; }

    }
    
}
