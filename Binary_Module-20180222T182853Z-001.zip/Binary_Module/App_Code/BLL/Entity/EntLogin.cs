﻿using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Summary description for EntLogin
/// </summary>
public class EntLogin
{
    private string userID;
    private string userName;
    private string password;
    private string emailId;
    private string mobileNo;
    private string genderID;
    private string roleID;
    private int statusID;
    private DateTime createdDate;
    private string createdBy;
    private DateTime updatedDate;
    private string updatedBy;

    public string UserID
    {
        get { return userID; }
        set { userID = value; }
    }

    public string UserName
    {
        get { return userName; }
        set { userName = value; }
    }

    public string Password
    {
        get { return password; }
        set { password = value; }
    }

    public string EmailId
    {
        get { return emailId; }
        set { emailId = value; }
    }

    public string MobileNo
    {
        get { return mobileNo; }
        set { mobileNo = value; }
    }

    public string GenderID
    {
        get { return genderID; }
        set { genderID = value; }
    }

    public string RoleID
    {
        get { return roleID; }
        set { roleID = value; }
    }

    public int StatusID
    {
        get { return statusID; }
        set { statusID = value; }
    }

    public DateTime CreatedDate
    {
        get { return createdDate; }
        set { createdDate = value; }
    }

    public string CreatedBy
    {
        get { return createdBy; }
        set { createdBy = value; }
    }

    public DateTime UpdatedDate
    {
        get { return updatedDate; }
        set { updatedDate = value; }
    }

    public string UpdatedBy
    {
        get { return updatedBy; }
        set { updatedBy = value; }
    }

	public EntLogin()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}