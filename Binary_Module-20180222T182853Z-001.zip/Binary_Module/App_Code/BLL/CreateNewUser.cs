﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsECportal
/// </summary>
public class CreateNewUser : BaseClass
{
    public CreateNewUser()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public int CreateUser(string sProdID, string txtmblno, string txtFullName, string txtEmailId, string sPassword, string txtRfrlMblNo, string option)
    {
        try
        {
            string SQLquery = "EXEC DBO.USP_CREATE_USER_RAW_DATA  '"+ sProdID +"', '" + txtFullName + "','" + txtmblno + "','" + txtEmailId + "', '"+ sPassword +"', '" + txtRfrlMblNo + "','" + option  + "'";

            int intRowAffect = fnExecuteNonQuery(SQLquery, true);

            return intRowAffect;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public int VerifyUser( string sUserId)
    {
        try
        {
            //exec dbo.USP_CREATE_USER_REGISTRATION 'P1', '7998232123434760'
            //Exec DBO.USP_CREATE_USER_REGISTRATION 'Uday E', '7000000081', 'Level_8_left@gmail.com', '1234567890123456','L'
            string SQLquery = "EXEC DBO.USP_CREATE_USER_REGISTRATION '" + sUserId + "'";

            int intRowAffect = fnExecuteNonQuery(SQLquery, true);

            return intRowAffect;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



}