﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text;
using System.Data.SqlClient;

/// <summary>
/// Summary description for GetData
/// </summary>
public class GetData : BaseClass
{
	public GetData()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable GetRawMembersDetails(string condition , string Value)
    {

        try
        {
            string sQry = "SELECT USERID, NAME, MOBILENO, EMAILID, REFERAL_ID, REFERAL_MOBILE, PLACEMENT, CREATED_DT ";
            sQry = sQry + " FROM TBL_USER_RAW_DATA WHERE " + condition + " = '" + Value + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable GetActiveMembersDetails(string condition, string Value)
    {

        try
        {
            string sQry = "SELECT * ";
            sQry = sQry + " FROM TBL_USER_REGISTRATION WHERE " + condition + " = '" + Value + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable GetProducts()
    {

        try
        {
            string sQry = "select *from dbo.TBL_PRODUCTS";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable GetProductsDetailsByID(string sProdID)
    {

        try
        {
            string sQry = "select *from dbo.TBL_PRODUCTS where product_id = '"+ sProdID +"' ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public int ProductSave(string sProdID, string sProdDesc, string sMethod, int iPeriod, double dBonusAmount, double dSposorAmount, bool bConsiderLR, double dBinaryAmt, double dCeilingAmt )
    {
        try
        {

            string[] strArrList = { "@PRODUCT_ID" , "@PRODUCT_DESCRIPTION" , "@BONUS_CALCULATION_METHODOLOGY" , "@BONUS_CONSIDERATION_PERIOD" , "@BONUS_AMOUNT" , "@SPONSOR_BONUS_AMOUNT" , "@CONSIDER_REFERAL_LR_FOR_BINARY" , "@BINARY_BONUS_AMOUNT" , "@BINARY_CEILING_AMOUNT" };
            string [] strArrValues = { sProdID, sProdDesc, sMethod, iPeriod.ToString(), dBonusAmount.ToString(), dSposorAmount.ToString(), bConsiderLR.ToString(), dBinaryAmt.ToString(), dCeilingAmt.ToString() };
            int intRowAffect = fnRunProcedure("USP_PRODUCT_SAVE", strArrList, strArrValues, true);

            return intRowAffect;

        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public bool CheckUserAuthentication(string sLoginID, string sPassword)
    {
        try
        {
            bool bRetVal = false;
            string sQry = "SELECT DBO.FN_CHECKING_LOGIN('"+ sLoginID +"','"+ sPassword +"') CHK";
            DataTable dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                bRetVal = Convert.ToBoolean(dt.Rows[0]["CHK"].ToString());
            }
            return bRetVal;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public string insertMerchant(string SETTINGNAME, string SETTINGVALUE, string constr)
    {
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings[constr].ToString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string commandNAME = "USP_INSERT_ADMIN_SETTINGS";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@_SETTINGNAME", SETTINGNAME);
            command.Parameters.AddWithValue("@_SETTINGVALUE", SETTINGVALUE);

            command.Parameters.Add("@RET_STR", SqlDbType.VarChar, 50);
            command.Parameters["@RET_STR"].Direction = ParameterDirection.Output;
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            string retunvalue = string.Empty;

            using (SqlDataReader dr = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RET_STR"].Value;
                EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
                retunvalue = objEncrypt.Encrypt(retunvalue, "r0b1nr0y");
                return retunvalue;
            }


        }
    }

   
}

      