﻿using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;


public class SMSCAPI
{
    private WebProxy objProxy1 = null;

    private void StreamReader(Stream stream)
    {
        throw new NotImplementedException();
    }



    public string SendSMS(string User, string password, string Mobile_Number, string Message, string Mtype, string DR)
    {

        Int64 mblno = Convert.ToInt64(Mobile_Number);
        if ((mblno >= 917000001001 && mblno <= 917000003047) || mblno == 917123456789)
        {
            string sConnStr = ConfigurationManager.AppSettings["conn_str"].ToString();
            SqlConnection Conn = new SqlConnection(sConnStr);
            Conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = Conn;

            string sQry = "SELECT SETTING_VALUE FROM TBL_ADMIN_SETTINGS WHERE SETTING_NAME = 'COMPANY_BYPASSING_MOBILENO'";
            cmd.CommandText = (sQry);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtup = new DataTable();
            da.Fill(dtup);

            if (dtup.Rows.Count <= 0)
            {

                return "invalid details";
            }


            // 
            // mblno = 919494263744;
            mblno = Convert.ToInt64("91" + dtup.Rows[0]["SETTING_VALUE"].ToString());

        }
        //return "abc";
        //if (Message.Contains("Bank Details: AXIS BANK, Branch: EDARAPALLI, IFSC CODE: UTIB0000374"))
        //{
        //    Message = Message + " Account Number: 915010039104830"; 
        //}

        System.Object stringpost = "User=" + User + "&passwd=" + password + "&mobilenumber=" + mblno + "&message=" + Message + "&MType=" + Mtype + "&DR=" + DR;

        //string functionReturnValue = null;
        //functionReturnValue = "";

        HttpWebRequest objWebRequest = null;
        HttpWebResponse objWebResponse = null;
        StreamWriter objStreamWriter = null;
        StreamReader objStreamReader = null;

        try
        {
            string stringResult = null;

            objWebRequest = (HttpWebRequest)WebRequest.Create("http://www.smscountry.com/SMSCwebservice.asp?");
            objWebRequest.Method = "POST";

            if ((objProxy1 != null))
            {
                objWebRequest.Proxy = objProxy1;
            }


            objWebRequest.ContentType = "application/x-www-form-urlencoded";

            objStreamWriter = new StreamWriter(objWebRequest.GetRequestStream());
            objStreamWriter.Write(stringpost);
            objStreamWriter.Flush();
            objStreamWriter.Close();

            objWebResponse = (HttpWebResponse)objWebRequest.GetResponse();
            objStreamReader = new StreamReader(objWebResponse.GetResponseStream());
            stringResult = objStreamReader.ReadToEnd();

            objStreamReader.Close();
            return (stringResult);
        }
        catch (Exception ex)
        {
            return (ex.Message);
        }
        finally
        {

            if ((objStreamWriter != null))
            {
                objStreamWriter.Close();
            }
            if ((objStreamReader != null))
            {
                objStreamReader.Close();
            }
            objWebRequest = null;
            objWebResponse = null;
            objProxy1 = null;
        }
    }

    public string SendSMS(string User, string password, string Mobile_Number, string Message, string Mtype, string DR, string sendid)
    {



        Int64 mblno = Convert.ToInt64(Mobile_Number);
        if (mblno == 917123456788 || mblno == 917123456789 || mblno == 917893251639)
        {
            string sConnStr = ConfigurationManager.AppSettings["conn_str1"].ToString();
            SqlConnection Conn = new SqlConnection(sConnStr);
            Conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = Conn;

            string sQry = "SELECT SETTING_VALUE FROM TBL_ADMIN_SETTINGS WHERE SETTING_NAME = 'COMPANY_BYPASSING_MOBILENO'";
            cmd.CommandText = (sQry);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtup = new DataTable();
            da.Fill(dtup);

            if (dtup.Rows.Count <= 0)
            {

                return "invalid details";
            }


            // 
            // mblno = 919494263744;
            mblno = Convert.ToInt64("91" + dtup.Rows[0]["SETTING_VALUE"].ToString());

        }
        //return "abc";
        //if (Message.Contains("Bank Details: AXIS BANK, Branch: EDARAPALLI, IFSC CODE: UTIB0000374"))
        //{
        //    Message = Message + " Account Number: 915010039104830"; 
        //}

        System.Object stringpost = "User=" + User + "&passwd=" + password + "&mobilenumber=" + mblno + "&message=" + Message + "&MType=" + Mtype + "&DR=" + DR + "&sid=" + sendid;

        //string functionReturnValue = null;
        //functionReturnValue = "";

        HttpWebRequest objWebRequest = null;
        HttpWebResponse objWebResponse = null;
        StreamWriter objStreamWriter = null;
        StreamReader objStreamReader = null;

        try
        {
            string stringResult = null;

            objWebRequest = (HttpWebRequest)WebRequest.Create("http://www.smscountry.com/SMSCwebservice.asp?");
            objWebRequest.Method = "POST";

            if ((objProxy1 != null))
            {
                objWebRequest.Proxy = objProxy1;
            }


            objWebRequest.ContentType = "application/x-www-form-urlencoded";

            objStreamWriter = new StreamWriter(objWebRequest.GetRequestStream());
            objStreamWriter.Write(stringpost);
            objStreamWriter.Flush();
            objStreamWriter.Close();

            objWebResponse = (HttpWebResponse)objWebRequest.GetResponse();
            objStreamReader = new StreamReader(objWebResponse.GetResponseStream());
            stringResult = objStreamReader.ReadToEnd();

            objStreamReader.Close();
            return (stringResult);
        }
        catch (Exception ex)
        {
            return (ex.Message);
        }
        finally
        {

            if ((objStreamWriter != null))
            {
                objStreamWriter.Close();
            }
            if ((objStreamReader != null))
            {
                objStreamReader.Close();
            }
            objWebRequest = null;
            objWebResponse = null;
            objProxy1 = null;
        }
    }

    public string SendSMS_byUid(string User, string password, string sUserID, string Message, string conn_str)
    {

        string sConnStr = ConfigurationManager.AppSettings[conn_str].ToString();
        SqlConnection Conn = new SqlConnection(sConnStr);
        Conn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = Conn;
        string sQry = "SELECT DBO.FN_GET_SMS_SENDING_MOBILENO('" + sUserID + "') mblno";
        cmd.CommandText = (sQry);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dtup = new DataTable();
        da.Fill(dtup);

        if (dtup.Rows.Count <= 0)
        {

            return "invalid details";
        }

        System.Object stringpost = "User=" + User + "&passwd=" + password + "&mobilenumber=91" + dtup.Rows[0]["mblno"].ToString() + "&message=" + Message + "&MType=N&DR=Y";

        //string functionReturnValue = null;
        //functionReturnValue = "";

        HttpWebRequest objWebRequest = null;
        HttpWebResponse objWebResponse = null;
        StreamWriter objStreamWriter = null;
        StreamReader objStreamReader = null;

        try
        {
            string stringResult = null;

            objWebRequest = (HttpWebRequest)WebRequest.Create("http://www.smscountry.com/SMSCwebservice.asp?");
            objWebRequest.Method = "POST";

            if ((objProxy1 != null))
            {
                objWebRequest.Proxy = objProxy1;
            }


            objWebRequest.ContentType = "application/x-www-form-urlencoded";

            objStreamWriter = new StreamWriter(objWebRequest.GetRequestStream());
            objStreamWriter.Write(stringpost);
            objStreamWriter.Flush();
            objStreamWriter.Close();

            objWebResponse = (HttpWebResponse)objWebRequest.GetResponse();
            objStreamReader = new StreamReader(objWebResponse.GetResponseStream());
            stringResult = objStreamReader.ReadToEnd();

            objStreamReader.Close();
            return (stringResult);
        }
        catch (Exception ex)
        {
            return (ex.Message);
        }
        finally
        {

            if ((objStreamWriter != null))
            {
                objStreamWriter.Close();
            }
            if ((objStreamReader != null))
            {
                objStreamReader.Close();
            }
            objWebRequest = null;
            objWebResponse = null;
            objProxy1 = null;
        }
    }




}






