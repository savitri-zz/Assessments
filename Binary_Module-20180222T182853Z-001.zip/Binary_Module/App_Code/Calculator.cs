﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Calculator" in code, svc and config file together.
public class Calculator : BaseClass , ICalculator
{
	public void DoWork()
	{
	}

    public double AddNumbers(double number1, double number2)
    {
        double result = number1 + number2;
        return result;
    }

    public double SubstractNumbers(double number1, double number2)
    {
        double result = number1 - number2;
        return result;
    }

    public double MultiplyNumbers(double number1, double number2)
    {
        double result = number1 * number2;
        return result;
    }

    public double DivisionNumbers(double number1, double number2)
    {
        double result = number1 / number2;
        return result;
    }


    public bool CheckUserAuthentication(string sLoginID, string sPassword)
    {
        try
        {
            bool bRetVal = false;
            string sQry = "SELECT DBO.FN_CHECKING_LOGIN('" + sLoginID + "','" + sPassword + "') CHK";
            DataTable dt =  GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                bRetVal = Convert.ToBoolean(dt.Rows[0]["CHK"].ToString());
            }
            return bRetVal;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public int CreateUser(string sProdID, string txtmblno, string txtFullName, string txtEmailId, string sPassword, string txtRfrlMblNo, string option)
    {
        try
        {
            string SQLquery = "EXEC DBO.USP_CREATE_USER_RAW_DATA  '" + sProdID + "', '" + txtFullName + "','" + txtmblno + "','" + txtEmailId + "', '" + sPassword + "', '" + txtRfrlMblNo + "','" + option + "'";

            int intRowAffect = fnExecuteNonQuery(SQLquery, true);

            return intRowAffect;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}
