using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;


//public class CommonSetting
//{
//    //public static string SQLConnectionString = ReadConfigFileValue("CONN_STR");
//    public static string smtphost = ReadConfigFileValue("SMTP_HOST");
//    public static string DataNumberFormat = "###,###,###,##0";
    
//    public CommonSetting()
//    {

//    }
//    public static string GetMasterDBName()
//    {
//        try
//        {
//            return "Bit2byteonlineDb";
//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    public static string GetsubDBName()
//    {
//        try
//        {
//            return "bit2byteonline.in";
//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    public static string GetConnectionString(bool IsMasterDataBase)
//    {
//        try
//        {
//            string SQLString = ReadConfigFileValue("CONN_STR");
//            if (IsMasterDataBase == true)
//            {
//                SQLString = SQLString.Replace("#DBNAME#", CommonSetting.GetMasterDBName().ToString());
//                return SQLString;
//            }
//            else
//            {
//                string SQLString1 = ReadConfigFileValue("CONN_STR1");
//                SQLString1 = SQLString1.Replace("#DBNAME#", CommonSetting.GetsubDBName().ToString());
//                return SQLString1;
//            }


//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    public static string ReadTemplateFile(string strFileName)
//    {
//        try
//        {
//            StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath(strFileName));
//            string strFileContent = sr.ReadToEnd();
//            sr.Close();
//            sr = null;
//            return strFileContent;
//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    public static void WriteErrorLog(Exception Ex)
//    {
//        try
//        {
//            StreamWriter sw = new StreamWriter(HttpContext.Current.Server.MapPath("ErrorLog\\Error.Log"));
//            sw.WriteLine(DateTime.Today.ToString() + "  " + Ex.Message.ToString());
//            sw = null;
//        }
//        catch (Exception Ex1)
//        {
//            throw Ex1;
//        }
//    }

//    public static string ReadConfigFileValue(string Key)
//    {
//        try
//        {
//            string Value = "";
//            Value = ConfigurationManager.AppSettings[Key];
//            return Value;
//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    public static void ExportToCSV(DataTable dtTmp, string FileName)
//    {
//        try
//        {
//            HttpContext.Current.Response.Clear();
//            HttpContext.Current.Response.Buffer = true;
//            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";

//            //HttpContext.Current.Response.ContentType = "application/pdf";
//            //HttpContext.Current.Response.WriteFile(HttpContext.Current.Server.MapPath("" + FileName )); 
//            HttpContext.Current.Response.AddHeader("Content-Disposition", "inline;filename=" + FileName + "");
//            HttpContext.Current.Response.Charset = "";
//            ProduceCSV(dtTmp, HttpContext.Current.Response.Output, true);
//            HttpContext.Current.Response.End();
//        }
//        catch (Exception Ex)
//        {
//            throw Ex;
//        }
//    }

//    private static void ProduceCSV(DataTable dt, System.IO.TextWriter httpStream, bool WriteHeader)
//    {
//        if (WriteHeader)
//        {
//            string[] arr = new String[dt.Columns.Count];
//            for (int i = 0; i < dt.Columns.Count; i++)
//            {
//                arr[i] = dt.Columns[i].ColumnName;
//            }

//            httpStream.WriteLine(string.Join(",", arr));
//            httpStream.WriteLine("");
//        }

//        for (int j = 0; j < dt.Rows.Count; j++)
//        {
//            string[] dataArr = new String[dt.Columns.Count];
//            for (int i = 0; i < dt.Columns.Count; i++)
//            {
//                //object o = dt.Rows[j][i];
//                //dataArr[i] = GetWriteableValue(o);
//                dataArr[i] = CSVString(dt.Rows[j][i].ToString());
//            }
//            httpStream.WriteLine(string.Join(",", dataArr));
//        }
//    }

//    private static string CSVString(string str)
//    {
//        try
//        {
//            str = str.Replace("\n", " ");
//            str = str.Replace("\r", " ");
//            str = str.Replace(",", " ");
//            return " " + str;
//        }
//        catch
//        {
//            return "";
//        }
//    }

//}



public class CommonSetting
{
    //public static string SQLConnectionString = ReadConfigFileValue("CONN_STR");
    public static string smtphost = ReadConfigFileValue("SMTP_HOST");
    public static string DataNumberFormat = "###,###,###,##0";

    public CommonSetting()
    {

    }
    public static string GetMasterDBName()
    {
        try
        {
            return "Mfloat_DB";
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public static string GetsubDBName()
    {
        try
        {
            return "Mfloat_DB";
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public static string GetConnectionString(bool IsMasterDataBase)
    {
        try
        {
            string SQLString = ReadConfigFileValue("CONN_STR");
            if (IsMasterDataBase == true)
            {
                SQLString = SQLString.Replace("#DBNAME#", CommonSetting.GetMasterDBName().ToString());
                return SQLString;
            }
            else
            {
                string SQLString1 = ReadConfigFileValue("CONN_STR1");
                SQLString1 = SQLString1.Replace("#DBNAME#", CommonSetting.GetsubDBName().ToString());
                return SQLString1;
            }


        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public static string ReadTemplateFile(string strFileName)
    {
        try
        {
            StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath(strFileName));
            string strFileContent = sr.ReadToEnd();
            sr.Close();
            sr = null;
            return strFileContent;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public static void WriteErrorLog(Exception Ex)
    {
        try
        {
            StreamWriter sw = new StreamWriter(HttpContext.Current.Server.MapPath("ErrorLog\\Error.Log"));
            sw.WriteLine(DateTime.Today.ToString() + "  " + Ex.Message.ToString());
            sw = null;
        }
        catch (Exception Ex1)
        {
            throw Ex1;
        }
    }

    public static string ReadConfigFileValue(string Key)
    {
        try
        {
            string Value = "";
            Value = ConfigurationManager.AppSettings[Key];
            return Value;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public static void ExportToCSV(DataTable dtTmp, string FileName)
    {
        try
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";

            //HttpContext.Current.Response.ContentType = "application/pdf";
            //HttpContext.Current.Response.WriteFile(HttpContext.Current.Server.MapPath("" + FileName )); 
            HttpContext.Current.Response.AddHeader("Content-Disposition", "inline;filename=" + FileName + "");
            HttpContext.Current.Response.Charset = "";
            ProduceCSV(dtTmp, HttpContext.Current.Response.Output, true);
            HttpContext.Current.Response.End();
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    private static void ProduceCSV(DataTable dt, System.IO.TextWriter httpStream, bool WriteHeader)
    {
        if (WriteHeader)
        {
            string[] arr = new String[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                arr[i] = dt.Columns[i].ColumnName;
            }

            httpStream.WriteLine(string.Join(",", arr));
            httpStream.WriteLine("");
        }

        for (int j = 0; j < dt.Rows.Count; j++)
        {
            string[] dataArr = new String[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                //object o = dt.Rows[j][i];
                //dataArr[i] = GetWriteableValue(o);
                dataArr[i] = CSVString(dt.Rows[j][i].ToString());
            }
            httpStream.WriteLine(string.Join(",", dataArr));
        }
    }

    private static string CSVString(string str)
    {
        try
        {
            str = str.Replace("\n", " ");
            str = str.Replace("\r", " ");
            str = str.Replace(",", " ");
            return " " + str;
        }
        catch
        {
            return "";
        }
    }

}
