﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ServiceReference2;

public partial class Registration_Form : System.Web.UI.Page
{
    
    string option;
    GetData clsGetData = new GetData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblError.Visible = false;
            LoadProducts();
        }
    }

    private void LoadProducts()
    {
        DataTable dtProducts = new DataTable();
        dtProducts = clsGetData.GetProducts();
        ddlProducts.DataSource = dtProducts;

        ddlProducts.DataTextField = "PRODUCT_DESCRIPTION";
        ddlProducts.DataValueField = "PRODUCT_ID";
        ddlProducts.DataBind();
        ddlProducts.Items.Insert(0, new ListItem("----Please Select-----", "0"));
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (txtmblno.Text.ToString() == "" || txtFullName.Text.ToString() =="" || txtEmailId.Text.ToString()=="" || txtRfrlMblNo.Text.ToString()=="" )
        {
            lblError.Visible = true;
            return;

        }

        if (rbtLstRating.SelectedIndex != -1)
        {
            string answer = rbtLstRating.SelectedItem.Text;
            option = rbtLstRating.SelectedItem.Value;
        }
        else
        {
            lblError.Visible = true;
            return;
        }


        CalculatorClient proxy = new CalculatorClient();

        //CreateNewUser clsNewUSer = new CreateNewUser();
       // int i = clsNewUSer.CreateUser(ddlProducts.SelectedValue.ToString(), txtmblno.Text.ToString(), txtFullName.Text.ToString(), txtEmailId.Text.ToString(), "",txtRfrlMblNo.Text.ToString(), option);
        int i = proxy.CreateUser(ddlProducts.SelectedValue.ToString(), txtmblno.Text.ToString(), txtFullName.Text.ToString(), txtEmailId.Text.ToString(), "", txtRfrlMblNo.Text.ToString(), option);

        if (i <= 0)
        {
            lblError.Text = "Something went wrong please try again";
            lblError.Visible = true;
            return;
        }
        else
        {
            lblAddResult.Text = "Successfully create left member";
            txtmblno.Text = "";
            txtFullName.Text = "";
            txtEmailId.Text = "";
            txtRfrlMblNo.Text = "";
            rbtLstRating.SelectedIndex = -1 ;
            ddlProducts.SelectedIndex = -1;

        }
        
    }
    protected void txtmblno_TextChanged(object sender, EventArgs e)
    {
        DataTable chkMobile = new DataTable();
        chkMobile = clsGetData.GetRawMembersDetails("MOBILENO", txtmblno.Text.ToString());
        if (chkMobile.Rows.Count > 0)
        {
            lblError.Text = "Mobile Number already Exists";
            lblError.Visible = true;
            return;
        }


    }
    protected void txtEmailId_TextChanged(object sender, EventArgs e)
    {
        DataTable chkMobile = new DataTable();
        chkMobile = clsGetData.GetRawMembersDetails("EMAILID", txtEmailId.Text.ToString());
        if (chkMobile.Rows.Count > 0)
        {
            lblError.Text = "EmailId Already Exists";
            lblError.Visible = true;
            return;
        }
    }
    protected void txtRfrlMblNo_TextChanged(object sender, EventArgs e)
    {
        DataTable chkMobile = new DataTable();
        chkMobile = clsGetData.GetActiveMembersDetails("MOBILENO", txtRfrlMblNo.Text.ToString());
        if (chkMobile.Rows.Count <= 0)
        {
            lblError.Text = "Referal Mobile Does Not Exists";
            lblError.Visible = true;
            return;
        }
    }
    //protected void btnLogin_Click(object sender, EventArgs e)
    //{

    //    CalculatorClient proxy = new CalculatorClient();
    //    if (proxy.CheckUserAuthentication(txtLoginID.Text, txtPassword.Text) == true)
    //    {
    //        lblAddResult.Text = "Result of CheckUserAuthentication Operation + Success" ;
    //    }
    //    else
    //    {
    //        lblAddResult.Text = "Result of CheckUserAuthentication Operation + Failed";
    //    }
    //}

    protected void btnLogin_Click(object sender, EventArgs e)
    {

                wsBinaryService  proxy = new wsBinaryService();
                string s = proxy.chkUserAuth(txtLoginID.Text, txtPassword.Text);
                lblAddResult.Text = s;
    }
}