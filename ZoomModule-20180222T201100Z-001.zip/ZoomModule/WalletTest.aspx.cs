﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Net;
using System.Web.Configuration;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;


public partial class Zoom_WalletTest : System.Web.UI.Page
{

    public class User
    {
        public string emailId { get; set; }
        public string password { get; set; }
        public string amount { get; set; }
        public string transid { get; set; }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        wsWalletData MS = new wsWalletData();
       Label1.Text = MS.validateWallet("", "rishi@123", "50","0122334657998");
        //string emailId = "rishikiran555@gmail.com";
        //string transid = "0123456789";

        ////Save wallet transactions

        //DateTime date = DateTime.Now;

        //string timeStamp = Convert.ToString(date.Ticks);


        //string transDate = timeStamp;

        //timeStamp = timeStamp.Replace("-", " ");
        //timeStamp = timeStamp.Replace(":", " ");
        //timeStamp = timeStamp.Replace(".", " ");
        //timeStamp = timeStamp.Replace(" ", "");


        //string transId = "TRN-" + timeStamp;

        //User user = new User
        //{

        //    emailId = "rishikiran555@gmail.com",
        //    password = "rishi@123",
        //    amount = "10",
        //    transid = "0123456789"
        //    // "rishikiran555@gmail.com", "rishi@123", "20"
        //};

        //var javaScriptSerializer = new JavaScriptSerializer();
        //string jsonString = javaScriptSerializer.Serialize(user);
        //Label1.Text = jsonString.ToString();

        
        //wsWalletData test = new wsWalletData();
        //Label1.Text = test.validateWalletDetails(jsonString);

       

    }

}