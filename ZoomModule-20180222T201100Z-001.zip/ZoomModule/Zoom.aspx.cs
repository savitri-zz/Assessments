﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Xml;
using System.IO;

public partial class Zoom : System.Web.UI.Page
{

    public string sLoginUserId = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["UserID"] != null)
        {
            sLoginUserId = Request.QueryString["UserID"].ToString();
            EncryptDecryptQueryString objDecrypt = new EncryptDecryptQueryString();
            sLoginUserId = objDecrypt.Decrypt(Request.QueryString["UserID"].ToString(), "r0b1nr0y").ToString();
            hdnUserId.Value = sLoginUserId;
            bindProfile();    
            recentAds();
            bindZoom();
        }

    }

    private void bindProfile()
    {
        bllOpmlData cls = new bllOpmlData();
        DataTable dtOpml = new DataTable();
        dtOpml = cls.getUserPersonalData(sLoginUserId);
        if (dtOpml.Rows.Count <= 0)
            return;

        string user_fileName = string.Format("http://mfloat.in/inner/Crop_Images/Small_Images/") + dtOpml.Rows[0]["imagename"].ToString();

        try
        {
            img_pfphto.Src = img_pfphto.ResolveUrl(string.Format(user_fileName));

        }
        catch (Exception ex)
        {
        }

        //string path = Server.MapPath("/~/inner/Background_Themes/");
        string themepath = string.Format("'http://mfloat.in/inner/Background_Themes/" + dtOpml.Rows[0]["THEME_IMAGE_NAME"].ToString() + "'");
        if (dtOpml.Rows[0]["THEME_IMAGE_NAME"].ToString() == "")
            themepath = "'http://mfloat.in/inner/images/icons/BackTheme_Default.png'";

        ThemeBackground.Style.Add("background", "url(" + themepath + ") no-repeat left top");

        ThemeBackground.Style.Add("background-size", "100% 100%");

        lblname.Text = dtOpml.Rows[0]["FULLNAME"].ToString();
        lbloccupation.Text = dtOpml.Rows[0]["Occupation"].ToString();
    }

    protected void recentAds()
    {
        bllOpmlData cls = new bllOpmlData();
        DataTable dt_RecentAds = cls.get_Recently_LikedAds(sLoginUserId);
        if (dt_RecentAds.Rows.Count > 0)
        {
            rptrAds.DataSource = dt_RecentAds.AsEnumerable().Take(8).Reverse().CopyToDataTable();
            rptrAds.DataBind();
        }
        else
        {

        }

    }

    [WebMethod]
    public static string LoadMore(string sUid, string sNoArray)
    {
        bllOpmlData cls = new bllOpmlData();
        System.Threading.Thread.Sleep(2000);
        DataSet ds = new DataSet();
        ds = cls.bindZoom(sUid, "LOAD_MORE", sNoArray);
        return ds.GetXml();
        
    }

    private void bindZoom()
    {
        if (HdnNewsId.Value.ToString() == "") { HdnNewsId.Value = "0"; }
        bllOpmlData cls = new bllOpmlData();
        DataSet dt = new DataSet();
        dt = cls.bindZoom(sLoginUserId, "FIRST_NEWS", HdnNewsId.Value);
        DataTable dts = dt.Tables[0];
        dts = dt.Tables[0];
        if (dts.Rows.Count <= 0)
            return;
        dts = dts.AsEnumerable().Take(12).Reverse().CopyToDataTable();
        rptrOpml.DataSource = dts;
        rptrOpml.DataBind();
        StringBuilder sb = new StringBuilder();
        foreach (DataRow dr in dts.Rows)
        {
            sb.Append(dr["SNO"].ToString());
            sb.Append(',');
        }
        sb = sb.Remove(sb.Length - 1, 1);
        HdnListNewsId.Value = sb.ToString();

    }
}