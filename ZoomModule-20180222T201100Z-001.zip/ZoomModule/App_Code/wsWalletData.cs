﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.ServiceModel.Web;
using System.Web.Script.Services;
using System.Globalization;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for WebService1
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.ComponentModel.ToolboxItem(false)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class wsWalletData : System.Web.Services.WebService
{
    //1/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////1//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string validateWallet(string emailId, string password, string amount, string transid)
    {
        SqlTransaction Transaction = null;
        //string emailId1 = HttpContext.Current.Request.Params["emailId"];
        //string password1 = HttpContext.Current.Request.Params["password"];
        //string amount1 = HttpContext.Current.Request.Params["amount"];
        //string transid1 = HttpContext.Current.Request.Params["transid"];

        //int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);

        var sb = new StringBuilder();
        //  string SQLQuery = "SELECT UW.USERID , MBOILE , CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < " + amount + " THEN CAST(ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) AS NVARCHAR) ELSE '" + amount + "' END as AMOUNT , CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < '" + amount + "'THEN 'In Sufficient Balance' ELSE 'Success' END as MESSAGE FROM TBL_USER_WALLET_CURRENT_BALANCES UWCB INNER JOIN TBL_USERWALLET UW ON UWCB.USERID = UW.USERID WHERE UW.EMAILID = '" + emailId + "' AND UW.PASSWORD = '" + password + "'";


        //query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                //connection.Open();
                //Transaction = connection.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            string commandNAME = "USP_DEDUCT_WALLET_AMOUNT";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@EMAIL_ID", emailId);
            command.Parameters.AddWithValue("@WALLET_PASSWORD", password);
            command.Parameters.AddWithValue("@REQUESTED_AMOUNT", ToInt(amount));
            // command.Parameters.AddWithValue("@TRANSACTION_ID", transid1);
            command.Parameters.AddWithValue("@OTHER_APP_TRANSACTION_ID", transid);

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            Transaction = connection.BeginTransaction();
            command.Transaction = Transaction;
            command.Parameters.Add("@SUCCESS_MSG", SqlDbType.VarChar, 100);
            command.Parameters["@SUCCESS_MSG"].Direction = ParameterDirection.Output;
            string retunvalue = "";
            string outputJson = string.Empty;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@SUCCESS_MSG"].Value;

                string amnt = string.Empty;
                string trasid = string.Empty;
                string status = string.Empty;
                if (retunvalue.ToUpper().Trim().Contains("INVALID CREDENTIALS"))
                {
                    amnt = "";
                    status = "INVALID CREDENTIALS";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INVALID REQUESTED AMOUNT"))
                {
                    amnt = "";
                    status = "INVALID REQUESTED AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INSUFFICIENT AMOUNT"))
                {
                    string[] result = retunvalue.ToUpper().Split(':');
                    amnt = result[1].ToString();
                    status = "INSUFFICIENT AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    amnt = "";
                    status = "SUCCESS";
                    string[] result = retunvalue.ToUpper().Split(';');
                    trasid = result[1].ToString();
                }
                else if (retunvalue.ToUpper().Trim().Contains("ERROR"))
                {
                    amnt = "";
                    status = "NETWORK ERROR";
                    trasid = "";
                }


                WalletUser response = new WalletUser
                {
                    TRANSACTIONID = trasid,
                    AMOUNT = amnt,
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }

        }

    }

    public class WalletUser
    {
        public string TRANSACTIONID { get; set; }
        public string AMOUNT { get; set; }
        public string STATUS { get; set; }

    }


    //1/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////1//


    //4/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////4//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string checkWalletDetails(string emailId, string password, string amount, string transid)
    {
        SqlTransaction Transaction = null;
        //string emailId1 = HttpContext.Current.Request.Params["emailId"];
        //string password1 = HttpContext.Current.Request.Params["password"];
        //string amount1 = HttpContext.Current.Request.Params["amount"];
        //string transid1 = HttpContext.Current.Request.Params["transid"];

        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);

        var sb = new StringBuilder();
        //  string SQLQuery = "SELECT UW.USERID , MBOILE , CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < " + amount + " THEN CAST(ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) AS NVARCHAR) ELSE '" + amount + "' END as AMOUNT , CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < '" + amount + "'THEN 'In Sufficient Balance' ELSE 'Success' END as MESSAGE FROM TBL_USER_WALLET_CURRENT_BALANCES UWCB INNER JOIN TBL_USERWALLET UW ON UWCB.USERID = UW.USERID WHERE UW.EMAILID = '" + emailId + "' AND UW.PASSWORD = '" + password + "'";


        //query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                //connection.Open();
                //Transaction = connection.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            string commandNAME = "USP_DEDUCT_WALLET_AMOUNT";
            SqlCommand command = new SqlCommand(commandNAME, connection);

            command.Parameters.AddWithValue("@EMAIL_ID", emailId);
            command.Parameters.AddWithValue("@WALLET_PASSWORD", password);
            command.Parameters.AddWithValue("@REQUESTED_AMOUNT", ToInt(amount));
            // command.Parameters.AddWithValue("@TRANSACTION_ID", transid1);
            command.Parameters.AddWithValue("@OTHER_APP_TRANSACTION_ID", transid);

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            Transaction = connection.BeginTransaction();
            command.Transaction = Transaction;
            command.Parameters.Add("@SUCCESS_MSG", SqlDbType.VarChar, 100);
            command.Parameters["@SUCCESS_MSG"].Direction = ParameterDirection.Output;
            string retunvalue = "";
            string outputJson = string.Empty;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@SUCCESS_MSG"].Value;

                string amnt = string.Empty;
                string trasid = string.Empty;
                string status = string.Empty;
                if (retunvalue.ToUpper().Trim().Contains("INVALID CREDENTIALS"))
                {
                    amnt = "";
                    status = "INVALID CREDENTIALS";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INVALID REQUESTED AMOUNT"))
                {
                    amnt = "";
                    status = "INVALID REQUESTED AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INSUFFICIENT AMOUNT"))
                {
                    string[] result = retunvalue.ToUpper().Split(';');
                    amnt = result[1].ToString();
                    status = "INSUFFICIENT AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    amnt = "";
                    status = "SUCCESS";
                    string[] result = retunvalue.ToUpper().Split(';');
                    trasid = result[1].ToString();
                }
                else if (retunvalue.ToUpper().Trim().Contains("ERROR"))
                {
                    amnt = "";
                    status = "NETWORK ERROR";
                    trasid = "";
                }


                WalletUser res = new WalletUser
                {
                    TRANSACTIONID = trasid,
                    AMOUNT = amnt,
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(res);

                return outputJson;
            }

        }

    }


    //4/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////4//



    public static int ToInt(string toParse)
    {
        int result;
        if (int.TryParse(toParse, out result)) return result;
        return result;
    }



    //2/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////2//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public virtual string saveWalletTransactions(WalletTransactions wtObj, WalletUsed wuObj)
    {
        SqlTransaction Transaction = null;
        string result = "";
        string SQLQuery1 = "insert into tbl_walletalltransactionproductwallet (userid,mobileno,creditedamount,debitedamt,date,status) values('" + wuObj.USER_ID + "','" + wtObj.MOBILE + "','" + wtObj.CR_AMT + "','" + wtObj.AMT + "', GETDATE() ,'" + wtObj.STATUS + "')";
        string SQLQuery2 = "insert into tbl_prduwalltused (userid,name,emailid,mobile,amt,transactionid,description,date,accountno,status,type,ORDER_ID,SUCCESS_STATUS) values('" + wuObj.USER_ID + "','" + wuObj.NAME + "','" + wuObj.EMAIL_ID + "','" + wuObj.MOBILE + "','" + wuObj.AMT + "','" + wuObj.TRANSACTION_ID + "','" + wuObj.DESCRIPTION + "', getdate() ,'" + wuObj.ACCOUNT_NO + "','" + wuObj.STATUS + "','" + wuObj.Type + "','" + wuObj.ORDER_ID + "','" + wuObj.SUCCESS_STATUS + "')";
        string SQLQuery3 = "EXEC USP_UPDATE_WALLET_CURRENT_BALANCES_BYAMOUNT '" + wtObj.USER_ID + "','" + wtObj.AMT + "'";

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();

        using (SqlConnection con = new SqlConnection(connectionString))
        {

            //int a = Convert.ToInt32(wtObj);
            //int b = Convert.ToInt32(wuObj);
            try
            {
                con.Open();
                Transaction = con.BeginTransaction();
                var DB = new SqlCommand();
                DB.Connection = con;
                DB.CommandText = SQLQuery3;
                DB.Transaction = Transaction;
                int b = DB.ExecuteNonQuery();
                DB = new SqlCommand();
                DB.Connection = con;
                DB.CommandText = SQLQuery1;
                DB.Transaction = Transaction;
                int a = DB.ExecuteNonQuery();
                DB = new SqlCommand();
                DB.Connection = con;
                DB.CommandText = SQLQuery2;
                DB.Transaction = Transaction;
                int c = DB.ExecuteNonQuery();
                Transaction.Commit();
                if (a == 1 && b == 1 && c == 1)
                {
                    result = "Data Saved Sucessfully.";
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Transaction.Rollback();
            }
            finally
            {
                con.Close();
            }
            return result;
        }
    }

    //2/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////2//


    //31/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////3//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public string validateWalletLoginDetails(string jsonString)
    {
        var user = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(jsonString);
        SqlTransaction Transaction = null;
        string emailId1 = HttpContext.Current.Request.Params["emailId"];
        string password1 = HttpContext.Current.Request.Params["password"];
        string amount1 = HttpContext.Current.Request.Params["amount"];

        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);

        var sb = new StringBuilder();
        string SQLQuery = "SELECT UW.USERID+'##'+MBOILE+'##'+ CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < " + user["amount"] + " THEN CAST(ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) AS NVARCHAR) ELSE '" + user["amount"] + "' END AS WALLET_BALANCE FROM TBL_USER_WALLET_CURRENT_BALANCES UWCB INNER JOIN TBL_USERWALLET UW ON UWCB.USERID = UW.USERID WHERE UW.EMAILID = '" + user["emailId"] + "' AND UW.PASSWORD = '" + user["pwd"] + "'";


        //query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
                Transaction = con.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = SQLQuery;
            DB.Transaction = Transaction;
            var data = DB.ExecuteReader();
            var totalRecords = "";
            string outputJson = string.Empty;

            while (data.Read())
            {
                if (totalRecords.Length == 0)
                {
                    totalRecords = data["WALLET_BALANCE"].ToString();
                }
                sb.Append(data["WALLET_BALANCE"]);
            }

            // handles zero records
            if (totalRecords.Length == 0)
            {
                outputJson = sb.ToString();
                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();
            return outputJson;
        }


    }

    //3/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////3//


    //4/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////4//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string validateWalletDetails(string emailId, string password, string amount, string transid, string btnid, string apikey, string apipwd)
    {
        SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
  
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                //connection.Open();
                //Transaction = connection.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            string commandNAME = "USP_DEDUCT_WALLET_AMOUNT";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@EMAIL_ID", emailId);
            command.Parameters.AddWithValue("@WALLET_PASSWORD", password);
            command.Parameters.AddWithValue("@REQUESTED_AMOUNT", ToInt(amount));
            // command.Parameters.AddWithValue("@TRANSACTION_ID", transid1);
            command.Parameters.AddWithValue("@OTHER_APP_TRANSACTION_ID", transid);

            //string btn = objEncrypt.Decrypt(btnid, "r0b1nr0y").ToString();
            //string key = objEncrypt.Decrypt(apikey, "r0b1nr0y").ToString();
            //string pwd = objEncrypt.Decrypt(apipwd, "r0b1nr0y").ToString();
            //command.Parameters.AddWithValue("@BUTTON_ID", btn);
            //command.Parameters.AddWithValue("@API_WALLET_KEY", key);
            //command.Parameters.AddWithValue("@API_WALLET_PASSWORD", pwd);


            command.Parameters.AddWithValue("@BUTTON_ID", objEncrypt.Decrypt(btnid, "r0b1nr0y"));
            command.Parameters.AddWithValue("@API_WALLET_KEY", objEncrypt.Decrypt(apikey, "r0b1nr0y"));
            command.Parameters.AddWithValue("@API_WALLET_PASSWORD", objEncrypt.Decrypt(apipwd, "r0b1nr0y"));

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            Transaction = connection.BeginTransaction();
            command.Transaction = Transaction;
            command.Parameters.Add("@SUCCESS_MSG", SqlDbType.VarChar, 100);
            command.Parameters["@SUCCESS_MSG"].Direction = ParameterDirection.Output;
            string retunvalue = "";
            string outputJson = string.Empty;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@SUCCESS_MSG"].Value;

                string amnt = string.Empty;
                string trasid = string.Empty;
                string status = string.Empty;
                if (retunvalue.ToUpper().Trim().Contains("INVALID CREDENTIALS"))
                {
                    amnt = "";
                    status = "INVALID CREDENTIALS";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INVALID REQUESTED AMOUNT"))
                {
                    amnt = "";
                    status = "INVALID REQUESTED AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INSUFFICIENT AMOUNT"))
                {
                    string[] result = retunvalue.ToUpper().Split(':');
                    amnt = result[1].ToString();
                    status = "INSUFFICIENT AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    amnt = "";
                    status = "SUCCESS";
                    string[] result = retunvalue.ToUpper().Split(';');
                    trasid = result[1].ToString();
                }
                else if (retunvalue.ToUpper().Trim().Contains("ERROR"))
                {
                    amnt = "";
                    status = "NETWORK ERROR";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("Duplicate"))
                {
                    amnt = "";
                    status = retunvalue;
                    trasid = "";
                }
                else 
                {
                    amnt = "";
                    status = retunvalue;
                    trasid = "";
                }


                WalletUser response = new WalletUser
                {
                    TRANSACTIONID = trasid,
                    AMOUNT = amnt,
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }

        }

    }

    //4/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////4//


}
