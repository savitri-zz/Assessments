﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class UserDetails
{
    public string name { get; set; }
    public string emailid { get; set; }
    public string mobileno { get; set; }
    public string userid { get; set; }
}

