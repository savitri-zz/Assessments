﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for paynow
/// </summary>
public class paynow:BaseClass
{
	public paynow()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string verifyCodeGenerator(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return verifyCodeGenerator(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }
    public void insertTransactionDetail(string emailid, string accountno,string pinno,string mobileno, string verifycode, string datetime)
    {
        try
        {

          /*  string SQLQuery = "insert into tbl_regtransactionDetails (Emailid,AccountNo,Pinno,Mobile, verification, generate_date) values ('" + emailid + "','" + accountno + "','" + pinno + "','" + mobileno + "', '" + verifycode + "', '" + datetime + "')";*/


            string SQLQuery = "USP_Bite2Byte_insertTransactionDetail   '" + emailid + "','" + accountno + "','" + pinno + "','" + mobileno + "', '" + verifycode + "', '" + datetime + "'";



            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmemuser(string verify, string accountno,string pinno, string datetime)
    {
        try
        {
            string SQLQuery = "select * from tbl_regtransactionDetails where verification='" + verify + "'  and (AccountNo = '" + accountno + "' or Pinno='" + pinno + "' ) and generate_date='" + datetime + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatetransactiontable(string transid, string verify)
    {
        try
        {

           /* string SQLQuery = "update tbl_regtransactionDetails set transactionid='" + transid.ToString() + "' where verification='" + verify + "'";*/
             string SQLQuery = "update tbl_regtransactionDetails set transactionid='" + transid.ToString() + "' where verification='" + verify + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string Generattransaction(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return Generattransaction(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public void updatebit2bytereg(string transid, string mobile, string email)
    {
        try
        {

            string SQLQuery = "update tbl_registration_temporary set TransactionId='" + transid.ToString() + "' where mobileno='" + mobile + "' and emailid='" + email + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable accountdetail(string verify)
    {
        try
        {
            string SQLQuery = "select * from tbl_transactionDetails where verification='" + verify + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }




    public DataTable moneydeductpaid(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable moneypaidfree(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where pinno='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getamount(string account_no)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no = '" + account_no + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getamount2(string transactionid)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where pinno = '" + transactionid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable delear_users(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as float)) as amount from tbl_delrpintransfer where dealerid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable delearamount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Amount as float)) as amount from tbl_admingenerate_pin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable user_amount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as float)) as amount from tbl_userpin where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable delearuseramount(string mobileno)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as float)) as amount from tbl_delrpintransfer where mobile = '" + mobileno + "' and pinno IS NOT NULL";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertpin_freepinuse(string mobileno, string userid, string name, string emailid, string Amount, string pingenerateid, string transactionid, string bit2byteuserid)
    {
        try
        {

          /*  string SQLQuery = "insert into tbl_userpin (username,emailid, amount,generate_date,userid,transactionid,bit2byteuserid) values ('" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + pingenerateid + "','" + transactionid + "','" + bit2byteuserid + "')";*/

            string SQLQuery = "USP_Bite2Byte_insertpin_freepinuse  '" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + pingenerateid + "','" + transactionid + "','" + bit2byteuserid + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);


        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertpin_delarpinuse(string mobileno, string userid, string name, string emailid, string Amount, string transactionid, string bit2byteuserid)
    {
        try
        {

           /* string SQLQuery = "insert into tbl_delrpintransfer (mobile,dealerid,name,emailid, amount,generatedate,transactionid,bit2byteuserid) values ('" + mobileno + "','" + userid + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + transactionid + "','" + bit2byteuserid + "')";*/

             string SQLQuery = "USP_Bite2Byte_insertpin_delarpinuse     '" + mobileno + "','" + userid + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + transactionid + "','" + bit2byteuserid + "'";



            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmemuser(string mobile, string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration_temporary where mobileno='" + mobile + "' and emailid='" + email + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
     public DataTable paidmemuser(string mobile, string email, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration_temporary where mobileno='" + mobile + "' and emailid='" + email + "' and userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable placementid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  mobileno='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updateReferalDetails(string PlacementID, string SponsorUserID, string referalID, string userID, string mobileNo)
    {
        try
        {
            string query = "update tbl_freememreg set placementid='" + PlacementID + "', SponsorUserID='" + SponsorUserID + "', referalID='" + referalID + "' where userid='" + userID + "'";
            query = string.Concat(query," update tbl_invitefriends set placementid='", PlacementID, "', SponsorUserID='", SponsorUserID, "', referid='", referalID, "', inivted_user='", referalID, "' where mobileno='", mobileNo, "'");
            int intRowAffect = fnExecuteNonQuery(query, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatepaidregistration(string generate_userid, string mobileno)
    {
        try
        {

            string SQLQuery = "update tbl_registration_temporary set usertype = '2' where sno = '" + generate_userid + "' and mobileno='" + mobileno + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void zdeletefreeregistration(string mobileno)
    {
        try
        {

            string SQLQuery = "delete from tbl_freememreg where mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriend(string inviteduser, string mobileno)
    {
        try
        {
            string SQLQuery = "select * from  tbl_invitefriends where  inivted_user='" + inviteduser + "' and mobileno='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updateinviteuserstatus(string invitee)
    {
        try
        {

            string SQLQuery = "update tbl_invitefriends set invited_user_status = '2' where inivted_user = '" + invitee + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertbitinvitation(string invitee, string name, string mobileno, string emailid)
    {
        try
        {

            string SQLQuery = "insert into tbl_invitefriends (inivted_user,fname,mobileno, emailid, invited_date) values ('" + invitee + "','" + name + "','" + mobileno + "', '" + emailid + "', '" + DateTime.Now.ToString() + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendleft(string referid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_level WHERE [Left_Id]='" + referid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable lastleftmem()
    {
        try
        {
            string SQLQuery = "SELECT TOP 1 [Level_Id],[Left_Id],[Right_Id],[Refer_Id] FROM tbl_level where [Left_Id] !='' order by [Level_Id] desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updatepaidregistrationplacement(string placementid, string generate_userid)
    {
        try
        {

           /* string SQLQuery = "update tbl_registration_temporary set placementid = '" + placementid + "', status='1' where userid = '" + generate_userid + "' ";*/
            string SQLQuery = "USP_Bite2Byte_updatepaidregistrationplacement '" + placementid + "','" + generate_userid + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



   

    public void inserleftvalue(string referid)
    {
        try
        {

            string SQLQuery = "insert into tbl_level (Left_Id) values('" + referid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable checkplacement123(string placementid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  placementid='" + placementid + "' and placement = '1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendright(string referid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_level WHERE [Right_Id] ='" + referid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable lastRightmem()
    {
        try
        {
            string SQLQuery = "SELECT TOP 1 [Level_Id],[Left_Id],[Right_Id],[Refer_Id] FROM tbl_level where [Right_Id] !='' order by [Level_Id] desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertRightvalue(string referid)
    {
        try
        {

            string SQLQuery = "insert into tbl_level (Right_Id) values(" + referid + ")";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable checkplacementright(string placementid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  placementid='" + placementid + "' and placement = '2'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void deletenonmember(string nonmembr)
    {
        try
        {
            string sqlquery = "Delete from tbl_nonmemreg where mobileno='" + nonmembr + "'";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable producewalt(string auserid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  userid='" + auserid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectfree(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where  mobileno='" + mobile + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectnon(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where  mobileno='" + mobile + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void zdeletefreemember(string useridfree)
    {
        try
        {
            string SQLQuery = "Delete from tbl_freememreg where userid='" + useridfree + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable inviteefree(string useridfree)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where  inivted_user='" + useridfree + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updateinvitee(string inviteduser, string sno)
    {
        try
        {
            string SQLQuery = "update tbl_invitefriends set inivted_user = '" + inviteduser + "', invited_user_status='2',invited_date='" + DateTime.Now.ToString() + "' where sno = '" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}