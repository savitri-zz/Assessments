﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for DebitWallet
/// </summary>
public class DebitWallet : BaseClass
{
	public DebitWallet()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable Getmemregistrationsponceruserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDebitwallet1()
    {
        try
        {
            string SQLQuery = "select * from tbl_Debit_Wallet";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDebitwallet(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_Debit_Wallet where mobileno='" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertDebitwallet(string userid, string mobileno, string Amount, string Remarks, string Approval_Status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Debit_Wallet(userid, mobileno, Amount, Remarks,Approval_Status) values (" + userid + ",'" + mobileno + "','" + Amount + "', '" + Remarks + "','" + Approval_Status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable AdminLogin3(string admin_userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_admindetails where admin_userid='" + admin_userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 public void UpdateDebitwallet(string sno, string Remarks, string Amount)
    {
        try
        {
            string SQLQuery = "update tbl_Debit_Wallet set Remarks='" + Remarks + "', Amount='" + Amount + "' where sno='" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    

 public void DeleteDebitwallet(string sno)
    {
        try
        {
            string SQLQuery = "delete from tbl_Debit_Wallet where sno='" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}