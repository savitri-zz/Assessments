﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Net;

/// <summary>
/// Summary description for Productlink
/// </summary>
public class Productlink : BaseClass
{
    public Productlink()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable GetInterests(string userid)
    {
        try
        {
            string SQLQuery = "select checkeditem from tbl_editprofile where userid= '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable RetriveImageUrls(string userid)
    {
        try
        {
            string SQLQuery = "select * from productimages where interest in (" + userid + ")";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable RetriveInterests()
    {
        try
        {
            string SQLQuery = "select * from tbl_dynamicstatus";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Interest(string interest)
    {
        try
        {
            string SQLQuery = "select distinct interest from tbl_dynamicstatus where sno in (" + interest + ")";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void InsertProductinfo(string finalimage, string imageurl)
    {
        try
        {
            string SQLQuery = "insert into tbl_dgmadds(imageurl,productlink) values ('" + finalimage + "','" + imageurl + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetAdInformation(int iSNo)
    {

        try
        {
            string SQLQuery = "SELECT MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY, STATE, PATTERN, SENT_CRITERIA ";
            SQLQuery = SQLQuery + " FROM TBL_ADS_SMSPRODUCTS WHERE SNO = " + iSNo.ToString() + " AND VISIBILITY_STATUS= 'TRUE'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetAdCampaignPreparedData()
    {
        try
        {
            string sQry = "select SNO, USERID, EMAILID, USERNAME, AD_SNO, MID, AD_TITLE, AD_WEBSITE, AD_DESCRIPTION, AD_IMAGE, AD_URL_LINK, AD_ACTUAL_PRICE, AD_OFFER, PROCESSED_IMAGE_NAME , ";
            sQry = sQry + " AD_OFFER_PRICE, AD_STATE, AD_CATEGORY, PREPARED_DT, REFERAL_USERID, REFERAL_MOBILENO, REFERAL_NAME, IMAGE_BINARY_DATA, IS_MAIL_SENT, REFERAL_IMAGE_NAME , REFERAL_OCCUPATION , REFERAL_ADDRESS, DATA_POOLING_CRITERIA from dbo.TBL_EMAIL_CAMPAIGN_STAGING_DATA WHERE IS_MAIL_SENT = 0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    public DataTable GetAdCampaignPreparedDataForMailing()
    {
        try
        {
            string sQry = "select SNO, USERID, EMAILID, USERNAME, AD_SNO, MID, AD_TITLE, AD_WEBSITE, AD_DESCRIPTION, AD_IMAGE, AD_URL_LINK, AD_ACTUAL_PRICE, AD_OFFER, PROCESSED_IMAGE_NAME , ";
            sQry = sQry + " AD_OFFER_PRICE, AD_STATE, AD_CATEGORY, PREPARED_DT, REFERAL_USERID, REFERAL_MOBILENO, REFERAL_NAME, IMAGE_BINARY_DATA, IS_MAIL_SENT, REFERAL_IMAGE_NAME , REFERAL_OCCUPATION , REFERAL_ADDRESS, DATA_POOLING_CRITERIA from dbo.TBL_EMAIL_CAMPAIGN_STAGING_DATA WHERE IS_MAIL_SENT = 0 AND DATA_POOLING_CRITERIA != 'USER_CAMPAIGN' ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    public DataTable GetAdCampaignUserShare()
    {
        try
        {

            string sQry = "select SNO, USERID, EMAILID, USERNAME, AD_SNO, MID, AD_TITLE, AD_WEBSITE, AD_DESCRIPTION, AD_IMAGE, AD_URL_LINK, AD_ACTUAL_PRICE, AD_OFFER, PROCESSED_IMAGE_NAME , ";
            sQry = sQry + " AD_OFFER_PRICE, AD_STATE, AD_CATEGORY, PREPARED_DT, REFERAL_USERID, REFERAL_MOBILENO, REFERAL_NAME, IMAGE_BINARY_DATA, IS_MAIL_SENT, REFERAL_IMAGE_NAME , REFERAL_OCCUPATION , REFERAL_ADDRESS, DATA_POOLING_CRITERIA,USER_COMMENTS,ADDL_COL_1,ADDL_COL_2 from dbo.TBL_EMAIL_CAMPAIGN_STAGING_DATA WHERE IS_MAIL_SENT = 0 AND DATA_POOLING_CRITERIA = 'USER_CAMPAIGN' ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    public void UpdateProcessedImageInfo(int iSNo, string sImagePath)
    {

        try
        {
            string SQLQuery = "UPDATE TBL_ADS_SMSPRODUCTS SET PROCESSED_IMAGE_NAME = '" + sImagePath + "' WHERE SNO = '" + iSNo + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);

            SQLQuery = "";
            SQLQuery = "UPDATE TBL_EMAIL_CAMPAIGN_STAGING_DATA SET PROCESSED_IMAGE_NAME = TBL_ADS_SMSPRODUCTS.PROCESSED_IMAGE_NAME";
            SQLQuery = SQLQuery + " FROM TBL_ADS_SMSPRODUCTS WHERE TBL_EMAIL_CAMPAIGN_STAGING_DATA.AD_SNO = TBL_ADS_SMSPRODUCTS.SNO";
            SQLQuery = SQLQuery + " and ISNULL(TBL_EMAIL_CAMPAIGN_STAGING_DATA.PROCESSED_IMAGE_NAME , '') = '' ";
            intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    //**************************** Added By naidu ***************************************************
    // To update PROCESSED_IMAGE_NAME value in TBL_EMAIL_CAMPAIGN_STAGING_DATA table
    public void UpdateProcessedImageInfo_v2(int iSNo, string sImagePath)
    {

        try
        {
            string SQLQuery = "UPDATE TBL_EMAIL_CAMPAIGN_STAGING_DATA SET PROCESSED_IMAGE_NAME = '" + sImagePath + "' WHERE AD_SNO = '" + iSNo + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);

            //SQLQuery = "";
            //SQLQuery = "UPDATE TBL_EMAIL_CAMPAIGN_STAGING_DATA SET PROCESSED_IMAGE_NAME = TBL_ADS_SMSPRODUCTS.PROCESSED_IMAGE_NAME";
            //SQLQuery = SQLQuery + " FROM TBL_ADS_SMSPRODUCTS WHERE TBL_EMAIL_CAMPAIGN_STAGING_DATA.AD_SNO = TBL_ADS_SMSPRODUCTS.SNO";
            //SQLQuery = SQLQuery + " and ISNULL(TBL_EMAIL_CAMPAIGN_STAGING_DATA.PROCESSED_IMAGE_NAME , '') = '' ";
            //intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    // End
    public void PrepareEmailCampaignData(string sCriteria_Type, string sCriteria_Text)
    {
        try
        {
            string sQry = "Exec USP_PREPARE_DATA_FOR_EMAIL_CAMPAIGN '" + sCriteria_Type + "','" + sCriteria_Text + "'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception Ex)
        {

            throw Ex;
        }
    }
    public DataTable GetInvitationpreparedata(int EVENT_ID, string USER_CRITERIA, string STATE_ID, string DIST_ID)
    {
        try
        {

            string sQry = "Exec USP_ADMIN_GET_USERS_FOR_EVENT_INVITATIONS '" + EVENT_ID + "','" + USER_CRITERIA + "'" + STATE_ID + "','" + DIST_ID + "'";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetAdsFromPreparedData()
    {
        try
        {

            string sQry = "SELECT DISTINCT AD_SNO FROM DBO.TBL_EMAIL_CAMPAIGN_STAGING_DATA";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }


    }



    public DataTable GetEmailData(string sCriteriaType, string sCriteriaText)
    {
        try
        {
            //string sQry = "SELECT V2.NAME, V2.MOBILENO, V2.USERPWD, V2.USERID, V2.EMAILID, V2.REFERAL_MOBILE, (SELECT NAME FROM ALL_MEMBERS_VIEW V1 WHERE V1.USERID = V2.REFERALID) REFNAME, REFERALID ";
            //sQry = sQry + " FROM ALL_MEMBERS_VIEW V2 WHERE V2.ACTIVEUSER = 'NA' AND ";
            //sQry = sQry + " V2.USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE IN ('INVITATION MAIL BULK SENDING', 'INVITATION MAIL' ) ";
            //sQry = sQry + " AND DATEDIFF(DAY, SENT_TIME , GETDATE()) < 3 	)  ORDER BY V2.SNO ";

            string sQry = "SELECT V2.NAME, V2.MOBILENO, V2.USERPWD, V2.USERID, V2.EMAILID, V2.REFERAL_MOBILE, (SELECT NAME FROM ALL_MEMBERS_VIEW V1 WHERE V1.USERID = V2.REFERALID) REFNAME, REFERALID ";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V2 WHERE V2.ACTIVEUSER = 'NA'  ";

            if (sCriteriaType == "Days")
            {
                sQry = sQry + " AND V2.USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE IN ('INVITATION MAIL BULK SENDING', 'INVITATION MAIL' ) ";
                sQry = sQry + " AND DATEDIFF(DAY, SENT_TIME , GETDATE()) <  " + sCriteriaText.ToString() + " ) ";
            }
            else if (sCriteriaType == "User")
            {
                sQry = sQry + " AND V2.MOBILENO='" + sCriteriaText.ToString() + "'";
            }
            else
            {
                sQry = sQry + " AND V2.REFERAL_MOBILE= '" + sCriteriaText.ToString() + "'";
            }
            sQry = sQry + " ORDER BY V2.SNO ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    public DataTable GetLuckyDrawCampaignInactiveList()
    {
        try
        {
            //string sQry = "SELECT V2.NAME, V2.MOBILENO, V2.USERPWD, V2.USERID, V2.EMAILID, V2.REFERAL_MOBILE, (SELECT NAME FROM ALL_MEMBERS_VIEW V1 WHERE V1.USERID = V2.REFERALID) REFNAME, REFERALID ";
            //sQry = sQry + " FROM ALL_MEMBERS_VIEW V2 WHERE V2.ACTIVEUSER = 'NA' AND ";
            //sQry = sQry + " V2.USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE IN ('INVITATION MAIL BULK SENDING', 'INVITATION MAIL' ) ";
            //sQry = sQry + " AND DATEDIFF(DAY, SENT_TIME , GETDATE()) < 3 	)  ORDER BY V2.SNO ";

            string sQry = "SELECT  V2.NAME, V2.MOBILENO, V2.USERPWD, V2.USERID, V2.EMAILID, V2.REFERAL_MOBILE, (SELECT NAME FROM ALL_MEMBERS_VIEW V1 WHERE V1.USERID = V2.REFERALID) REFNAME, REFERALID , V2.ACTIVEUSER";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V2 WHERE (V2.ACTIVEUSER = 'NA' OR (V2.ACTIVEUSER = 'A' AND V2.IS_PROFILE_UPDATED = 0) )  ";
            sQry = sQry + " AND V2.USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE = 'LuckyDraw-01 Campaign' )";


            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    public DataTable GetDataForInformationSending()
    {
        try
        {
            string sQry = "SELECT V2.NAME, V2.MOBILENO, V2.USERPWD, V2.USERID, V2.EMAILID, V2.REFERAL_MOBILE, (SELECT NAME FROM ALL_MEMBERS_VIEW V1 WHERE V1.USERID = V2.REFERALID) REFNAME, REFERALID ";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V2 WHERE V2.USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE = 'INFORMATION SENDING'  )";
            sQry = sQry + " ORDER BY V2.SNO ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    public void insertEmailCampaignDetails(string sUid, string sAdid, string strRemoteHost, string strDateTime)
    {
        /*  ***********************************************         Start By Naidu          *****************************************************      */

        //   ---------------------------------   Insert Email Campaign Details along with time and ip address   ---------------------------------
        string sQry = "insert into TBL_EMAILCAMPAIGN_USER_AUDIT(USERID, AD_SNO , Host, Clicked_Date) VALUES ('" + sUid + "','" + sAdid + "','" + strRemoteHost + "','" + strDateTime + "')";
        int intRowAffect = fnExecuteNonQuery(sQry, true);
        // Table Update

    }


    public void EmailCampaignDataArchive()
    {
        try
        {
            string sQry = "EXEC DBO.USP_EMAIL_CAMPAIGN_DATA_ARCHIVE  ";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable GetAdInformation(string iSNo,string sUID)
    {

        try
        {
            //string SQLQuery = "SELECT ADS.SNO, ADS.MID, ADS.TITLE, ADS.WEBSITE, ADS.DESCRIPTION, ADS.IMAGE, ADS.URLLINK, ADS.ACTUAL_PRICE, ADS.OFFER, ADS.OFFER_PRICE, ADS.CATEGORY, ADS.STATE, ADS.PATTERN, ADS.SENT_CRITERIA,ADS.MERCHANT_IMAGE_URL, M.MERCHANT_DESCRIPTION ";
            //string SQLQuery = "SELECT ADS.SNO, ADS.MID, ADS.TITLE, ADS.WEBSITE, ADS.DESCRIPTION, ADS.IMAGE, REPLACE(ADS.URLLINK , 'mfloatanonymoususer','" + sUID + "') URLLINK, ADS.ACTUAL_PRICE, ADS.OFFER, ADS.OFFER_PRICE, ADS.CATEGORY, ADS.STATE, ADS.PATTERN, ADS.SENT_CRITERIA,ADS.MERCHANT_IMAGE_URL, M.MERCHANT_DESCRIPTION ";
            string SQLQuery = "SELECT ADS.SNO, ADS.MID, ADS.TITLE, ADS.WEBSITE, ADS.DESCRIPTION, ADS.IMAGE, REPLACE(REPLACE(ADS.URLLINK , 'mfloatanonymoususer','" + sUID + "') , 'k=[NETWORKID]', 'k="+ sUID +"') URLLINK, ADS.ACTUAL_PRICE, ADS.OFFER, ADS.OFFER_PRICE, ADS.CATEGORY, ADS.STATE, ADS.PATTERN, ADS.SENT_CRITERIA,ADS.MERCHANT_IMAGE_URL, M.MERCHANT_DESCRIPTION ";
            SQLQuery += ", isnull(z.ZoomStatus, 0) ZoomStatus FROM TBL_ADS_SMSPRODUCTS ADS INNER JOIN TBL_MRCHNT M ON M.MID=ADS.MID left outer join TBL_ZOOM_COLLECTIONS z on z.tablename = 'TBL_ADS_SMSPRODUCTS' and ADS.sno = z.columnid and z.userid = '" + sUID + "' WHERE ADS.SNO = '" + iSNo.ToString() + "' AND ADS.VISIBILITY_STATUS= 'TRUE'";


            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {

            throw Ex;
        }

    }
    public DataTable GetAdInformation(string iSNo)
    {
        try
        {
            string SQLQuery = "SELECT ADS.SNO, ADS.MID, ADS.TITLE, ADS.WEBSITE, ADS.DESCRIPTION, ADS.IMAGE, ADS.URLLINK, ADS.ACTUAL_PRICE, ADS.OFFER, ADS.OFFER_PRICE, ADS.CATEGORY, ADS.STATE, ADS.PATTERN, ADS.SENT_CRITERIA,ADS.MERCHANT_IMAGE_URL, M.MERCHANT_DESCRIPTION ";
            SQLQuery += "FROM TBL_ADS_SMSPRODUCTS ADS INNER JOIN TBL_MRCHNT M ON M.MID=ADS.MID WHERE ADS.SNO = '" + iSNo.ToString() + "' AND ADS.VISIBILITY_STATUS= 'TRUE'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    // ---------------------------  Modified By Ganga  -----------------------------
    //   Purpose: Retrieving related categories Ads information based on sno
    public DataTable getAdInformation_ByCategory(string sSNo)
    {
        try
        {
            string SQLQuery = "SELECT SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY, STATE, PATTERN, SENT_CRITERIA,MERCHANT_IMAGE_URL ";
            SQLQuery = SQLQuery + " FROM TBL_ADS_SMSPRODUCTS WHERE CATEGORY IN(SELECT CATEGORY FROM TBL_ADS_SMSPRODUCTS WHERE SNO=" + sSNo.ToString() + " AND VISIBILITY_STATUS=1 ) and visibility_status='1' ORDER BY NEWID()";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    // Purpose:  Checking user is already liked the image or not if not then insert the record otherwise ignore it

    public void insert_Ads_User_Likes(string sUid, string sAdno)
    {
        string sQry = "Exec sp_insert_ADS_USER_LIKES '" + sUid + "','" + sAdno + "'";
        int intRowAffect = fnExecuteNonQuery(sQry, true);
    }
    //  Retreiving Similar Ads and Liked date and likes counter based on Product category number
    public DataTable getRelatedAdInformation_ByCategory(string scategory_no)
    {
        try
        {
            System.Text.StringBuilder SQLQuery = new System.Text.StringBuilder();
            SQLQuery.Append("SELECT top 50 DFL.sno, DFL.CTR AD_LIKES_CTR , ISNULL( CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) , '')LIKED_MAX_DT_106 , S.IMAGE, S.SNO,");
            SQLQuery.Append("S.WEBSITE, S.DESCRIPTION, S.TITLE, s.category  , s.Offer_price  FROM TBL_ADS_SMSPRODUCTS S ");
            SQLQuery.Append("INNER  JOIN (select s.sno, COUNT(l.AD_SRL_NO) ctr, MAX(LIKED_DT) LIKED_MAX_DT from tbl_ads_smsproducts s ");
            SQLQuery.Append("left outer join TBL_ADS_USER_LIKES l on s.sno = l.AD_SRL_NO ");
            SQLQuery.Append("where category in (select L2_CATEGORY_ID  from TBL_INTEREST_LEVEL_2 ");
            SQLQuery.Append("where L1_CATEGORY_SNO = '" + scategory_no + "')group by s.sno) AS DFL ON S.SNO = DFL.sno ");
            SQLQuery.Append("WHERE S.VISIBILITY_STATUS = 1 AND S.CATEGORY LIKE '" + scategory_no + "-%' order by newid() ");
            return GetDataTable(SQLQuery.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getRelatedAdInformation_ByCategory(string scategory_no, string sUid)
    {
        try
        {
            System.Text.StringBuilder SQLQuery = new System.Text.StringBuilder();
            SQLQuery.Append("SELECT top 50 DFL.sno, DFL.CTR AD_LIKES_CTR , ISNULL( CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) , '') LIKED_MAX_DT_106 , S.IMAGE, S.SNO,S.WEBSITE, S.DESCRIPTION, S.TITLE, s.category  , s.Offer_price, isnull(z.ZoomStatus, 0) ZoomStatus ");
            SQLQuery.Append("FROM TBL_ADS_SMSPRODUCTS S INNER  JOIN (select s.sno, COUNT(l.AD_SRL_NO) ctr, MAX(LIKED_DT) LIKED_MAX_DT ");
            SQLQuery.Append("from tbl_ads_smsproducts s Left outer join TBL_ADS_USER_LIKES l on s.sno = l.AD_SRL_NO ");
            SQLQuery.Append("where category in (select L2_CATEGORY_ID  from TBL_INTEREST_LEVEL_2 where L1_CATEGORY_SNO = '1')");
            SQLQuery.Append("group by s.sno) AS DFL ON S.SNO = DFL.sno ");
            SQLQuery.Append("left outer join TBL_ZOOM_COLLECTIONS z on z.tablename = 'TBL_ADS_SMSPRODUCTS' and s.sno = z.columnid and z.userid = '" + sUid + "'");
            SQLQuery.Append("WHERE S.VISIBILITY_STATUS = 1 AND S.CATEGORY LIKE '1-%' order by newid() ");
            return GetDataTable(SQLQuery.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //  Purpose:  Retreiving Recently Liked Ads
    public DataTable get_Recently_LikedAds(string sUid)
    {
        try
        {
            // string SQLQuery = "SELECT * FROM TBL_ADS_SMSPRODUCTS ADS ";
            // SQLQuery += "JOIN TBL_ADS_USER_LIKES LIKES ON ADS.SNO= LIKES.AD_SRL_NO WHERE LIKES.USER_ID='" + sUid + "' AND ADS.VISIBILITY_STATUS='TRUE' ORDER BY LIKES.LIKED_DT DESC";
            System.Text.StringBuilder SQLQuery = new System.Text.StringBuilder();
            SQLQuery.Append("SELECT DFL.CTR AD_LIKES_CTR , CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) LIKED_MAX_DT_106,DFL.AD_SRL_NO,S.IMAGE,S.SNO,S.WEBSITE,S.DESCRIPTION,S.TITLE , S.OFFER_PRICE,S.MERCHANT_IMAGE_URL,S.urllink  FROM TBL_ADS_SMSPRODUCTS S ");
            SQLQuery.Append(" INNER  JOIN (SELECT ROW_NUMBER() OVER (ORDER BY MAX(LIKED_DT) DESC) AS A, AD_SRL_NO , MAX(LIKED_DT) LIKED_MAX_DT, COUNT(AD_SRL_NO) CTR");
            SQLQuery.Append(" FROM  TBL_ADS_USER_LIKES WHERE USER_ID = '" + sUid + "' ");
            SQLQuery.Append(" GROUP BY AD_SRL_NO) AS DFL ON S.SNO = DFL.AD_SRL_NO");
            SQLQuery.Append(" WHERE S.VISIBILITY_STATUS = 1 ORDER BY DFL.A");
            return GetDataTable(SQLQuery.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable get_Recently_LikedAds(string sUid, string AdCategory)
    {
        try
        {
            System.Text.StringBuilder SQLQuery = new System.Text.StringBuilder();

            SQLQuery.Append(" SELECT TOP 10 AD_LIKES_CTR, LIKED_MAX_DT_106, AD_SRL_NO, IMAGE, SNO, WEBSITE, DESCRIPTION, TITLE ");
            SQLQuery.Append(" FROM ");
            SQLQuery.Append(" (SELECT 1 PRIORITY, DFL.A ROW_NUM, DFL.CTR AD_LIKES_CTR , CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) LIKED_MAX_DT_106,DFL.AD_SRL_NO,S.IMAGE,S.SNO,S.WEBSITE,S.DESCRIPTION,S.TITLE ");
            SQLQuery.Append(" FROM TBL_ADS_SMSPRODUCTS S  ");
            SQLQuery.Append(" INNER  JOIN (SELECT ROW_NUMBER() OVER (ORDER BY MAX(LIKED_DT) DESC) AS A, AD_SRL_NO , MAX(LIKED_DT) LIKED_MAX_DT, COUNT(AD_SRL_NO) CTR ");
            SQLQuery.Append(" 		FROM  TBL_ADS_USER_LIKES WHERE USER_ID = '" + sUid + "'  GROUP BY AD_SRL_NO) AS DFL ON S.SNO = DFL.AD_SRL_NO ");
            SQLQuery.Append("       WHERE S.VISIBILITY_STATUS = 1 AND CATEGORY IN (SELECT L2_CATEGORY_ID FROM TBL_INTEREST_LEVEL_2  WHERE L1_CATEGORY_SNO = '" + AdCategory + "')");
            SQLQuery.Append("       UNION ");
            SQLQuery.Append(" SELECT 2 PRIOTY, DFL.A ROW_NUM, DFL.CTR AD_LIKES_CTR , CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) LIKED_MAX_DT_106,DFL.AD_SRL_NO,S.IMAGE,S.SNO,S.WEBSITE,S.DESCRIPTION,S.TITLE ");
            SQLQuery.Append(" FROM TBL_ADS_SMSPRODUCTS S  ");
            SQLQuery.Append(" INNER  JOIN (SELECT ROW_NUMBER() OVER (ORDER BY MAX(LIKED_DT) DESC) AS A, AD_SRL_NO , MAX(LIKED_DT) LIKED_MAX_DT, COUNT(AD_SRL_NO) CTR ");
            SQLQuery.Append(" FROM  TBL_ADS_USER_LIKES WHERE USER_ID = '" + sUid + "'  GROUP BY AD_SRL_NO) AS DFL ON S.SNO = DFL.AD_SRL_NO ");
            SQLQuery.Append(" WHERE S.VISIBILITY_STATUS = 1 AND CATEGORY NOT IN (SELECT L2_CATEGORY_ID FROM TBL_INTEREST_LEVEL_2  WHERE L1_CATEGORY_SNO = '" + AdCategory + "')");
            SQLQuery.Append(" ) AS DFL2");
            SQLQuery.Append(" ORDER BY DFL2.PRIORITY, DFL2.ROW_NUM");

            return GetDataTable(SQLQuery.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    // -------------------------  End   By Ganga --------------------
    // -------------------------    By Savitri --------------------

    public void insert_Ads_User_clicks(string sUid, string sAdno, string Purpose)
    {
        string sQry = "Exec sp_insert_ADS_USER_CLICKS '" + sUid + "','" + sAdno + "','" + Purpose + "','" + HttpContext.Current.Request.Url.AbsoluteUri + "'";
        int intRowAffect = fnExecuteNonQuery(sQry, true);
    }
    public DataTable GetLikedCategoryByUserID(String UserID)
    {
        try
        {
            string SQLQuery = "SELECT DISTINCT L1.L1_CATEGORY_NAME LIKEDCATEGORY,l1.SNO CATEGORYID  FROM TBL_ADS_USER_LIKES L ";
            SQLQuery += " INNER JOIN TBL_ADS_SMSPRODUCTS A ON L.AD_SRL_NO=A.SNO ";
            SQLQuery += " INNER JOIN TBL_INTEREST_LEVEL_2 L2 ON L2.L2_CATEGORY_ID=A.CATEGORY ";
            SQLQuery += " INNER JOIN TBL_INTEREST_LEVEL_1 L1 ON L1.SNO=L2.L1_CATEGORY_SNO ";
            SQLQuery += "WHERE L.USER_ID='" + UserID + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetNetworkUserDetailsByInterestCategory(string sUserID, string sCateogryID)
    {
        try
        {
            string sQry = "select i.userid, i.mobileno, i.emailid, i.fname, m.imagename from tbl_invitefriends i ";
            sQry = sQry + " inner join tbl_imagedetail m on i.userid = m.userid AND i.userid in (SELECT userid FROM FN_USER_TREE_ACTIVE_NETWORK_MEMBERS_FROM_ACTIVE('" + sUserID + "')) ";
            sQry = sQry + " where charindex(',' + '" + sCateogryID + "' + ',' , ',' + i.checkeditem + ',') > 0";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetNetworkUserDetailsByInterestCategory(string sUserID, string sCateogryID, int count)
    {
        //string sQry = "select top " + count + " i.userid, i.mobileno, i.emailid, i.fname, m.imagename from tbl_invitefriends i ";
        //sQry = sQry + " inner join tbl_imagedetail m on i.userid = m.userid AND i.userid in (SELECT top " + count + " userid FROM FN_USER_TREE_ALL_NETWORK_MEMBERS_USERIDS_ONLY('" + sUserID + "','A')) ";
        //sQry = sQry + " and  charindex(',' + '" + sCateogryID + "' + ',' , ',' + i.checkeditem + ',') > 0";

        //string sQry = "SELECT top " + count + " userid, mobileno, emailid, fullname as fname, image  as imagename FROM FN_USER_TREE_ACTIVE_NETWORK_MEMBERS_FROM_ACTIVE('" + sUserID + "')";
        //sQry = sQry + " where USERID in (select USERID from tbl_invitefriends where charindex(',' + '" + sCateogryID + "' + ',' , ',' + checkeditem + ',') > 0) and mobileno != ''";
        string sQry = "SELECT TOP " + count + " F.USERID, F.MOBILENO, F.EMAILID, F.FULLNAME AS FNAME, IMAGE  AS IMAGENAME , C.CITY_NAME, O.OCCUPATION ";
        sQry = sQry + "FROM FN_USER_TREE_ACTIVE_NETWORK_MEMBERS_FROM_ACTIVE('" + sUserID + "') F ";
        sQry = sQry + "INNER JOIN TBL_ACTIVE_USERS A ON F.USERID = A.USERID AND  CHARINDEX(',' + '" + sCateogryID + "' + ',' , ',' + CHECKEDITEM + ',') > 0 ";
        sQry = sQry + "INNER JOIN TBL_OCCUPATION O ON O.ID = A.OCCUPATION ";
        sQry = sQry + "INNER JOIN CITIES C ON C.CITY_ID = A.CITY";

        return GetDataTable(sQry, true);
    }

    public void InsertProductSharing(string sMasterCategory, string sKeyValue, string sUserID, string sSharedTO, string sCustomUsers, bool bIsZoomShared)
    {
        try
        {

            EncryptDecryptQueryString ClsEncrypt = new EncryptDecryptQueryString();
            string sEncryptedUserID = ClsEncrypt.Encrypt(sUserID, "r0b1nr0y");

            string[] strArrList = { "@MASTER_CATEGORY", "@KEY_VALUE", "@USERID", "@SHARED_TO", "@CUSTOMER_USERS", "@IS_ZOOM_SHARED", "@ENCRYPTED_USERID" };
            string[] strArrValues = { sMasterCategory, sKeyValue, sUserID, sSharedTO, sCustomUsers, (bIsZoomShared == true ? "1" : "0"), sEncryptedUserID };
            int intRowAffect = fnRunProcedure("USP_PRODUCT_SHARING", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public string sReplaceUrl(string sUrl, string sPurpose)
    {
        try
        {
            string sRetUrl = "";
            string sQry = "SELECT dbo.FN_REPLACE_URL('"+ sUrl +"' , '"+ sPurpose +"') URL";
            DataTable dt = new DataTable();
            dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                sRetUrl = dt.Rows[0]["URL"].ToString();
            }
            return sRetUrl;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public void InsertDataSharingClicks(string sRefNo, string sClickedBy, string sClickedFrom, string sSharedBy)
    {
        try
        {
            General clsGen = new General();
            home clsHome = new home();
            string sIP = clsHome.GetUser_IP();
            string sQry = "";
            sQry = "INSERT INTO TBL_PRODUCT_SHARING_CLICKS(REF_NO, CLICKED_ON, CLICKED_IP, CLICKED_BY, CLICKED_FROM, UPLINE_AFFILIATE, SHARED_BY_USERID) ";
            sQry = sQry + "VALUES('" + sRefNo + "', GETDATE(), '" + sIP + "', '" + sClickedBy + "', '" + sClickedFrom + "',dbo.FN_GET_IMMEDIATE_APPLAINER('" + sClickedBy + "') , '" + sSharedBy + "' )";

            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public DataTable GetSharedProductData(string sUserID, string sMasterCategory, string sKeyValue, string sSharedTo)
    {
        try
        {
            string sQry = "SELECT  SNO, MASTER_CATEGORY, SUB_CATEGORY, KEY_VALUE, USERID, SHARED_TO, CUSTOM_USERS, SHARED_DATETIME,";
            sQry = sQry + " IS_ZOOM_SHARED, URL, UPLINE_AFFILIATE_USERID, SHARING_TO_SOCIAL_NETWORK, IS_MAIL_CAMPAIGN_PROCESSED";
            sQry = sQry + " FROM TBL_PRODUCT_SHARING WHERE USERID = '"+ sUserID +"' AND MASTER_CATEGORY = '"+ sMasterCategory +"' AND KEY_VALUE = '"+ sKeyValue +"' AND SHARED_TO = '"+ sSharedTo +"'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
        
    }

    public DataTable GetPreviousSharedProductsCount(string sUserID, string sMasterCategory, string sKeyValue, int iConfigLimiDays )
    {
        try
        {
            string sQry = "SELECT COUNT(DISTINCT MASTER_CATEGORY +'$$'+ KEY_VALUE) CTR FROM TBL_PRODUCT_SHARING WHERE USERID = '"+ sUserID  +"' AND MASTER_CATEGORY = '"+ sMasterCategory +"' AND KEY_VALUE = '"+ sKeyValue +"'";
            sQry = sQry + " AND SHARED_DATETIME > DATEADD(HOUR, "+ iConfigLimiDays +" * 24 * -1 , GETDATE())";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }
    public void InsertUserSharingInfo(string saleSrNo, string Criteria, string comment, string sUrl, string customEmail)
    {
        try
        {
          
                string sQry = "insert into TBL_SALES_USER_CAMPAIGN (SALE_SRL_NO,CRITERIA,CUSTOM_EMAIL,USER_COMMENTS,CAMPAIGN_URL) ";
                sQry = sQry + " values ('" + saleSrNo + "','" + Criteria + "','" + customEmail + "','" + comment + "','" + sUrl + "') ";
                int intRowAffect = fnExecuteNonQuery(sQry, true);
            


        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    /* Added by Naidu 
      to get sales data
    */
    public DataTable sGetSalesMasterData()
    {

        try
        {
            string SQLQuery = "select SNO, AD_SRL_NO, SALE_DATE, SALE_USERID, ";
            SQLQuery = SQLQuery + " SALE_PRODUCT_NAME, MERCHANT_CATEGORY, ";
            SQLQuery = SQLQuery + " PRODUCT_PRICE, QUANTITY, SALE_PRICE, ";
            SQLQuery = SQLQuery + " COMMISSION_PRERCENT, ADDITIONAL_FEES, IS_MAIL_SENT ";
            SQLQuery = SQLQuery + " from TBL_SALES_MASTER where IS_MAIL_SENT = 0 ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    /* Added by Naidu 
       update thanks mail sending status to user who purchased product
     */
    public void UpdateSharedLog(string sCampaignSno)
    {

        try
        {
            string SQLQuery = "UPDATE TBL_SALES_MASTER SET IS_MAIL_SENT = 1 where sno= " + sCampaignSno;
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getDataforSharing()
    {
        try
        {
            string SQLQuery = "select * from TBL_SALES_USER_CAMPAIGN where IS_PROCESSED= 0";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        
    }
    public void prepareDataforSharing(string adId)
    {
        try
        {
            //exec USP_PREPARE_DATA_FOR_EMAIL_CAMPAIGN 'USER_CAMPAIGN','1'
            string sQry = "exec USP_PREPARE_DATA_FOR_EMAIL_CAMPAIGN 'USER_CAMPAIGN','" + adId + "'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
           
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    //Over Loading method added by Naidu to insert sharing details
    public void InsertDataSharingClicks(string sRefNo, string sClickedBy, string sClickedFrom)
    {
        try
        {
            General clsGen = new General();
            home clsHome = new home();
            string sIP = clsHome.GetUser_IP();
            string sQry = "";
            sQry = "INSERT INTO TBL_PRODUCT_SHARING_CLICKS(REF_NO, CLICKED_ON, CLICKED_IP, CLICKED_BY, CLICKED_FROM, UPLINE_AFFILIATE,  DESCRIPTION ) ";
            sQry = sQry + "VALUES('" + Convert.ToInt32(sRefNo) + "', GETDATE(), '" + sIP + "', '" + sClickedBy + "', '" + sClickedFrom + "',dbo.FN_GET_IMMEDIATE_APPLAINER('" + sClickedBy + "') , 'Purchased user clicked for sharing' )";

            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateEmailSentStatus(string iSNo)
    {

        try
        {
            string SQLQuery = "UPDATE TBL_EMAIL_CAMPAIGN_STAGING_DATA SET IS_MAIL_SENT = 1 WHERE SNO = '" + iSNo + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
                      
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

}