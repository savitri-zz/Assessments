﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
/// <summary>
/// Summary description for PayoutSummary
/// </summary>
public class PayoutSummary : BaseClass
{
	public PayoutSummary()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getSummaryDates()
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_payoutsummary order by sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getbianrydata( string uid)
    {
        try
        {

            string SQLQuery = "select *  from tbl_Binarypayoutdetails  where userid='" + uid + "' order by CAST(PayoutDate as date) desc";
            return GetDataTable(SQLQuery, true);
        }
        catch( Exception ex)
        {
            throw ex;
        }
    
    }
    public DataTable getfromdate(string userid,string date)
    {
        try
        {

            string SQLQuery = "SELECT s.Fromdate,s.Todate FROM tbl_Binarypayoutdetails p INNER JOIN tbl_ReferalInfo1 s ON p.Payoutdate = s.Payoutdate WHERE p.userid ='" + userid + "' and p.Payoutdate='" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable spotbouns(string uid)
    {
        try
        {
            string SQLQuery = "select  * from tbl_Data_SpotBonusAmt where userid='" + uid + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable getreferalfromdate(string userid, string date)
    {
        try
        {

            string SQLQuery = "SELECT s.Fromdate,s.Todate, p.Refmem,p.BV,p.BonusBV,p.TotalBV,p.Totamt FROM tbl_ReferalInfo p INNER JOIN tbl_ReferalInfo1 s ON p.Payoutdate = s.Payoutdate WHERE p.userid ='" + userid + "' and p.Payoutdate='" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable getbianrydate1()
    {
        try
        {

            string SQLQuery = "select TOP 5*  from tbl_user_payout_generation where status='B'  order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable getbianrydatePayout(string date)
    {
        try
        {

            string SQLQuery = "select TOP 5*  from tbl_user_payout_generation where status='B' and CAST(generate_dates as DATE) =  '" + date + "'  order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

   

    public DataTable getreferaldate()
    {
        try
        {

            string SQLQuery = "select TOP 5 *  from tbl_user_payout_generation where status='R'  order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable getdataincentivedate()
    {
        try
        {

            string SQLQuery = "select TOP 10* from tbl_user_payout_generation where status='D'  order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable getreferalbvs(string userid)
    {
        try
        {

            string SQLQuery = "SELECT * FROM tbl_Referalpayoutdetails p INNER JOIN tbl_ReferalInfo s ON p.userid = s.userid WHERE p.userid ='" + userid + "'  ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable getdatapayoutdates(string days)
    {
        try
        {

            string SQLQuery = "select TOP " + days + " * from tbl_user_data_payout where status='D'  order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable referalpayouts( string userid)
    {
        try
        {

            string SQLQuery = "select *  from tbl_Referalpayoutdetails where userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable SummaryPayoutGeneration()
    {
        try
        {

            string SQLQuery = "SELECT * FROM (SELECT DISTINCT generate_dates, status FROM tbl_user_payout_generation) AS tbl_user_payout_generation order by generate_dates desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public DataTable dataincentiveamount(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Datapayoutdetails where userid='" + userid + "' order by sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable bainryincentiveamount(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable CheckPayoutDetailsdata(string status)
    {
        try
        {

            string SQLQuery = "select * from tbl_user_data_payout where status='" + status + "' order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public DataTable getProductType(string userid)
    {
        try
        {

            string SQLQuery = "select *  from tbl_registration where userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public void insertdatapayout(string payout_dates, string generate_dates, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_user_data_payout (payout_dates,generate_dates,status) values ('" + payout_dates + "','" + generate_dates + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    

   

    public DataTable referal(string userid)
    {
        try
        {
            string SQLQuery = "select  * from tbl_Referalpayoutdetails where userid='" + userid + "' order by sno desc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable Totalearningsdata(string userid)
    {
        try
        {
            string SQLQuery = "select sum(CAST(Numofinvitations as float))as Numofinvitations,sum(CAST(Elgpoints as float))as Elgpoints,sum(CAST(totalpoints as float))as totalpoints,sum(CAST(totalamt as float))as totalamt from tbl_Datapayoutdetails where userid='" + userid + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable Totalearningsbianry(string userid)
    {
        try
        {
            string SQLQuery = "select  sum(CAST(PW as float))as PW, sum(CAST(DeductionAmt as float))as DeductionAmt, sum(CAST(BeforeDeductionNetAmt as float))as BeforeDeductionNetAmt,sum(CAST(PayabeAmt as float))as PayabeAmt from tbl_Binarypayoutdetails where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable Totalearningsreferal(string userid)
    {
        try
        {
            string SQLQuery = "select sum(CAST(Actualamt as float))as Actualamt, sum(CAST(PW as float))as PW, sum(CAST(Balance as float))as Balance,sum(CAST(Deductions as float))as Deductions from tbl_Referalpayoutdetails where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable bankwalletamount(string userid)
    {
        try
        {
            string SQLQuery = "SELECT (sum(CAST(ref.Balance as float))+ sum(CAST(bin.Balance as float))+ sum(CAST(data.Balance as float)))as bankwallet FROM  tbl_Referalpayoutdetails ref , tbl_Binarypayoutdetails  bin,tbl_Datapayoutdetails data";
            SQLQuery += " where ref.userid=bin.userid  and ref.userid=data.userid and ref.userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable inproductwallet(string userid)
    {
        try
        {
            string SQLQuery = "SELECT (sum(CAST(ref.PW as float))+ sum(CAST(bin.PW as float))+ sum(CAST(data.PW as float)))as Productwallet FROM tbl_Referalpayoutdetails ref , tbl_Binarypayoutdetails bin, tbl_Datapayoutdetails data";
            SQLQuery += "  where ref.userid=bin.userid  and ref.userid=data.userid and ref.userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable intds(string userid)
    {
        try
        {
            string SQLQuery = "SELECT (sum(CAST(ref.TDS as float))+ sum(CAST(bin.TDS as float))+sum(CAST(data.TDS as float)))as tds FROM tbl_Referalpayoutdetails ref , tbl_Binarypayoutdetails bin,tbl_Datapayoutdetails data";
            SQLQuery += "  where ref.userid=bin.userid  and ref.userid=data.userid and ref.userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable zdtGetInvitationBonusPoints(string sUserID)
    {
        try
        {
            string sQry = "SELECT ROW_NUMBER() OVER(ORDER BY ACTIVATION_DATE) SNO, NAME, MOBILENO,  CONVERT(VARCHAR(30), ACTIVATION_DATE, 105) ACTIVATION_DATE, ";
	        sQry = sQry + " CASE WHEN (ROW_NUMBER() OVER(ORDER BY ACTIVATION_DATE)) <= 20  THEN 2 ";
		    sQry = sQry + " WHEN (ROW_NUMBER() OVER(ORDER BY ACTIVATION_DATE)) > 20 AND (ROW_NUMBER() OVER(ORDER BY ACTIVATION_DATE)) < 100 THEN 4 ELSE 0  END BONUS_POINTS ";
            sQry = sQry + " FROM (SELECT NAME, MOBILENO, ISNULL(ACTIVATION_DATE, JOINDATE) ACTIVATION_DATE  ";
		    sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE REFERAL_MOBILE = '"+ sUserID +"' AND ACTIVEUSER = 'A' ) AS DFL";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw;
        }
    }

    public DataTable dtGetInvitationBonusPoints(string sUserID,string Criteria)
    {
        try
        {
            string sQry = "EXEC dbo.USP_GET_FREE_WALLET_DATA '" + sUserID + "', '" + Criteria + "'";
    
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }
}