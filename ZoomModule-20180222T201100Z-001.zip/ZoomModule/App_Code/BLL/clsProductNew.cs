﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for clsProductNew
/// </summary>
public class clsProductNew:BaseClass
{
	public clsProductNew()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetProducts()
    {
        try
        {
            string sqlquery = "Select * from tbl_Products_New order by sno asc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetEditProduct(string sno)
    {
        try
        {
            string sqlquery = "Select * from tbl_Products_New where sno = '" + sno.ToString() + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void UpadteProduct(string mrp,string BV, string Points,string Pindelear_charges,string tax,string otherServices_Charge
           ,string point_value,string DP_DelearPrice,string SMS_SetupCost,string SMS_SetupCost_percentage,string Net_Amount,string DevelopMentCharges
           ,string DevelopMentCharges_percentage,string Balance,string Binary_CV,string Unilevel_CV,string Network_Sharing,string Bit2byte_profit, string sno)
    {
        try
        {
            string SQLQuery = " update tbl_Products_New set mrp='" + mrp + "' ,BV='" + BV + "' , Points='" + Points + "' ,Pindelear_charges='" + Pindelear_charges + "' ,tax='" + tax + "', ";
            SQLQuery = SQLQuery + " otherServices_Charge='" + otherServices_Charge + "',point_value='" + point_value + "',DP_DelearPrice='" + DP_DelearPrice + "', ";
            SQLQuery = SQLQuery + " SMS_SetupCost='" + SMS_SetupCost + "',SMS_SetupCost_percentage='" + SMS_SetupCost_percentage + "', Net_Amount='" + Net_Amount + "', ";
            SQLQuery = SQLQuery + " DevelopMentCharges='" + DevelopMentCharges + "', DevelopMentCharges_percentage='" + DevelopMentCharges_percentage + "', ";
            SQLQuery = SQLQuery + " Balance='" + Balance + "', Binary_CV='" + Binary_CV + "', Unilevel_CV='" + Unilevel_CV + "', Network_Sharing='" + Network_Sharing + "', ";
            SQLQuery = SQLQuery + " Bit2byte_profit='" + Bit2byte_profit + "' where sno='" + sno + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


}