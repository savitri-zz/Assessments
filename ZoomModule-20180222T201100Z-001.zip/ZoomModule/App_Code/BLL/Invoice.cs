﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


public class Invoice:BaseClass
{
	public Invoice()
	{
		
	}

    public DataTable getInvoiceDetails( string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where  userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getStateCity(string stateid, string cityid)
    {
        try
        {
            string SQLQuery = "SELECT s.states, c.cityname FROM dbo.tbl_indianstates s CROSS JOIN dbo.tbl_cities c where s.id='" + stateid + "' and c.cityid='" + cityid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getProductDetails(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno= '" + productid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getProductDetails1(string productid)
    {
        try
        {
            string SQLQuery = "SELECT round(cast(mrp as decimal),0) as mrp FROM tbl_Products where sno= '" + productid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable upgradeuserid(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_updatereg where userid= '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}