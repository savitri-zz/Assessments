using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for AdminFooter
/// </summary>
public class entProduct
{
    public entProduct()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private string _productname = "";
    private string _code;
    private string _cost = "";
    private string _tax = "";
    private string _total = "";
    private string _data = "";
    private string _bonus = "";
    private string _data1 = "";
    private string _bonus1 = "";
    private string _product = "";
    private string _BV = "";
    private string _bv1 = "";
    private string _sms = "";
    private string _point = "";
    private string _ceiling = "";
    private string _status = "";



    public string productname
    {
        get
        {
            return _productname;
        }
        set
        {
            _productname = value;
        }
    }

    public string code
    {
        get
        {
            return _code;
        }
        set
        {
            _code = value;
        }
    }


    public string cost
    {
        get
        {
            return _cost;
        }
        set
        {
            _cost = value;
        }
    }

    public string tax
    {
        get
        {
            return _tax;
        }
        set
        {
            _tax = value;
        }
    }

    public string total
    {
        get
        {
            return _total;
        }
        set
        {
            _total = value;
        }
    }

    public string data
    {
        get
        {
            return _data;
        }
        set
        {
            _data = value;
        }
    }

    public string bonus
    {
        get
        {
            return _bonus;
        }
        set
        {
            _bonus = value;
        }
    }

    public string data1
    {
        get
        {
            return _data1;
        }
        set
        {
            _data1 = value;
        }
    }

    public string bonus1
    {
        get
        {
            return _bonus1;
        }
        set
        {
            _bonus1 = value;
        }
    }

    public string product
    {
        get
        {
            return _product;
        }
        set
        {
            _product = value;
        }
    }

    public string BV
    {
        get
        {
            return _BV;
        }
        set
        {
            _BV = value;
        }
    }

    public string bv1
    {
        get
        {
            return _bv1;
        }
        set
        {
            _bv1 = value;
        }
    }

    public string sms
    {
        get
        {
            return _sms;
        }
        set
        {
            _sms = value;
        }
    }

    public string point
    {
        get
        {
            return _point;
        }
        set
        {
            _point = value;
        }
    }

    public string ceiling
    {
        get
        {
            return _ceiling;
        }
        set
        {
            _ceiling = value;
        }
    }

    public string status
    {
        get
        {
            return _status;
        }
        set
        {
            _status = value;
        }
    }     
   
}
