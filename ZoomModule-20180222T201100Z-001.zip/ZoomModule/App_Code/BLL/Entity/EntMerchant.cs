﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Entmerchant
/// </summary>
public class EntMerchant
{
    private string merchantName;
    private string merchantID;
    private string merchantDesc;
    private int statusID;
    private DateTime createdDate;
    private DateTime updatedDate;
    private string merchantUrl;

    public string MerchantUrl
    {
        get { return merchantUrl; }
        set { merchantUrl = value; }
    }

    public string MerchantName
    {
        get { return merchantName; }
        set { merchantName = value; }
    }

    public string MerchantID
    {
        get { return merchantID; }
        set { merchantID = value; }
    }

    public string MerchantDesc
    {
        get { return merchantDesc; }
        set { merchantDesc = value; }
    }

    public int StatusID
    {
        get { return statusID; }
        set { statusID = value; }
    }

    public DateTime CreatedDate
    {
        get { return createdDate; }
        set { createdDate = value; }
    }

    public DateTime UpdatedDate
    {
        get { return updatedDate; }
        set { updatedDate = value; }
    }



    public EntMerchant()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}