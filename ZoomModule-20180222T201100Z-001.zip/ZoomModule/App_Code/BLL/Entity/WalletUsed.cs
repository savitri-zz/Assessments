﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for WalletUsed
/// </summary>
public class WalletUsed
{
    private string uSER_ID;

    public string USER_ID
    {
        get { return uSER_ID; }
        set { uSER_ID = value; }
    }
    private string mOBILE;

    public string MOBILE
    {
        get { return mOBILE; }
        set { mOBILE = value; }
    }
    private string nAME;

    public string NAME
    {
        get { return nAME; }
        set { nAME = value; }
    }

    private string aMT;

    public string AMT
    {
        get { return aMT; }
        set { aMT = value; }
    }
    private string dATE;

    public string DATE
    {
        get { return dATE; }
        set { dATE = value; }
    }
    private string sTATUS;

    public string STATUS
    {
        get { return sTATUS; }
        set { sTATUS = value; }
    }
    private string tRANSACTION_ID;

    public string TRANSACTION_ID
    {
        get { return tRANSACTION_ID; }
        set { tRANSACTION_ID = value; }
    }
    private string dESCRIPTION;

    public string DESCRIPTION
    {
        get { return dESCRIPTION; }
        set { dESCRIPTION = value; }
    }
    private string aCCOUNT_NO;

    public string ACCOUNT_NO
    {
        get { return aCCOUNT_NO; }
        set { aCCOUNT_NO = value; }
    }
    private string type;

    public string Type
    {
        get { return type; }
        set { type = value; }
    }
    private string oRDER_ID;

    public string ORDER_ID
    {
        get { return oRDER_ID; }
        set { oRDER_ID = value; }
    }
    private string sUCCESS_STATUS;

    public string SUCCESS_STATUS
    {
        get { return sUCCESS_STATUS; }
        set { sUCCESS_STATUS = value; }
    }
    private string eMAIL_ID;

    public string EMAIL_ID
    {
        get { return eMAIL_ID; }
        set { eMAIL_ID = value; }
    }
	public WalletUsed()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}