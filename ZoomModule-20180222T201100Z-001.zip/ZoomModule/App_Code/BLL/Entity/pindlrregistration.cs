﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for pindlrregistration
/// </summary>
public class pindlrregistration
{
	public pindlrregistration()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private string _title = "";
    private string _name = "";
    private string _mobileno = "";
    private string _landlineno = "";
    private string _dob = "";
    private string _typeofmembr = "";
    private string _pincode = "";
    private string _address = "";
    private string _country = "";
    private string _state = "";
    private string _district = "";
    private string _area = "";
    private string _emailid = "";
    private string _password = "";
    private string _accountno = "";
    private string _userid = "";
    private string _joindate = "";
    private string _status = "";
    private string _verifycode = "";


    public string title
    {
        get
        {
            return _title;
        }
        set
        {
            _title = value;
        }

    }
    public string name
    {
        get
        {
            return _name;
        }
        set
        {
            _name = value;
        }


    }
    public string mobileno
    {
        get
        {
            return _mobileno;
        }
        set
        {
            _mobileno = value;
        }

    }

    public string landlineno
    {
        get
        {
            return _landlineno;
        }
        set
        {
            _landlineno = value;
        }

    }
    public string dob
    {
        get
        {
            return _dob;
        }
        set
        {
            _dob = value;
        }
    }
    public string typeofmembr
    {
        get
        {
            return _typeofmembr;
        }
        set
        {
            _typeofmembr = value;
        }
    }

    public string pincode
    {
        get
        {
            return _pincode;
        }
        set
        {
            _pincode = value;
        }
    
    }
    public string address
    {
        get
        {
            return _address;
        }
        set
        {
            _address = value;
        }
    }
    public string country
    {
        get
        {
            return _country;
        }
        set
        {
            _country = value;
        }
    }
    public string state
    {
        get
        {
            return _state;
        }
        set
        {
            _state = value;
        }
    }
    public string district
    {
        get
        {
            return _district;
        }
        set
        {
            _district = value;
        }
    }
    public string area
    {
        get
        {
            return _area;
        }
        set
        {
            _area = value;
        }
    }
    public string emailid
    {
        get
        {
            return _emailid;
        }
        set
        {
            _emailid = value;
        }
    }

    public string password
    {
        get
        {
            return _password;
        }
        set
        {
            _password = value;
        }

    }

    public string accountno
    {
        get
        {
            return _accountno;
        }
        set
        {
            _accountno = value;
        }
    }
    public string userid
    {
        get
        {
            return _userid;
        }
        set
        {
            _userid = value;
        }
    }
    public string joindate
    {
        get
        {
            return _joindate;
        }
        set
        {
            _joindate = value;
        }
    }
    public string status
    {
        get
        {
            return _status;
        }
        set
        {
            _status = value;
        }
    }
    public string verifycode
    {
        get
        {
            return _verifycode;
        }
        set
        {
            _verifycode = value;
        }
    }

}