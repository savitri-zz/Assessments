﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for WalletTransactions
/// </summary>
public class WalletTransactions
{
    private string uSER_ID;

    public string USER_ID
    {
        get { return uSER_ID; }
        set { uSER_ID = value; }
    }
    private string mOBILE;

    public string MOBILE
    {
        get { return mOBILE; }
        set { mOBILE = value; }
    }
    private string cR_AMT;

    public string CR_AMT
    {
        get { return cR_AMT; }
        set { cR_AMT = value; }
    }
    private string aMT;

    public string AMT
    {
        get { return aMT; }
        set { aMT = value; }
    }
    private string dATE;

    public string DATE
    {
        get { return dATE; }
        set { dATE = value; }
    }
    private string sTATUS;

    public string STATUS
    {
        get { return sTATUS; }
        set { sTATUS = value; }
    }
	public WalletTransactions()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}