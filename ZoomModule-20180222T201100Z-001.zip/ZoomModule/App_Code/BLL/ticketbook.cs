﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
/// <summary>
/// Summary description for ticketbook
/// </summary>
public class ticketbook:BaseClass
{
	public ticketbook()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string verifyCodeGenerator(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return verifyCodeGenerator(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public string Generattransaction(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return Generattransaction(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public DataTable getamount(string account_no)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no = '" + account_no + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getamount2(string account_no)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where accountno = '" + account_no + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable delear_users(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_delrpintransfer where dealerid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable productwalletexpense(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(ROUND(amt,0) as int)) as amount from tbl_prduwalltused where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable productwallettotal(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(ROUND(PW,0) as  int)) as amount from tbl_pw_deductions where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable delearamount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Amount as int)) as amount from tbl_admingenerate_pin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable user_amount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_userpin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
public DataTable getSpotBonusAmount(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Data_SpotBonusAmt  where tbl_registration.userid = tbl_Data_SpotBonusAmt.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable delearuseramount(string accountno)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_delrpintransfer where accountno = '" + accountno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable moneypaidfree(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where accountno='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable moneydeductpaid(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertTransactionDetail(string Name,string emailid, string accountno, string pinno, string mobileno, string verifycode, string datetime, string transaction)
    {
        try
        {

            string SQLQuery = "insert into tbl_tickettransaction (Name,Emailid,DAccountno,Uaccountno,Mobile, verificationcode, generatedate,transactionid) values ('" + Name + "','" + emailid + "','" + accountno + "','" + pinno + "','" + mobileno + "', '" + verifycode + "', '" + datetime + "' ,'" + transaction + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmemuser(string verify, string accountno, string pinno,string userid, string datetime)
    {
        try
        {
            string SQLQuery = "select * from tbl_tickettransaction where verificationcode='" + verify + "'  and (DAccountno = '" + accountno + "' or Uaccountno='" + pinno + "' or userid='" + userid + "') and generatedate='" + datetime + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertpin_freepinuse(string name, string emailid, string Amount, string pingenerateid, string bit2byteuserid, string subsno, string pintransfer, string transaction)
    {
        try
        {

            string SQLQuery = "insert into tbl_userpin (username,emailid, amount,generate_date,userid,bit2byteuserid,accountno,pinno,transactionid,description) values ('" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + pingenerateid + "','" + bit2byteuserid + "','" + subsno + "','" + pintransfer + "','" + transaction + "','To words Book Bus Ticket')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertpin_delarpinuse(string mobileno, string userid, string name, string emailid, string Amount, string account, string bit2byteuserid, string transaction)
    {
        try
        {

            string SQLQuery = "insert into tbl_delrpintransfer (mobile,dealerid,name,emailid, amount,generatedate,accountno,bit2byteuserid,pinno,Description) values ('" + mobileno + "','" + userid + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + account + "','" + bit2byteuserid + "','" + transaction + "','To words bit2byte')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void insertusepw(string bit2byteuserid,  string name, string emailid, string mobile, string amount,  string transaction,string type)
    {
        try
        {

            string SQLQuery = "insert into tbl_prduwalltused (userid,name,emailid,mobile, amt,transactionid,description,date,type) values ('" + bit2byteuserid + "','" + name + "','" + emailid + "','" + mobile + "', '" + amount + "','" + transaction + "','To words Book My Ticket','" + DateTime.Now.ToString() + "','" + type + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void latestproducttran(string bit2byteuserid, string mobileno, string debitedamt,string status)
    {
        try
        {

            string SQLQuery = "insert into tbl_walletalltransactionproductwallet (userid,mobileno,debitedamt, date,status) values ('" + bit2byteuserid + "','" + mobileno + "','" + debitedamt + "', '" + DateTime.Now.ToString() + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatetransactiontable(string transid, string verify)
    {
        try
        {

            string SQLQuery = "update tbl_tickettransaction  set transactionid='" + transid.ToString() + "' where verificationcode='" + verify + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertbooking(string name,string emailid, string mobileno, string Daccountno, string Uaccountno, string transactionid, string amount, string boarding, string seatselect, string journeydate, string departure, string arrival, string confirmationno, string busid)
    {
        try
        {

            string SQLQuery = "insert into tbl_busbooking (Name,Emailid,Mobileno,Daccountno,Uaccountno, transactionid,Generatedate,amount,Boardingpoint,SeatSelect,Journydate,Departure,Arrival,ConfirmationNumbr,Busid) values ('" + name + "','" + emailid + "','" + mobileno + "','" + Daccountno + "', '" + Uaccountno + "','" + transactionid + "', '" + DateTime.Now.ToString() + "','" + amount + "','" + boarding + "','" + seatselect + "','" + journeydate + "','" + departure + "','" + arrival + "','" + confirmationno + "','" + busid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        
    }

    public void insertbooking1(string busid, string tentitiveticketno, string datojourny, string seatno, string totalseat, string totalseatlayout)
    {
        try
        {

            string SQLQuery = "insert into tbl_bookmyticket (busid,ticketno,dateofjourny,seatlayout,seatcount,totalseatlayout) values ('" + busid + "','" + tentitiveticketno + "','" + datojourny + "','" + seatno + "', '" + totalseat + "','" + totalseatlayout + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable seatdetails(string busid, string seatlayout, string dateofjourny)
    {
        try
        {
            string SQLQuery = "select * from tbl_bookmyticket where busid='" + busid + "' and totalseatlayout= '" + seatlayout + "' and dateofjourny ='" + dateofjourny + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updateticket(string busid, string seatlayout, string dateofjourny,string ticket)
    {
        try
        {

            string SQLQuery = "update  tbl_bookmyticket  set ticketno='" + ticket + "' where busid='" + busid + "' and totalseatlayout= '" + seatlayout + "' and dateofjourny ='" + dateofjourny + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updeatil(string ticketprice, string boardingpt, string arrival, string departure, string servicprovid, string bustype,string name, string age, string gender, string email, string mobile, string sno)
    {
        try
        {

            string SQLQuery = "update  tbl_bookmyticket  set ticketprice='" + ticketprice + "' , boardingpoint ='" + boardingpt + "' , arrival='" + arrival + "' , departure ='" + departure + "', serviceprovider='" + servicprovid + "',bustype='" + bustype + "', name='" + name + "',age='" + age + "',gender='" + gender + "', emailid='" + email + "',mobile='" + mobile + "', bookingtime='" + DateTime.Now.ToString() + "' where sno='" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectgrid(string ticketno)
    {

        try
        {
            string SQLQuery = "select * from tbl_bookmyticket where ticketno='" + ticketno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }


    }

    public DataTable selectseat(string busno, string seatlayout)
    {
        try
        {
            string SQLQuery = "select * from tbl_bookmyticket where busid='" + busno + "' and seatlayout='" + seatlayout + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        
    }

    public DataTable GetBustypes()
    {
        try
        {
            string SQLQuery = "select distinct buscondition from tbl_businfo";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetTravelnames()
    {
        try
        {
            string SQLQuery = " select distinct Travelsname from tbl_businfo";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetBordingPoints()
    {
        try
        {
            string SQLQuery = " select distinct Bordingpoints from tbl_businfo";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetDroppingPoints()
    {
        try
        {
            string SQLQuery = " select distinct Dropingpoints from tbl_businfo";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void deleteseat(string busno, string seatlayout)
    {

        try
        {

            string SQLQuery = "delete from   tbl_bookmyticket where busid='" + busno + "' and seatlayout='" + seatlayout + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
      
    }

    public DataTable getamount3(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Datapayoutdetails  where tbl_registration.userid = tbl_Datapayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getamountchuser(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Binarypayoutdetails  where tbl_registration.userid = tbl_Binarypayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getamountchuser1(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Referalpayoutdetails  where tbl_registration.userid = tbl_Referalpayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertTransactionDetail1(string uname, string Uemail, string accountno, string useraccountno, string umobile, string codeverify, string datetime, string userid)
    {
        try
        {

            string SQLQuery = "insert into tbl_tickettransaction (Name,Emailid,DAccountno,Uaccountno,Mobile,verificationcode,generatedate,userid) values ('" + uname + "','" + Uemail + "','" + accountno + "','" + useraccountno + "', '" + umobile + "','" + codeverify + "','" + datetime + "','" + userid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatetickttransactiontable(string transid, string verify)
    {
        try
        {

            string SQLQuery = "update tbl_tickettransaction set transactionid='" + transid.ToString() + "' where verificationcode='" + verify + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable partnrid(string auserid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insetconfirmdetail(string contactno,string source, string destination, string doj, string travlsname, string tiktno,string pnrno, string bustype, string reporttime, string fare, string departur, string bordingtim, string bordinglocation, string landmark, string address, string userid, string accountno)
    {
        try
        {

            string SQLQuery = "insert into tbl_ticktconfirm (contactno,source,destination,doj,travelsname,ticketno,pnrno,bustype,reportingtime,fare,deprturtime,bordingtime,bordinglocation,bordinglandmark,boardingaddress,userid,accountno) values ('" + contactno + "','" + source + "','" + destination + "','" + doj + "', '" + travlsname + "','" + tiktno + "','" + pnrno + "','" + bustype + "','" + reporttime + "','" + fare + "','" + departur + "','" + bordingtim + "','" + bordinglocation + "','" + landmark + "','" + address + "','" + userid + "','" + accountno + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpuserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfuserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


   

    public void insertbusdetail(string Travelsname, string Departuretime, string seatavailabl, string sellfair, string servicename, string arrivaltime, string bustype, string routeid, string userid,string buscondition, string busno,string BPLocation,string DPLocation)
    {
        try
        {

            string SQLQuery = "insert into tbl_businfo (Travelsname,Departuretime,seatavailabl,sellfair,servicename,arrivaltime,bustype,routeid,userid,buscondition,status1,Bordingpoints,Dropingpoints) values ('" + Travelsname + "','" + Departuretime + "','" + seatavailabl + "','" + sellfair + "', '" + servicename + "','" + arrivaltime + "','" + bustype + "','" + routeid + "','" + userid + "','" + buscondition + "','" + busno + "','" + BPLocation + "','" + DPLocation + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void deleteuserid(string userid)
    {
        try
        {

            string SQLQuery = "delete from   tbl_businfo where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertdestination(string cityname, string cityid)
    {
        try
        {

            string SQLQuery = "insert into tbl_bookmyticket (cityid,cityname) values ('" + cityid + "','" + cityname + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlcities()
    {
        try
        {
            string SQLQuery = "select * from tbl_buscity ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public object getbusinfo(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo where userid='" + userid + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void InsertBusTypes(string bustypeid,string userid)
    {
        try
        {
            string SQLQuery = "insert into tbl_busTypeCondition (bustypeid,userid) values ('" + bustypeid + "','" + userid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   
    public void DeleteBusTypes1(string bustypeid)
    {
        try
        {
            string SQLQuery = "delete from tbl_busTypeCondition where bustypeid='" + bustypeid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getbusinfoBind(string bustypeid,string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_busTypeCondition where bustypeid = '" + bustypeid + "'and userid='"+userid+"' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getbusinfoBind12()
    {
        try
        {
            string SQLQuery = "select  *  from tbl_busTypeCondition";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void DeleteBusTypes(string bustypeid)
    {
        try
        {
            string SQLQuery = "delete from tbl_busTypeCondition where sno = '" + bustypeid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable wallettransamtforbus(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(creditedamount as float)) as amount from tbl_walletalltransaction where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable walletdebitsamtforbus(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(debitedamt as float)) as amount from tbl_walletalltransaction where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void Insertbankwallettranscationforbus(string userid,string mobileno,string debitedamt,string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_walletalltransaction(userid,mobileno,debitedamt,date,status) values ('" + userid + "','" + mobileno + "','" + debitedamt + "','" + DateTime.Now + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable ProductWalletamtforbus(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(creditedamount as float))-sum( cast(debitedamt as float)) as amount from tbl_walletalltransactionproductwallet where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}