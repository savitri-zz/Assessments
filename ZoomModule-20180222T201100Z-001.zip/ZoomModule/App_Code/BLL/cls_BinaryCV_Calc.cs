﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for cls_BinaryCV_Calc
/// </summary>
public class cls_BinaryCV_Calc : BaseClass
{
	public cls_BinaryCV_Calc()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetUserid(string Payout)
    {
        try
        {
            string SQLQuery = "select tbl_BinaryCV_Calc1.Userid as Userid, tbl_BinaryCV_Calc1.ElgBV as ElgBV, tbl_BinaryCV_Calc1.SelectedDate as SelectedDate, tbl_BinaryCV_Calc1.BinaryCV as BinaryCV, tbl_BinaryCV_Calc1.BVAmt as BVAmt from tbl_BinaryCV_Calc1, tbl_registration where tbl_BinaryCV_Calc1.Userid = tbl_registration.userid ";
            SQLQuery = SQLQuery + " and  cast(SelectedDate as date) = '" + Payout.ToString()+ "' order by cast(tbl_registration.joindate as datetime) desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ZGetUserid_Binary(string PayoutDate)
    {
        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails_New where cast(PayoutDate as date) ='" + PayoutDate + "' and EBV <> '0' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetSid(string userid, string PayoutDate)
    {
        try
        {
            string SQLQuery = "select SUM(cast(BalanceCV as int)) as BalanceCV from tbl_BinaryCVCalc where SponsorID = '" + userid + "' and cast(PayoutDate as date) = '" + PayoutDate.ToString()+ "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public void UpadteDeductionAmt(string Userid, string DeductionAmt, string BinaryCV, string payoutDate)
    {
        try
        {
            string SQLQuery = "update tbl_BinaryCV_Calc1 set BinaryCV='" + BinaryCV + "' ,DeductionAmt='" + DeductionAmt + "' where Userid='" + Userid + "' and SelectedDate = '" + payoutDate.ToString() + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ZGetSponsorids(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ZGetExistUserid(string userid, string payoutDate)
    {
        try
        {
            string SQLQuery = "select * from tbl_BinaryCV_Calc1 where Userid='" + userid + "' and cast(SelectedDate as date) = '" + payoutDate.ToString() + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertBinaryCVCalcations(string userid, string ElgBV, string BVAmt,string SelectedDate, string PayoutDate)
    {
        try
        {
           // string SQLQuery = "insert into tbl_BinaryCV_Calc1(userid, ElgBV, BVAmt,SelectedDate,PayoutDate) values ('" + userid + "','" + ElgBV + "','" + BVAmt + "','" + SelectedDate + "','" + PayoutDate + "')";

            string SQLQuery = "USP_InsertBinaryCVCalcations   '" + userid + "','" + ElgBV + "','" + BVAmt + "','" + SelectedDate + "','" + PayoutDate + "'";


            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BinaryCalcValuesExist(string userid, string PayoutDate)
    {
        try
        {
            string SQLQuery = "select * from tbl_BinaryCV_Calc1 where Userid='" + userid + "' and PayoutDate='" + PayoutDate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable checkplacementright(string referid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  userid='" + referid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
}