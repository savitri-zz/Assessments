﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

public class Products:BaseClass
{
	public Products()
	{
		
	}

    public void saveProducts(ProductsEntity product)
    {
        try
        {

            string[] strArrList = { "@Code", "@product_name", "@cost", "@QTY", "@total", "@tax", "@mrp", "@dealerprice", 
                                      "@delerpricePersent", "@profit", "@margin", "@marginpersent", "@devchrges", "@devchargespersent", 
                                      "@bonus", "@bonuspersent", "@balance", "@cv", "@cvpersent", "@BV", "@bonusBV", "@data", "@extradata", 
                                      "@ppdata", "@points", "@totalPoints", "@pv", "@totalPV", "@elgPV", "@elgpvpersent", "@extraPV", "@netElgPV", 
                                      "@crtmpble", "@payable", "@paid", "@accountBalance" };
            string[] strArrValues = { product.code.ToString(),product.productname.ToString(), product.cost.ToString(),product.quantity.ToString(), product.total.ToString(), 
                                        product.tax.ToString(),product.mrp.ToString(), product.dealerprice.ToString(), product.delerpricePersent.ToString(),
                                        product.profit.ToString(), product.margin.ToString(), product.marginpersent.ToString(), product.devchrges.ToString(), 
                                        product.devchargespersent.ToString(), product.bonus.ToString(),product.bonuspersent.ToString(),product.balance.ToString(), 
                                        product.cv.ToString(),product.cvpersent.ToString(), product.BV.ToString(),product.bonusBV.ToString(),product.data.ToString(),
                                        product.extradata.ToString(), product.ppdata.ToString(), product.points.ToString(),product.totalPoints.ToString(),product.pv.ToString(),
                                        product.totalPV.ToString(), product.elgPV.ToString(), product.elgpvpersent.ToString(), product.extraPV.ToString(),product.netElgPV.ToString(),
                                        product.crtmpble.ToString(), product.payable.ToString(),product.paid.ToString(), product.accountBalance.ToString() };


            int intRowAffect = fnRunProcedure("sp_saveProductsDetails", strArrList, strArrValues, true);


        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataTable getProductDetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_Products";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void DeleteProduct(string ProductId)
    {
        try
        {
            //string SQLQuery = "delete from tbl_Products where sno = '" + ProductId + "'";
            string SQLQuery = " USP_DeleteProduct '" + ProductId + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateProductDetails(ProductsEntity product)
    {
        try
        {

            string[] strArrList = {"@sno", "@Code", "@product_name", "@cost", "@QTY", "@total", "@tax", "@mrp", "@dealerprice", 
                                      "@delerpricePersent", "@profit", "@margin", "@marginpersent", "@devchrges", "@devchargespersent", 
                                      "@bonus", "@bonuspersent", "@balance", "@cv", "@cvpersent", "@BV", "@bonusBV", "@data", "@extradata", 
                                      "@ppdata", "@points", "@totalPoints", "@pv", "@totalPV", "@elgPV", "@elgpvpersent", "@extraPV", "@netElgPV", 
                                      "@crtmpble", "@payable", "@paid", "@accountBalance" };
            string[] strArrValues =  {Convert.ToString( product.ProductId), product.code.ToString(),product.productname.ToString(), product.cost.ToString(),product.quantity.ToString(), product.total.ToString(), 
                                        product.tax.ToString(),product.mrp.ToString(), product.dealerprice.ToString(), product.delerpricePersent.ToString(),
                                        product.profit.ToString(), product.margin.ToString(), product.marginpersent.ToString(), product.devchrges.ToString(), 
                                        product.devchargespersent.ToString(), product.bonus.ToString(),product.bonuspersent.ToString(),product.balance.ToString(), 
                                        product.cv.ToString(),product.cvpersent.ToString(), product.BV.ToString(),product.bonusBV.ToString(),product.data.ToString(),
                                        product.extradata.ToString(), product.ppdata.ToString(), product.points.ToString(),product.totalPoints.ToString(),product.pv.ToString(),
                                        product.totalPV.ToString(), product.elgPV.ToString(), product.elgpvpersent.ToString(), product.extraPV.ToString(),product.netElgPV.ToString(),
                                        product.crtmpble.ToString(), product.payable.ToString(),product.paid.ToString(), product.accountBalance.ToString() };


            int intRowAffect = fnRunProcedure("sp_updateProductsDetails", strArrList, strArrValues, true);


        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}