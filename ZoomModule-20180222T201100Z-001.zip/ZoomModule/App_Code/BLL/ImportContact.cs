﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

public class ImportContact:BaseClass
{
	public ImportContact()
	{
		
	}

    public void insertcontact(string Name, string Mobile, string state, string district, string city, string Address, string Occupayion, string Reference)
    {
        try
        {

            string SQLQuery = "insert into test_contacts(Name,Mobile,state,district,city,Address,Occupayion,Reference)values ('" + Name + "','" + Mobile + "','" + state + "','" + district + "','" + city + "','" + Address + "','" + Occupayion + "','" + Reference + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertMailContact(string Emailid,string Reference)
    {
        try
        {

            string SQLQuery = "insert into tbl_mailContacts(Userid,EmailAddress)values ('" + Reference + "','" + Emailid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable ExistsData(string Mobile)
    {
        try
        {
            string SQLQuery = "select * from test_contacts where Mobile='" + Mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}