﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clseditinvite
/// </summary>
public class clseditinvite: BaseClass 
{
	public clseditinvite()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public void editprofile(editProfileRegistration reg)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO tbl_editprofile(name,gender,dob,country,state,district,[city/area],othercityarea,address,postalcode,");
            sb.Append("mobileno,email,education,occupation,industry,incomerange,checkeditem,userid) values('" + reg.fname + "','" + reg.gender + "', '" + reg.dob + "',");
            sb.Append("'" + reg.country  + "',");
            sb.Append("'" + reg.state + "',");
            sb.Append("'" + reg.district + "',");
            sb.Append("'" + reg.city + "',");
            sb.Append("'" + reg.othercityarea + "',");
            sb.Append("'" + reg.address  + "',");
            sb.Append("'" + reg.pincode + "',");
            sb.Append("'" + reg.mobileno  + "',");
            sb.Append("'" + reg.emailid + "',");
            sb.Append("'" + reg.education  + "',");
            sb.Append("'" + reg.occupation  + "',");
            sb.Append("'" + reg.industry  + "',");
            sb.Append("'" + reg.incomerange + "',");
            sb.Append("'" + reg.checkeditem + "',");
            sb.Append("'" + reg.userid + "')");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
                 
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

        }
    public DataTable personalinvitcount(string inviteeno)
    {
        try
        {
             // string SQLQuery = "select count(*) as total from tbl_invitefriends where inivted_user='" + inviteeno + "'";
            string SQLQuery = "USP_personalinvitcount '" + inviteeno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable mailinvitcount(string inviteeno)
    {
        try
        {
           // string SQLQuery = "select count(*) as total from tbl_mailContacts where Userid='" + inviteeno + "'";
            string SQLQuery = "USP_mailinvitcount '" + inviteeno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable excelinvitcount(string inviteeno)
    {
        try
        {
           // string SQLQuery = "select count(*) as total from test_contacts where Reference='" + inviteeno + "'";

            string SQLQuery = "USP_excelinvitcount '" + inviteeno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Zinvitefriends(editProfileRegistration reg1)
    {
        try
        {

            string[] strArrList = { "@inivted_user", "@fname", "@lname", "@gender", "@agegroup", "@mobileno", "@emailid", "@area", "@address", "@pincode", "@country", "@state", "@district", "@city", "@occupation", "@checkeditem", "@invited_date", "@status", "@invited_user_status", "@active_status" ,"@userid"};
            string[] strArrValues = { reg1.inivted_user.ToString(),reg1.fname.ToString(), reg1.lname.ToString(),reg1.gender.ToString(), reg1.agegroup.ToString(), reg1.mobileno.ToString(),reg1.emailid.ToString(), reg1.area.ToString(), reg1.address.ToString(),reg1.pincode.ToString(),
                                        reg1.country.ToString(), reg1.state.ToString(), reg1.district.ToString(), reg1.city.ToString(), reg1.occupation.ToString(),reg1.checkeditem.ToString(),reg1.invited_date.ToString(), reg1.status.ToString(),reg1.invited_user_status.ToString(), reg1.active_status.ToString(),null};


            int intRowAffect = fnRunProcedure("sp_invitefriends", strArrList, strArrValues, true);
            

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataTable Getddldistricts1(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_district where sno = '" + id + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getstate(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates where id = '" + id + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getpaidmobil(string mobile)
    {
        try
        {
            string SQLQuery = "select p.mobileno from tbl_registration p inner join tbl_invitefriends i on  p.mobileno='"+mobile+"'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getpfreemobil(string mobile)
    {
        try
        {
            string SQLQuery = "select f.mobileno from tbl_freememreg f inner join tbl_invitefriends i on  f.mobileno='" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpaidcall(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno='" + mobile + "' and invited_user_status=2";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getfreecall(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno='" + mobile + "' and invited_user_status=1";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


  

    public void addcontact(string name, string mbl_no,string phoneno, string email, string district)
    {
        try
        {
            string SQLQuery = "insert into tbl_addcontact (name, mblno, phoneno, email,district) values ('" + name + "', '" + mbl_no + "', '" + phoneno + "', '" + email + "', '" + district + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable referaluserid(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where referal = '"+ id +"'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddldistricts(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_district where id =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlstates()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

   

    public DataTable Getinterest()
    {
        try
        {
            string SQLQuery = "select * from tbl_interest";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable invitefriendsexist(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno='" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable invitefriendsexist1(string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where emailid='" + email + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


  

    public DataTable paidmobileexits(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable freemobileexits(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendcountexits(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitecount where uid='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendagain(string inviteeno,string mobile,string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user='" + inviteeno + "' and mobileno='" + mobile + "' and invited_user_status='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable updatefriendcountexits(string uid)
    {
        try
        {
            string SQLQuery = "update  tbl_invitecount  set totalcount='0' ,invitedate='" + DateTime.Now.Date.ToShortDateString() +"'  where uid='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public void insertcontactcount(string uid, string totalcount, string invitedate)
    {
        try
        {
            string SQLQuery = "insert into tbl_invitecount (uid, totalcount, invitedate) values ('" + uid + "', '" + totalcount + "', '" + invitedate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }




    public void updatecontactcount(string count, string date, string uid)
    {
        try
        {
            string SQLQuery = "update tbl_invitecount set totalcount = '" + count + "', invitedate = '" + date + "' where uid = '" + uid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatecontactcountonly(string count, string uid)
    {
        try
        {
            string SQLQuery = "update tbl_invitecount set totalcount = '" + count + "' where uid = '" + uid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

  

    public DataTable getViewData(string mobileno, string Criteria)
    {
        try
        {
            string SQLQuery = "exec [dbo].[USP_SHOW_PERSONAL_DATA] '" + mobileno + "', '"+Criteria+"'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getUserPersonalData(string sUserID)
    {
        try
        {
            string SQLQuery = "EXEC USP_GET_USER_PERSONAL_DATA '" + sUserID + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetAboutUserByUserID(string UserID)
    {
        try
        {
            string SQLQuery = "select* from TBL_USER_ADDITIONAL_INFO where userid='" + UserID + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable GetReferalsByMobileNo(string sMobileNo)
    {
        try
        {
            string SQLQuery = "     select USERID, MOBILENO, NAME, IMAGE_NAME,EMAILID, ";
            SQLQuery = SQLQuery + " DBO.FN_GET_DETAILS_BY_USERID(USERID, 'CITY') CITY_NAME, ";
            SQLQuery = SQLQuery + " DBO.FN_GET_DETAILS_BY_USERID(USERID, 'STATE') state_name, ";
            SQLQuery = SQLQuery + " DBO.FN_GET_DETAILS_BY_USERID(USERID, 'OCCUPATION') OCCUPATION, ";
            SQLQuery = SQLQuery + " CONVERT(VARCHAR(11),JOINDATE ,106) ACTIVATION_DATE_106 , ";
            SQLQuery = SQLQuery + " (select top 1 USERID from tbl_freememreg f2 where f2.mobileno = '" + sMobileNo + "' and f2.referalID = a.USERID ) ref_userID ";
            SQLQuery = SQLQuery + " from TBL_ACTIVE_USERS a where USERID in ";
            SQLQuery = SQLQuery + " (  select f.referalID from tbl_freememreg f  ";
            SQLQuery = SQLQuery + "   where activeuser = 'NA' and INVALID_DATA_STATUS = 0  and mobileno = '" + sMobileNo + "'      )  ";
                   
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }  
       
}