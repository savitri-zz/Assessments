﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsnonmember
/// </summary>
public class clsnonmember: BaseClass
{
	public clsnonmember()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void Nonmemlogin(string mobileno, string userpwd, string name, string joindate, string emailid,string userid, string refrencid)
    {
        try
        {
            string SQLQuery = "insert into tbl_nonmemreg(mobileno, userpwd, name,joindate,emailid,userid,Referenceid) values ('" + mobileno + "', '" + userpwd + "', '" + name + "', '" + joindate + "','" + emailid + "','" + userid + "','" + refrencid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Nonmemlogininvite(string mobileno, string userpwd, string name, string joindate, string emailid, string referid)
    {
        try
        {
            string SQLQuery = "insert into tbl_nonmemreg(mobileno, userpwd, name,joindate,emailid,Referenceid) values ('" + mobileno + "', '" + userpwd + "', '" + name + "', '" + joindate + "','" + emailid + "','" + referid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable userexists(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where mobileno ='" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable nonmemlogin(string mobile, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where mobileno ='" + mobile + "' and  userpwd='" + password + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}