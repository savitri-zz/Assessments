﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for pindealerstatus
/// </summary>
public class pindealerstatus : BaseClass
{
	public pindealerstatus()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getamt(string accountno)
    {
        try
        {
            string sqlquery = "select sum(cast(Amount as int)) as amount  from tbl_admingenerate_pin where accountno='" + accountno + "'";

            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getdlrinfo()
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where status='1' and id !=62 order by id desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }
    public DataTable dealermonyexpense(string dealerid)
    {
        try
        {
            string sqlquery = "Select sum(cast(amount as float)) as amount from tbl_delrpintransfer where dealerid ='" + dealerid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable dealerdeatil(string dealerid)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where id ='" + dealerid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }


    public DataTable selectpackage()
    {
        try
        {
            string sqlquery = "Select sno, round(cast(mrp as int)) as mrp from tbl_Products";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
    public DataTable detailstransaction()
    {
        try
        {
            string sqlquery = "Select a.producttype,a.mobileno,a.TransactionId,a.joindate,b.AccountNo from tbl_registration as a inner join tbl_regtransactionDetails as b on a.TransactionId=b.transactionid ";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }


    public DataTable getmobile(string userid, string transaction)
    {
        try
        {
            string sqlquery = "select * from tbl_registration where userid='" + userid + "' and TransactionId='" + transaction + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable getpinsubdlr(string mobile)
    {
        try
        {
            string sqlquery = "  select distinct name,generatedate,amount,mobile,transactionid from tbl_delrpintransfer where  mobile='" + mobile + "' and pinno is not null ";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable selectdata(string dlrsno)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where dealerid='" + dlrsno + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable getamountfull(string sno)
    {


        try
        {
            string sqlquery = "Select ROUND(mrp,0) as mrp from tbl_Products where sno='" + sno + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
       
    }

    public DataTable pincheck(string dealer, string pin)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where dealerid='" + dealer + "' and pinno='" + pin + "' and  pinno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable pincheck(string dealer)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where dealerid='" + dealer + "' order by cast(generatedate as datetime) desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable pincheck1(string dealer)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where dealerid='" + dealer + "' and pinno is null and bit2byteuserid is not null order by cast(generatedate as datetime) desc ";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable pincheck2(string dealer)
    {
        try
        {
            string sqlquery = "Select distinct mobile from tbl_delrpintransfer where dealerid='" + dealer + "' and pinno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable subdlrrow(string pin, string mobile)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where mobile='" + mobile + "' and pinno='" + pin + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
    public DataTable usersno(string sno)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where sno='" + sno + "' order by sno desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }


    public DataTable getdirectamt(string directamt)
    {
        try
        {
            string sqlquery = "Select sum(cast(amount as float)) as total from tbl_delrpintransfer where dealerid='" + directamt + "' and pinno is null and amountdeduct is null";
            return GetDataTable(sqlquery, true);

        }
        catch(Exception Ex)
        {
            throw Ex;
        }
        
    }

    public DataTable getindirectamt(string indirectamt)
    {
        try
        {
            string sqlquery = "Select sum(cast(amount as float)) as total from tbl_delrpintransfer where dealerid='" + indirectamt + "' and pinno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getindirectdlramt(string indirectamt)
    {
        try
        {
            string sqlquery = "  Select sum(cast(amount as int)) as total from tbl_delrpintransfer where mobile='" + indirectamt + "' and pinno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable pinsubdlr(string userid)
    {
        try
        {
            string sqlquery = "Select * from tbl_userpin where userid='" + userid + "' and bit2byteuserid is not null order by cast(generate_date as datetime) desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable subdealermonyexpense(string dealerid)
    {
        try
        {
            string sqlquery = "Select sum(cast(amount as float)) as amount from tbl_userpin where userid ='" + dealerid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable subdealerdeatil(string dealerid)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where mobile ='" + dealerid + "' and pinno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable getcancelamt(string indirectamt)
    {
        try
        {
            string sqlquery = "Select sum(cast(amount as float)) as total from tbl_delrpintransfer where dealerid='" + indirectamt + "' and amountdeduct is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getdetailcancelpinamt(string indirectamt)
    {
        try
        {
            string sqlquery = "Select  * from tbl_delrpintransfer where dealerid='" + indirectamt + "' and amountdeduct is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPaidMemActiveStatus(string useid)
    {
        try
        {
            string sqlquery = "Select * from tbl_Userwalletstatus where useid='" + useid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
}