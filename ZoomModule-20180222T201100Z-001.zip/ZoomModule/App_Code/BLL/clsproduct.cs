﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsECportal
/// </summary>
public class clsproduct : BaseClass
{
	public clsproduct()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void AddProduct(entProduct reg)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" INSERT INTO tbl_Product(productname,code,cost,tax,total,data,bonus,data1,bonus1,product,BV,");
            sb.Append(" bv1,sms, point,ceiling) VALUES ('" + reg.productname + "', '" + reg.code + "', '" + reg.cost + "',");
            sb.Append("'" + reg.tax + "', ");
            sb.Append("'" + reg.total + "', ");
            sb.Append("'" + reg.data + "', ");
            sb.Append("'" + reg.bonus + "', ");
            sb.Append("'" + reg.data1 + "', ");
            sb.Append("'" + reg.bonus1 + "', ");
            sb.Append("'" + reg.product + "', ");
            sb.Append("'" + reg.BV + "', ");
            sb.Append("'" + reg.bv1 + "', ");
            sb.Append("'" + reg.sms + "', ");
            sb.Append("'" + reg.point + "', ");           
            sb.Append("'" + reg.ceiling + "')");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void AddProducts(ProductEntity reg)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" INSERT INTO tbl_Products(Code,Product_name,Cost,QTY,tax,MRP,DP,PROFIT,MARGIN,RP,BALANCE,");
            sb.Append(" CV,BV,points,pv_status,BonusBv,pv,celling) VALUES ('" + reg.code + "','" + reg.productname + "', '" + reg.cost + "',");
            sb.Append("'" + reg.total + "', ");
            sb.Append("'" + reg.tax + "', ");
            sb.Append("'" + reg.data + "', ");
            sb.Append("'" + reg.data1 + "', ");
            sb.Append("'" + reg.bonus + "', ");
            sb.Append("'" + reg.bonus1 + "', ");
            sb.Append("'" + reg.product + "', ");
            sb.Append("'" + reg.BV + "', ");
            sb.Append("'" + reg.bv1 + "', ");
            sb.Append("'" + reg.sms + "', ");
            sb.Append("'" + reg.point + "', ");
            sb.Append("'" + reg.pv_status + "', ");
            sb.Append("'" + reg.bonusbv + "', ");
            sb.Append("'" + reg.pv + "', ");
            sb.Append("'" + reg.celling + "')");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateProduct(entProduct reg, Int32 ProductID)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_Product ");
            sb.Append("set");
            sb.Append(" productname = '" + reg.productname + "', ");
            sb.Append(" code = '" + reg.code + "', ");
            sb.Append(" cost = '" + reg.cost + "', ");
            sb.Append(" tax = '" + reg.tax + "', ");
            sb.Append(" total = '" + reg.total + "', ");
            sb.Append(" data = '" + reg.data + "', ");
            sb.Append(" bonus = '" + reg.bonus + "', ");
            sb.Append(" data1 = '" + reg.data1 + "', ");
            sb.Append(" bonus1 = '" + reg.bonus1 + "', ");
            sb.Append(" product = '" + reg.product + "', ");
            sb.Append(" BV = '" + reg.BV + "', ");
            sb.Append(" bv1 = '" + reg.bv1 + "', ");
            sb.Append(" sms = '" + reg.sms + "', ");
            sb.Append(" point = '" + reg.point + "', ");
            sb.Append(" ceiling = '" + reg.ceiling + "' where sno = '" + ProductID + "'");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateProducts(ProductEntity reg, Int32 ProductID)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_Products ");
            sb.Append("set");
            sb.Append(" Product_name = '" + reg.productname + "', ");
            sb.Append(" Code = '" + reg.code + "', ");
            sb.Append(" Cost = '" + reg.cost + "', ");
            sb.Append(" QTY = '" + reg.total + "', ");
            sb.Append(" tax = '" + reg.tax + "', ");
            sb.Append(" MRP = '" + reg.data + "', ");
            sb.Append(" DP = '" +  reg.data1+ "', ");
            sb.Append(" PROFIT = '" + reg.bonus + "', ");
            sb.Append(" MARGIN = '" + reg.bonus1 + "', ");
            sb.Append(" RP = '" + reg.product + "', ");
            sb.Append(" BALANCE = '" + reg.BV + "', ");
            sb.Append(" CV = '" + reg.sms + "', ");
            sb.Append(" BV = '" + reg.bv1 + "', ");
            sb.Append(" points = '" + reg.point + "', ");
            sb.Append(" pv = '" + reg.pv + "', ");
            sb.Append(" celling = '" + reg.celling + "', ");
            sb.Append(" BonusBv = '" + reg.bonusbv + "', ");
            sb.Append(" pv_status = '" + reg.pv_status + "' where sno = '" + ProductID + "'");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Delete(int pin_no)
    {
        try
        {
            string SQLQuery = "delete from tbl_Product where sno=" + pin_no;
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void DeleteProducts(int pin_no)
    {
        try
        {
            string SQLQuery = "delete from tbl_Products where sno=" + pin_no;
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetProducts()
    {
        try
        {
            string SQLQuery = "select * from tbl_Product";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetProductDetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_Products";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpindetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_paypin";

            return GetDataTable(SQLQuery, false);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetProductsExits(string code)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where code = '" + code + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPinID(string PinNO)
    {
        try
        {
            string SQLQuery = "select * from tbl_pin_generator where pin_no = '" + PinNO.ToString() + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetreferralID(string refNO)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referedid = '" + refNO.ToString() + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable smsvillagepanchatALL(string villagepanchayat, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where village_pan > '" + villagepanchayat + "' ref_id= '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable smsvillageareaALL(string villagepanchayat, string area, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where village_pan = '" + villagepanchayat + "'and Area >'" + area + "' and ref_id= '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable smsusers(string villagepanchayat, string area, string userid )
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where village_pan = '" + villagepanchayat + "'and Area= '" + area + "' and ref_id= '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Alreadyexists(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobile ='" + mobileno + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetAdminLogin(string username, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_adminlogin where username='" + username + "' and pwd='" + password + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetUserLogin(string username, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobile = '" + username + "' and password = '" + password + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getposition()
    {
        try
        {
            string SQLQuery = "select * from tbl_position";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDate()
    {
        try
        {
            string SQLQuery = "select * from tbl_date";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetMonth()
    {
        try
        {
            string SQLQuery = "select * from tbl_month";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetYear()
    {
        try
        {
            string SQLQuery = "select * from tbl_year";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetGender()
    {
        try
        {
            string SQLQuery = "select * from tbl_gender";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetStates()
    {
        try
        {
            string SQLQuery = "select * from tbl_states where id = '18'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetMPCon()
    {
        try
        {
            string SQLQuery = "select * from tbl_MPconstituency where id ='9'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetMLA()
    {
        try
        {
            string SQLQuery = "select * from tbl_MLAconstituency where id = '82'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetZilla()
    {
        try
        {
            string SQLQuery = "select * from tbl_zilla";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetVillage()
    {
        try
        {
            string SQLQuery = "select * from tbl_villagepanchayat";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetVillagearea(string villageid)
    {
        try
        {
            string SQLQuery = "select * from tbl_villagearea where panchayat_id = '" + villageid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetCast()
    {
        try
        {
            string SQLQuery = "select * from tbl_Caste";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetReligion()
    {
        try
        {
            string SQLQuery = "select * from tbl_religion";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   
}