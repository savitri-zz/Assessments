﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsBinaryPayouts
/// </summary>
public class clsBinaryPayouts_temp : BaseClass
{
    protected string strNodevalue = "";
    protected string strSubnodevalue = "";
    protected string strUserIDS = "";
    protected string strTotalBVSum = "";
    protected int strBVTotal = 0;
    protected DateTime strjoindate;
    public clsBinaryPayouts_temp()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBinaryDatewisePayout_Mem(string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and CAST(tbl_registration.joindate as DATE) <=  '" + date + "' order by CAST(tbl_registration.joindate as DATE) DESC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids(string refid, string placement)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and  tbl_registration.referid ='" + refid + "' and  tbl_registration.placement = '" + placement + "'   order by CAST(tbl_registration.joindate as DATETIME) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_WithDates(string refid, string placement, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.referid='" + refid + "' and tbl_registration.placement='" + placement + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) <=  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_WithEqualDates(string refid, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.referid=tbl_Userwalletstatus.useid and tbl_registration.referid='" + refid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) =  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc   ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_EqualDates(string refid, string startDate, string endDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + refid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) between  '" + startDate + "' and '" + endDate + "' order by CAST(tbl_registration.joindate as DATE) asc   ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable fnDTParentNodes(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryDatewisePayout(string userid,  string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + userid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) <= '" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetBinaryDateBetweenwisePayout(string userid, string strStartDate, string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + userid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) between '" + strStartDate + "' and  '" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable fnDTSubNodes(string placementid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where placementid = '" + placementid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string fnMainNode(string sno, string strStartDate, string strJoinDate)
    {
        strUserIDS = "";
        DataTable dt = new DataTable();
        dt = fnDTParentNodes(sno);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                strNodevalue = row["userid"].ToString();
                fnSubNode(strNodevalue, strStartDate,strJoinDate);
            }
        }

        return strUserIDS.ToString();
    }

    public void fnSubNode(string strNodevalues, string strStartDate, string strJoinDate)
    {
        DataTable dt1 = new DataTable();
        dt1 = fnDTSubNodes(strNodevalues.ToString());
        if (dt1.Rows.Count > 0)
        {
            foreach (DataRow dr in dt1.Rows)
            {
                strSubnodevalue = dr["userid"].ToString();
                // strjoindate = Convert.ToDateTime(dr["joindate"].ToString());
                DataTable memActivatedStatus = GetBinaryDateBetweenwisePayout(strSubnodevalue.ToString(), strStartDate.ToString(), strJoinDate.ToString());
                if (memActivatedStatus.Rows.Count > 0)
                {
                    strUserIDS = strUserIDS + strSubnodevalue + ",";
                }
                fnSubNode(strSubnodevalue.ToString(),strStartDate, strJoinDate);
            }
        }
    }

    public string fnTotalBVCalc(string strTotalBV, string startdate, string enddate)
    {
        strBVTotal = 0;
        if (strTotalBV.Length != 0)
        {
            strTotalBVSum = strTotalBV.Substring(0, strTotalBV.Length - 1);
            string[] strInputArray = strTotalBVSum.Split(',');
            for (int i = 0; i < strInputArray.Length; i++)
            {
                DataTable dtUserDate = GetBinaryDateBetweenwisePayout(strInputArray[i], startdate.ToString(), enddate.ToString());
                if (dtUserDate.Rows.Count > 0)
                {
                    DataTable dtbvleft = new DataTable();
                    dtbvleft = getproductBVsum(dtUserDate.Rows[0]["producttype"].ToString());
                    if (dtbvleft.Rows.Count > 0)
                    {
                        strBVTotal = strBVTotal + Convert.ToInt32(dtbvleft.Rows[0]["BV"].ToString());
                    }
                }
            }
        }

        return strBVTotal.ToString();
    }


    public string fnTotalBVCalc_EqualsBV(string strTotalBV, string startdate, string enddate)
    {
        strBVTotal = 0;
        if (strTotalBV.Length != 0)
        {
            strTotalBVSum = strTotalBV.Substring(0, strTotalBV.Length - 1);
            string[] strInputArray = strTotalBVSum.Split(',');
            for (int i = 0; i < strInputArray.Length; i++)
            {
                DataTable dtUserDate = GetBinaryReferids_EqualDates(strInputArray[i], startdate.ToString(), enddate.ToString());
                if (dtUserDate.Rows.Count > 0)
                {
                    DataTable dtbvleft = new DataTable();
                    dtbvleft = getproductBVsum(dtUserDate.Rows[0]["producttype"].ToString());
                    if (dtbvleft.Rows.Count > 0)
                    {
                        strBVTotal = strBVTotal + Convert.ToInt32(dtbvleft.Rows[0]["BV"].ToString());
                    }
                }
            }
        }

        return strBVTotal.ToString();
    }


    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPayoutdeatils(string PayoutDate, string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayoutdetails_New where PayoutDate = '" + PayoutDate + "' and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPayoutdeatils_Datewise(string PayoutDate)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayoutdetails_New where PayoutDate = '" + PayoutDate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetCarryforwardValue(string userid, string payoutDate)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayoutdetails_New where userid='" + userid + "' and cast(PayoutDate as date) < '" + payoutDate + "'  order by cast(PayoutDate as date) DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertPayputDetails(string PayoutDate, string userid, string Name, string Mobileno, string TLBV, string TRBV, string CLBV, string CRBV, string CFL, string CFR, string NetBV, string EBV, string CV, string BeforeDeductionNetAmt, string DeductionAmt, string PW, string PayabeAmt, string UpdatePayout, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Binarypayoutdetails_New(PayoutDate, userid, Name, Mobileno,TLBV,TRBV,CLBV,CRBV,CFL,CFR,NetBV,EBV,CV,BeforeDeductionNetAmt,DeductionAmt,PW, PayabeAmt,UpdatePayout,status) values ('" + PayoutDate + "','" + userid + "','" + Name + "','" + Mobileno + "','" + TLBV + "','" + TRBV + "','" + CLBV + "','" + CRBV + "','" + CFL + "','" + CFR + "','" + NetBV + "','" + EBV + "','" + CV + "','" + BeforeDeductionNetAmt + "','" + DeductionAmt + "','" + PW + "','" + PayabeAmt + "','" + UpdatePayout + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //public void UpadatePayputDetails(string Name, string Mobileno, string TLBV, string TRBV, string CLBV, string CRBV, string CFL, string CFR, string NetBV, string EBV, string CV, string BeforeDeductionNetAmt, string DeductionAmt, string PW, string PayabeAmt, string UpdatePayout, string status,string PayoutDate, string userid)
    //{
    //    try
    //    {
    //        string SQLQuery = "update tbl_Binarypayout_Bystep set Name='" + Name + "', Mobileno='" + Mobileno + "',TLBV='" + TLBV + "',TRBV='" + TRBV + "',CLBV='" + CLBV + "',CRBV='" + CRBV + "',CFL='" + CFL + "',CFR='" + CFR + "',NetBV='" + NetBV + "',EBV='" + EBV + "',CV='" + CV + "',BeforeDeductionNetAmt='" + BeforeDeductionNetAmt + "',DeductionAmt='" + DeductionAmt + "',PW='" + PW + "',PayabeAmt='" + PayabeAmt + "',,UpdatePayout='" + UpdatePayout + "', status='" + status + "' where PayoutDate='" + PayoutDate + "' and  userid='" + userid + "')";
    //        int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}



    public DataTable getreferedname1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public List<DateTime> GetDateRange(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(1);
        } while (tmpDate <= EndingDate);
        rv.Sort(delegate(DateTime x, DateTime y) { return y.CompareTo(x); });
        return rv;
    }


    public List<DateTime> GetPayoutDates_ASC(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(1);
        } while (tmpDate <= EndingDate);
        rv.Sort(delegate(DateTime x, DateTime y) { return y.CompareTo(x); });
        rv.Reverse();
        return rv;
    }

    public string fnMainNode_FirstLevel(string sno, string startdate,string enddate)
    {
        strUserIDS = "";
        DataTable dt = new DataTable();
        dt = fnDTParentNodes(sno);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                strNodevalue = row["userid"].ToString();
                fnSubNode_firstLevel(strNodevalue,startdate.ToString(),enddate.ToString());
            }
        }

        return strUserIDS.ToString();
    }

    public void fnSubNode_firstLevel(string strNodevalues, string startdate, string enddate)
    {
        DataTable dt1 = new DataTable();
        dt1 = fnDTSubNodes(strNodevalues.ToString());
        if (dt1.Rows.Count > 0)
        {
            foreach (DataRow dr in dt1.Rows)
            {
                strSubnodevalue = dr["userid"].ToString();
                // strjoindate = Convert.ToDateTime(dr["joindate"].ToString());
                DataTable memActivatedStatus = GetBinaryReferids_EqualDates(strSubnodevalue.ToString(), startdate.ToString(), enddate.ToString());
                if (memActivatedStatus.Rows.Count > 0)
                {
                    strUserIDS = strUserIDS + strSubnodevalue + ",";
                }
                fnSubNode_firstLevel(strSubnodevalue.ToString(), startdate, enddate);
            }
        }
    }


    public DataTable getUpgradeUserDetails(string strUserid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_updatereg where userid = '" + strUserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUpgradeUseAmt(string package)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_elgibilityValues where package = '" + package + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetBinaryPlacementid(string placementid, string placement)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  where ";
            SQLQuery = SQLQuery + " tbl_registration.placementid ='" + placementid + "' and  tbl_registration.placement = '" + placement + "'   order by CAST(tbl_registration.joindate as DATETIME) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}