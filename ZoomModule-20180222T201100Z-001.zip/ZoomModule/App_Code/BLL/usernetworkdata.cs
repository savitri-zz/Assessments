﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for usernetworkdata
/// </summary>
public class usernetworkdata : BaseClass
{
    public usernetworkdata()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable getusernetworkdata(string csuserid, string Criteria)
    {
        try
        {
            string SQLQuery = "exec [dbo].[USP_SHOW_PERSONAL_DATA] '" + csuserid + "', '" + Criteria + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void zgetUserNetworkDataWithSession(string sUserID, string Criteria, string sSessionID)
    {
        try
        {
            //string sQry = "EXEC DBO.USP_SHOW_USER_NETWORK '" + sUserID + "' , '" + Criteria + "' , '" + sSessionID + "'";
            //int iRowsEffected = fnExecuteNonQuery(sQry, true);



            string[] strArrList = { "@USERID", "@CRITERIA", "@SESSION_ID" };
            string[] strArrValues = { sUserID, Criteria, sSessionID };


            int intRowAffect = fnRunProcedure("USP_SHOW_USER_NETWORK", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getUserNetworkDataWithSessionAsTable(string sUserID, string Criteria, string sSessionID)
    {
        try
        {
            string sQry = "EXEC DBO.USP_SHOW_USER_NETWORK '" + sUserID + "' , '" + Criteria + "' , '" + sSessionID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void getUserNetworkDataVersion2_WithSession(string sLoginUserID, string sDisplayUserID, string Criteria, string sSessionID, int iRetryCtr = 0)
    {
        try
        {
            //string sQry = "EXEC DBO.USP_SHOW_USER_NETWORK_VERSION_2 '" + sLoginUserID + "' , '" + sDisplayUserID + "' , '" + Criteria + "' , '" + sSessionID + "'";
            //int iRowsEffected = fnExecuteNonQuery(sQry, true);

            string[] strArrList = { "@LOGIN_USERID", "@DISPLAY_USERID", "@CRITERIA", "@SESSION_ID" };
            string[] strArrValues = { sLoginUserID, sDisplayUserID, Criteria, sSessionID };


            int intRowAffect = fnRunProcedure("USP_SHOW_USER_NETWORK_VERSION_2", strArrList, strArrValues, true);

        }
        catch (SqlException sqlEx)
        {
            if (iRetryCtr >= 3) //5, 7, Whatever
            {
                //log.Error("Unable to DoSomeSql, reached maximum number of retries.");
                throw;
            }

            switch (sqlEx.Number)
            {
                case 1205:
                    //log.Warn("DoSomeSql was deadlocked, will try again.");
                    break;
                case -2:
                    //log.Warn("DoSomeSql was timedout, will try again.");
                    break;
                default:
                    //log.WarnFormat(buf.ToString(), sqlEx);
                    break;
            }

            System.Threading.Thread.Sleep(1000); //Can also use Math.Rand for a random interval of time
            this.getUserNetworkDataVersion2_WithSession(sLoginUserID, sDisplayUserID, Criteria, sSessionID, ++iRetryCtr);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void getUserNetworkDataBetweenDates(string sLoginUserID, string sDisplayUserID, string Criteria, string sSessionID, DateTime dttFromDate, DateTime dttToDate)
    {
        try
        {
            //string sQry = "EXEC DBO.USP_SHOW_USER_NETWORK_VERSION_2 '" + sLoginUserID + "' , '" + sDisplayUserID + "' , '" + Criteria + "' , '" + sSessionID + "'";
            //int iRowsEffected = fnExecuteNonQuery(sQry, true);

            //string[] strArrList = { "@LOGIN_USERID", "@DISPLAY_USERID", "@CRITERIA", "@SESSION_ID" , "@FROM_DATE", "@TO_DATE" };
            //string[] strArrValues = { sLoginUserID, sDisplayUserID, Criteria, sSessionID, dttFromDate, dttToDate };


            //int intRowAffect = fnRunProcedure("USP_SHOW_USER_NETWORK_VERSION_2", strArrList, strArrValues, true);

            string SQLQuery = "exec [dbo].[USP_SHOW_USER_NETWORK_BETWEEN_DATE] '" + sLoginUserID + "', '"+ sDisplayUserID +"', '"+ Criteria +"', '"+ sSessionID +"', '"+ dttFromDate.ToString("yyyy-MM-dd") +"', '"+ dttToDate.ToString("yyyy-MM-dd") +"'";

             fnExecuteNonQuery(SQLQuery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getMaxActivationDateInUserNetwork(string sUserID)
    {
        try
        {   
            string sQry = "SELECT MAX(ACTIVATION_DATE) MAX_ACTIVATION_DATE FROM FN_USER_TREE_ALL_NETWORK_MEMBERS('"+ sUserID +"','','A')";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public DataTable getUserNetworkDataFromSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT MY_USER_ID, NEXT_LEVEL_USER_ID, FULLNAME, CITY_NAME, ISNULL(STATE_NAME , '') STATE_NAME, AREA, USER_STATUS,ACTIVATION_DATE, ACTIVATION_DATE_106, ";
            sQry = sQry + " OCCUPATION, USER_IMAGE, REFERID, REF_NAME, REF_IMAGE, ISNULL(TOTAL_USER_NETWORK_ACTIVATED , 0) TOTAL_USER_NETWORK_ACTIVATED, ISNULL(TOTAL_USER_NETWORK_INVITED , 0) TOTAL_USER_NETWORK_INVITED, MOBILE_NO,EMAIL_ID, MEMBER_POSITION, DATA_STATUS , ISNULL(PERSONAL_ACTIVATED,0) PERSONAL_ACTIVATED , ISNULL(PERSONAL_INVITED,0) PERSONAL_INVITED";
            sQry = sQry + " , INVITED_THROUGH, ISNULL(IS_QUICK_INVITE_UPDATE_PROFILE , 0) IS_QUICK_INVITE_UPDATE_PROFILE ";
            sQry = sQry + " , FULL_ACTIVATION_FLAG ,NEXT_LEVEL_MOBILENO, ISNULL(IS_MOBILE_VERIFIED,0) IS_MOBILE_VERIFIED";
            sQry = sQry + " , ISNULL(PENDING_ACTIVATIONS,0) PENDING_ACTIVATIONS";
            sQry = sQry + " FROM TMP_USER_NETWORK_SHOW_DATA  WHERE SESSION_ID = '" + sSessionID + "'  ORDER BY ACTIVATION_DATE DESC ";


            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable getUserNetworkDataFromSessionByDate(string sSessionID)
    {
        // This overloading method written by Sudhindra on 14-Mar-2015. Purpose : to filter the data based on given time slots
        try
        {
            string sQry = "SELECT MY_USER_ID, NEXT_LEVEL_USER_ID, FULLNAME, CITY_NAME, ISNULL(STATE_NAME , '') STATE_NAME, AREA, USER_STATUS,ACTIVATION_DATE, ACTIVATION_DATE_106, ";
            sQry = sQry + " OCCUPATION, USER_IMAGE, REFERID, REF_NAME, REF_IMAGE, ISNULL(TOTAL_USER_NETWORK_ACTIVATED , 0) TOTAL_USER_NETWORK_ACTIVATED, ISNULL(TOTAL_USER_NETWORK_INVITED , 0) TOTAL_USER_NETWORK_INVITED, MOBILE_NO,EMAIL_ID, MEMBER_POSITION, DATA_STATUS , ISNULL(PERSONAL_ACTIVATED,0) PERSONAL_ACTIVATED , ISNULL(PERSONAL_INVITED,0) PERSONAL_INVITED";
            sQry = sQry + " , INVITED_THROUGH, ISNULL(IS_QUICK_INVITE_UPDATE_PROFILE , 0) IS_QUICK_INVITE_UPDATE_PROFILE ";
            sQry = sQry + " , FULL_ACTIVATION_FLAG ";
            sQry = sQry + " FROM TMP_USER_NETWORK_SHOW_DATA  WHERE SESSION_ID = '" + sSessionID + "' ";
            sQry = sQry + " AND ACTIVATION_DATE <= (SELECT MAX(ACTIVATION_DATE) FROM TMP_USER_NETWORK_SHOW_DATA WHERE  SESSION_ID = '" + sSessionID + "'  )";
            sQry = sQry + " AND ACTIVATION_DATE >= (SELECT DATEADD(DAY,-30,MAX(ACTIVATION_DATE)) FROM TMP_USER_NETWORK_SHOW_DATA WHERE SESSION_ID = '" + sSessionID + "'  ) ORDER BY ACTIVATION_DATE DESC ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable getUserNetworkDataFromSessionByDate(string sSessionID, DateTime sFromDate, DateTime sToDate)
    {
        // This overloading method written by Sudhindra on 14-Mar-2015. Purpose : to filter the data based on given time slots
        try
        {
            string sQry = "SELECT MY_USER_ID, NEXT_LEVEL_USER_ID, FULLNAME, CITY_NAME, ISNULL(STATE_NAME , '') STATE_NAME, AREA, USER_STATUS,ACTIVATION_DATE, ACTIVATION_DATE_106, ";
            sQry = sQry + " OCCUPATION, USER_IMAGE, REFERID, REF_NAME, REF_IMAGE, ISNULL(TOTAL_USER_NETWORK_ACTIVATED , 0) TOTAL_USER_NETWORK_ACTIVATED, ISNULL(TOTAL_USER_NETWORK_INVITED , 0) TOTAL_USER_NETWORK_INVITED, MOBILE_NO,EMAIL_ID, MEMBER_POSITION, DATA_STATUS , ISNULL(PERSONAL_ACTIVATED,0) PERSONAL_ACTIVATED , ISNULL(PERSONAL_INVITED,0) PERSONAL_INVITED";
            sQry = sQry + " , INVITED_THROUGH, ISNULL(IS_QUICK_INVITE_UPDATE_PROFILE , 0) IS_QUICK_INVITE_UPDATE_PROFILE ";
            sQry = sQry + " , FULL_ACTIVATION_FLAG ";
            sQry = sQry + " FROM TMP_USER_NETWORK_SHOW_DATA  WHERE SESSION_ID = '" + sSessionID + "' ";
            sQry = sQry + " AND ACTIVATION_DATE <= '" + sFromDate.ToString("yyyy-MM-dd") + "' AND ACTIVATION_DATE >= '" + sToDate.ToString("yyyy-MM-dd") + "' ORDER BY ACTIVATION_DATE DESC ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getMaxAcitvation(string sSessionID)
    {
        try
        {
            string sQry = "SELECT MAX(ACTIVATION_DATE) MAX_ACTIVATION_DATE FROM TMP_USER_NETWORK_SHOW_DATA WHERE SESSION_ID = '" + sSessionID + "' ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    /*

        public void getUserNetworkDataVersion2_WithSession(string sUserID, string Criteria, string sSessionID)
        {
            try
            {
                string sQry = "EXEC DBO.USP_SHOW_USER_NETWORK_VERSION_2 '" + sUserID + "' , '" + Criteria + "' , '" + sSessionID + "'";
                int iRowsEffected = fnExecuteNonQuery(sQry, true);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public DataTable getUserNetworkDataFromSession(string sSessionID)
        {
            try
            {
                string sQry = "SELECT MY_USER_ID, NEXT_LEVEL_USER_ID, FULLNAME, CITY_NAME, STATE_NAME, AREA, USER_STATUS,ACTIVATION_DATE, ACTIVATION_DATE_106, ";
                sQry = sQry + " OCCUPATION, USER_IMAGE, REFERID, REF_NAME, REF_IMAGE, ISNULL(TOTAL_USER_NETWORK_ACTIVATED , 0) TOTAL_USER_NETWORK_ACTIVATED, ISNULL(TOTAL_USER_NETWORK_INVITED , 0) TOTAL_USER_NETWORK_INVITED, MOBILE_NO,EMAIL_ID, MEMBER_POSITION, DATA_STATUS ";
                sQry = sQry + " , INVITED_THROUGH, FIRSTLOG, IS_QUICK_INVITE_UPDATE_PROFILE ";
                sQry = sQry + " FROM TMP_USER_NETWORK_SHOW_DATA  WHERE SESSION_ID = '" + sSessionID + "' ORDER BY ACTIVATION_DATE DESC";

                return GetDataTable(sQry, true);
            }
            catch (Exception ex)
            {
            
                throw ex;
            }
        }
    */

    public DataTable getusernetworkdetails(string csuserid)
    {
        try
        {
            string SQLQuery = "exec [dbo].[USP_GET_USER_PERSONAL_DATA] '" + csuserid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserInvitationsData(string sUserID)
    {
        try
        {
            string sQry = "SELECT ISNULL(PERSONAL_INVITED, 0) PERSONAL_INVITED, ISNULL(PERSONAL_ACTIVATED , 0) PERSONAL_ACTIVATED, ISNULL(NETWORK_INVITED , 0) NETWORK_INVITED, ISNULL(NETWORK_ACTIVATED , 0) NETWORK_ACTIVATED, ISNULL(PERSONAL_INV_FRI_INVITED , 0) PERSONAL_INV_FRI_INVITED, PERSONAL_DIR_REG_INVITED, PERSONAL_INV_FRI_ACTIVATED, PERSONAL_DIR_REG_ACTIVATED, NETWORK_INV_FRI_INVITED, NETWORK_DIR_REG_INVITED, NETWORK_INV_FRI_ACTIVATED, NETWORK_DIR_REG_ACTIVATED, PERSONAL_ACTIVE_USER_IDS, PERSONAL_QUICK_INV_INVITED, PERSONAL_QUICK_INV_ACTIVATED, NETWORK_QUICK_INV_INVITED, NETWORK_QUICK_INV_ACTIVATED, PERSONAL_IMPORT_CONTACTS_INVITED, PERSONAL_IMPORT_CONTACTS_ACTIVATED, NETWORK_IMPORT_CONTACTS_INVITED, NETWORK_IMPORT_CONTACTS_ACTIVATED, USER_CURRENT_STATUS, ISNULL(NETWORK_NO_OF_AFFILIATES , 0) NETWORK_NO_OF_AFFILIATES, PERSONAL_FB_CONTACTS_INVITED, PERSONAL_FB_CONTACTS_ACTIVATED, NETWORK_FB_CONTACTS_INVITED, NETWORK_FB_CONTACTS_ACTIVATED , ISNULL(PERSONAL_SUSPENDED,0) PERSONAL_SUSPENDED, ISNULL(NETWORK_SUSPENDED,0) NETWORK_SUSPENDED, ISNULL(PERSONAL_SUSPENDED_AFFILIATES,0) PERSONAL_SUSPENDED_AFFILIATES, ISNULL(NETWORK_SUSPENDED_AFFILIATES,0) NETWORK_SUSPENDED_AFFILIATES ";
            sQry = sQry + " , ISNULL(PERSONAL_ACTIVATED_WITH_OPTIN , 0) PERSONAL_ACTIVATED_WITH_OPTIN , ISNULL(NETWORK_ACTIVATED_WITH_OPTIN , 0 ) NETWORK_ACTIVATED_WITH_OPTIN ";
            sQry = sQry + " , ISNULL(PERSONAL_DEACTIVATED , 0) PERSONAL_DEACTIVATED, ISNULL(NETWORK_DEACTIVATED , 0) NETWORK_DEACTIVATED , ISNULL(PERSONAL_DEACTIVATED_AFFILIATES , 0) PERSONAL_DEACTIVATED_AFFILIATES , ISNULL(NETWORK_DEACTIVATED_AFFILIATES , 0) NETWORK_DEACTIVATED_AFFILIATES ";
            sQry =  sQry + " FROM TBL_USER_INVITATIONS_DATA  WHERE USERID = '" + sUserID + "'";
            
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getUserPersonalData(string sUserID)
    {
        try
        {
            string sQry = "SELECT COUNT(*) PERSONAL_INVITED, ISNULL(SUM(CASE WHEN ACTIVEUSER = 'A' THEN 1 ELSE 0 END) , 0) PERSONAL_ACTIVED, ";
            sQry = sQry + " ISNULL(SUM(CASE WHEN ACTIVEUSER = 'S' THEN 1 ELSE 0 END) , 0) PERSONAL_SUSPENDED, ISNULL(SUM(CASE WHEN ACTIVEUSER = 'D' THEN 1 ELSE 0 END) ,0) PERSONAL_DEACTIVATED ";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + sUserID + "' AND INVALID_DATA_STATUS = 0 ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }



    public DataTable GetDataGivenUsers()
    {
        try
        {
            string sQry = " SELECT NAME, EMAILID, MOBILENO, USERID FROM ALL_MEMBERS_VIEW ";
            //sQry = sQry + " WHERE USERID IN (SELECT REFERALID  FROM ALL_MEMBERS_VIEW WHERE ACTIVEUSER = 'A') ORDER BY NAME";
            sQry = sQry + " WHERE USERID IN (SELECT REFERAL_ID FROM TBL_ACTIVE_USERS) ORDER BY NAME";
            return GetDataTable(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetDataGivenUsers(string sUserID, int iFilterDataGiven)
    {
        try
        {
            string sQry = " SELECT USERID, FULLNAME, MOBILENO, EMAILID, REFERID, REF_NAME, NO_OF_INVITES, USER_STATUS, ACTIVESTATUS, ";
            sQry = sQry + " INVITED_THROUGH, OCCUPATION, CITY_NAME, STATE_NAME, ACTIVATION_DATE, AFFILIATE_DATE, USER_STATUS_DTLS ";
            sQry = sQry + " FROM FN_REFERAL_TREE_ALL_NETWORK_MEMBERS('" + sUserID + "','','A')";
            sQry = sQry + " WHERE NO_OF_INVITES > =" + iFilterDataGiven.ToString();

            return GetDataTable(sQry, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet getUserNetworkDataUsingSession(string sSessionID, string USER_STATUS)
    {
        try
        {
            string sQry = "SELECT MY_USER_ID, NEXT_LEVEL_USER_ID, FULLNAME, CITY_NAME, ISNULL(STATE_NAME , '') STATE_NAME, AREA, USER_STATUS,ACTIVATION_DATE, ACTIVATION_DATE_106, ";
            sQry = sQry + " OCCUPATION, USER_IMAGE, REFERID, REF_NAME, REF_IMAGE, ISNULL(TOTAL_USER_NETWORK_ACTIVATED , 0) TOTAL_USER_NETWORK_ACTIVATED, ISNULL(TOTAL_USER_NETWORK_INVITED , 0) TOTAL_USER_NETWORK_INVITED, MOBILE_NO,EMAIL_ID, MEMBER_POSITION, DATA_STATUS , ISNULL(PERSONAL_ACTIVATED,0) PERSONAL_ACTIVATED , ISNULL(PERSONAL_INVITED,0) PERSONAL_INVITED";
            sQry = sQry + " , INVITED_THROUGH, ISNULL(IS_QUICK_INVITE_UPDATE_PROFILE , 0) IS_QUICK_INVITE_UPDATE_PROFILE ";
            sQry = sQry + " FROM TMP_USER_NETWORK_SHOW_DATA  WHERE SESSION_ID = '" + sSessionID + "' AND USER_STATUS = '" + USER_STATUS + "' ORDER BY ACTIVATION_DATE DESC";

            return GetDataSet(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataSet getInActiveByUserID(string uid)
    {
        try
        {
            string sQry = "select name,emailid,mobileno,userid from tbl_freememreg where referalid='" + uid + "' and activeuser='NA'";
            return GetDataSet(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable getInActiveByUserID(string uid, int PageIndex, int PageSize)
    {

        try
        {
            string SQLQuery = "exec [dbo].[GetInActiveDataPageWise] " + PageIndex + "," + PageSize + ",'" + uid + "',10";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        //try
        //{
        //    string sQry = "select top("+ PageCount +") name,emailid,mobileno,userid from tbl_freememreg where referalid='" + uid + "' and activeuser='NA' and PageCount='"+ PageCount +"' and PageSize='"+ PageSize + "'";
        //    return GetDataSet(sQry, true);
        //}
        //catch (Exception ex)
        //{

        //    throw ex;
        //}
    }


    public DataSet getGeneralReportActiveData()
    {
        try
        {
            string sQry = " SELECT fname,i.mobileno FROM TBL_INVITEFRIENDS I ";
            sQry = sQry + " INNER JOIN ALL_MEMBERS_VIEW V ON I.USERID = V.USERID LEFT OUTER JOIN ";
            sQry = sQry + " TBL_EDITPROFILE E ON V.USERID = E.USERID WHERE ISNULL(I.CITY , E.[CITY/AREA]) ";
            sQry = sQry + " IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) And v.activeuser='A' ";
            return GetDataSet(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    internal object executeQuery(string query)
    {
        try
        {
            return fnExecuteReader(query, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetPremiumAffiliatesClosedNetwork(string sUserID, string sMemberStatus = "")
    {
        try
        {
            string sQry = "SELECT USERID, FULLNAME, MOBILENO, EMAILID, PLACEMENT, JOINDATE, ACTIVESTATUS, MEMBER_STATUS, UPGRADED_PAID_DEACTIVE, ACTIVATION_DATE, AFFILIATE_DATE FROM FN_USER_TREE_PREMIUM_AFFILIATE_ACTIVE_NETWORK_MEMBERS('" + sUserID + "') ";
            if (sMemberStatus != "")
            {
                sQry = sQry + " WHERE MEMBER_STATUS = '" + sMemberStatus.ToUpper() + "' ";
            }
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetPremiumAffiliates()
    {
        try
        {
            string sQry = "SELECT MEMBER_STATUS,sno,mobileno,userpwd,name,emailid,referal_mobile,referalID,joindate,userid,activeuser,";
            sQry = sQry + " fiftystatus,firstlog,placement,placementid,SponsorUserID,IS_TERMS_AGREED,state,city,ACTIVATION_DATE,";
            sQry = sQry + " PRODUCTTYPE,levelno,AFFILIATE_DATE,UPGRADED_PAID_DEACTIVE,IS_FULLY_ACTIVATED,IS_PROFILE_PIC_UPLOADED,";
            sQry = sQry + " IS_PASSWORD_CHANGED,IS_PROFILE_UPDATED,INVALID_DATA_STATUS FROM FREEMEM_PAIDMEM_AFFILAITES_VIEW WHERE MEMBER_STATUS = 'PREMIUM AFFILIATE'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetMemberStatusByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT MEMBER_STATUS,sno,mobileno,userpwd,name,emailid,referal_mobile,referalID,joindate,userid,activeuser,";
            sQry = sQry + " fiftystatus,firstlog,placement,placementid,SponsorUserID,IS_TERMS_AGREED,state,city,ACTIVATION_DATE,";
            sQry = sQry + " PRODUCTTYPE,levelno,AFFILIATE_DATE,UPGRADED_PAID_DEACTIVE,IS_FULLY_ACTIVATED,IS_PROFILE_PIC_UPLOADED,";
            sQry = sQry + " IS_PASSWORD_CHANGED,IS_PROFILE_UPDATED,INVALID_DATA_STATUS FROM FREEMEM_PAIDMEM_AFFILAITES_VIEW WHERE USERID = '"+ sUserID +"'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public int GetInvalidDataCount(string sUserID)
    {
        try
        {
            int iCtr = 0;
            string sQry = "SELECT COUNT(*) CTR FROM TBL_INVALID_DATA WHERE REFERAL_ID = '"+ sUserID +"'";
            DataTable dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                iCtr = Convert.ToInt32(dt.Rows[0]["CTR"].ToString());
            }
            return iCtr;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

  
}