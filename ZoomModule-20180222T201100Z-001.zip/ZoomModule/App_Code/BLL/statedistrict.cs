﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// Summary description for statedistrict
/// </summary>
public class statedistrict : BaseClass
{
	public statedistrict()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataTable Getddlstates()
    {
        try
        {
            string SQLQuery = "select * from States order by state_name asc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddldistricts()
    {
        try
        {
            string SQLQuery = "select * from District where dist_id ='624' order by dist_name";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Getddldistricts(string id)
    {
        try
        {
            string SQLQuery = "select * from District where state_id ='" + id + "' order by dist_name ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDistrictByID(int iStateID, int iDistID)
    {
        try
        {
            string SQLQuery = "SELECT DIST_NAME FROM DISTRICT WHERE STATE_ID = '"+ iStateID.ToString() +"' AND DIST_ID ='" + iDistID.ToString() + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getstate(int id)
    {
        try
        {
            string SQLQuery = "select * from States where state_id =" + id + "  order by state_name asc ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getstate1(string id)
    {
        try
        {
            string SQLQuery = "select * from States where state_id =" + id + "  order by state_name asc ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlcitys(string distid)
    {
        try
        {
            string SQLQuery = "select * from Cities where  dist_id ='" + distid + "' order by city_name";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlcitys()
    {
        try
        {
            string SQLQuery = "select * from Cities where city_id = '0' order by city_name ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getcity(string id)
    {
        try
        {
            string SQLQuery = "select * from Cities where city_id ='" + id + "' order by city_name ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getcity(int sStateId, string sDistId, string sCityId)
    {
        try
        {
            string SQLQuery = "SELECT CITY_NAME, CITY_PINCODE FROM CITIES WHERE  STATE_ID = '"+ sStateId.ToString() +"' AND DIST_ID = '"+ sDistId.ToString() +"' AND CITY_ID ='" + sCityId + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlpincode(string cityid)
    {
        try
        {
            string SQLQuery = "select city_pincode from Cities where  city_id='" + cityid + "' order by city_name";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    /* ***************** Modified By Ganga on 2-Aug-2014. Purpose: To get the ad details based on sno  ******************* */
    public DataTable getUpdateDetails(int adno)
    {
        try
        {
            string SQLQuery = "select * from tbl_ads_smsproducts where sno="+adno;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getaddno()
    {
        try
        {
            string SQLQuery = "select * from tbl_ads_smsproducts";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
}