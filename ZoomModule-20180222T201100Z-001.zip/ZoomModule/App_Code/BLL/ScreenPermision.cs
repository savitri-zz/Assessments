﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ScreenPermision
/// </summary>
public class ScreenPermision : BaseClass
{
    public ScreenPermision()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable GetMenuPermissions(string roleid)
    {
        try
        {
            //string SQLQuery = "SELECT tRSP.ScreenName, tRSP.PermissionID,  tS.MenuID, tS.ParentID, tS.ScreenURL FROM tbl_Role_Screen_Permssion as tRSP INNER JOIN tbl_Screens as tS ON tRSP.ScreenName = tS.ScreenName INNER JOIN tbl_Permissions as tP ON tRSP.PermissionID = tP.PermissionID where tRSP.RoleID='" + roleid + "'   and tS.StatusID=1";
           // string SQLQuery = "SELECT   ScreenName, MenuID, ParentID, ScreenURL FROM tbl_Screens"; 
            //string SQLQuery = "SELECT   ScreenName, MenuID, ParentID, ScreenURL FROM tbl_Screens where RoleID='"+ roleid +"' and UserID='"+ userid +"' ";
            //string SQLQuery = "SELECT tRsc.RoleID, tRsc.ScreenName, tRsc.PermissionID, tS.MenuID, tS.ParentID,tS.ScreenURL FROM tbl_Role_Screen_Permssion as tRsc INNER JOIN tbl_Screens as tS ON tRsc.ScreenName = tS.ScreenName WHERE tRsc.RoleID = '" + roleid + "'";

            string SQLQuery = "SELECT tRsc.ScreenName AS ScreenName,tS.MenuID, tS.ParentID,tS.ScreenURL FROM tbl_Role_Screen_Permssion as tRsc INNER JOIN tbl_Screens as tS ON tRsc.ScreenName = tS.ScreenName WHERE tRsc.RoleID = '" + roleid + "' and tS.StatusID=1 group by tRsc.ScreenName,tS.MenuID, tS.ParentID,tS.ScreenURL";
        
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet GetScreens()
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Screens";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }





    public DataSet GetPermissions()
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Permissions where StatusID=1";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet GetPageContent()
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Permissions where StatusID=1; ";
            // SQLQuery += "SELECT Distinct ScreenName FROM tbl_Role_Screen_Permssion; ";
            SQLQuery += "SELECT Distinct ScreenName FROM tbl_Role_Screen_Permssion WHERE RoleID ='Admin' order by ScreenName; ";
            //SQLQuery += "SELECT Distinct ScreenName,PermissionID, RoleID FROM tbl_Role_Screen_Permssion WHERE RoleID ='Admin'; ";
            SQLQuery += "SELECT RoleId FROM tbl_UserRoles WHERE RoleID !='Admin'; ";
            //SQLQuery += "SELECT RoleId,StatusID,CreatedDate,UpdatedDate FROm tbl_UserRoles WHERE RoleID !='Admin'; ";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertBulkPermissions(DataTable dt, string RoleID)
    {

        try
        {
            //string SQLQuery = "INSERT INTO tbl_Users(UserID,UserName,Password,EmailId,MobileNo,GenderID,RoleID,StatusID,CreatedDate,CreatedBy)VALUES('" + entR.UserID + "','" + entR.UserName + "','" + entR.Password + "','" + entR.EmailId + "','" + entR.MobileNo + "','" + entR.GenderID + "','" + entR.RoleID + "',0,getdate(), LoginUser)";
            string SQLQuery = "DELETE FROM tbl_Role_Screen_Permssion WHERE RoleID = '" + RoleID + "'";
            fnInsertBulkCopy(dt, SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }



    }

    public DataSet UpdatetScreen(EntScreen entR)
    {
        try
        {
            string SQLQuery = "UPDATE tbl_Screens SET ScreenName ='" + entR.ScreenName + "',MenuID = '" + entR.MenuID + "',ParentID='" + entR.ParentID + "',ScreenURL='" + entR.ScreenURL + "',StatusID='" + entR.StatusID + "',UpdatedDate = getdate() WHERE ScreenName= '" + entR.ScreenName + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            DataSet ds = new DataSet();
            return ds = GetScreens();
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataSet InsertScreen(EntScreen entR)
    {

        DataSet ds = new DataSet();
        try
        {

            string SQLQuery = string.Format("SELECT COUNT(*) FROM tbl_Screens WHERE ScreenName= '" + entR.ScreenName + "'");


            int noOfUsers = fnExecuteScalar(SQLQuery, true);
            if (noOfUsers < 1)
            {
                SQLQuery = "INSERT INTO tbl_Screens(ScreenName,MenuID,ParentID,ScreenURL,StatusID,CreatedDate)VALUES('" + entR.ScreenName + "',(select max(MenuID)+1 from tbl_Screens as MenuID),'" + entR.ParentID + "','" + entR.ScreenURL + "','" + entR.StatusID + "',getdate())";
                //int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
                DataTable dt = new DataTable();
                ds = GetPermissions();
                if (ds.Tables[0].Rows.Count > 0)
                    dt = ds.Tables[0];
                DataColumn newColumn = new System.Data.DataColumn("ScreenName", typeof(System.String));
                newColumn.DefaultValue = entR.ScreenName;// "Your DropDownList value";
                dt.Columns.Add(newColumn);
                newColumn = new System.Data.DataColumn("RoleID", typeof(System.String));
                newColumn.DefaultValue = "Admin";//
                dt.Columns.Add(newColumn);
                fnInsertBulkCopy(dt, SQLQuery, true);
                //foreach (DataRow row in dt.Rows)
                //{
                //    row["ScreenName"] = "You DropDownList value";
                //    row["RoleID"] = "You DropDownList value";
                //}
            }
            return ds = GetScreens();
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetRolePermission(string Role)
    {
        try
        {
            
            string SQLQuery = "SELECT ScreenName, PermissionID  FROM tbl_Role_Screen_Permssion WHERE RoleID ='" + Role + "'order by ScreenName";
            //string SQLQuery = "SELECT RoleID, ScreenName, PermissionID FROM tbl_Role_Screen_Permssion WHERE (RoleID='" + Role + "' or RoleID ='Admin')";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetScreenPermissionInfo(string role, string Screen)
    {
        try
        {
            string SQLQuery = "SELECT ScreenName, PermissionID  FROM tbl_Role_Screen_Permssion WHERE RoleID ='" + role + "' and ScreenName ='" + Screen + "'";

           // string SQLQuery = "SELECT ScreenName, PermissionID  FROM tbl_Role_Screen_Permssion WHERE RoleID ='" + role + "'order by ScreenName";
            //string SQLQuery = "SELECT RoleID, ScreenName, PermissionID FROM tbl_Role_Screen_Permssion WHERE (RoleID='" + Role + "' or RoleID ='Admin')";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}