﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;

/// <summary>
/// Summary description for Clsadmin_New
/// </summary>
public class Clsadmin_New:BaseClass
{
	public Clsadmin_New()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    //public DataTable getnonmemberdetails()
    //{
    //    try
    //    {
    //        string SQLQuery = "sp_freememreg";
    //        return fnRunProcedureDatatableWithoutWhere(SQLQuery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}
}