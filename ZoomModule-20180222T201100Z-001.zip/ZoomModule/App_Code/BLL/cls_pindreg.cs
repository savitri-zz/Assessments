﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for cls_pindreg
/// </summary>
public class cls_pindreg  : BaseClass
{
	public cls_pindreg()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void pindelrreg(pindlrregistration dreg)
    {

        try
        {
            string[] strarrlist = { "@Title", "@Name", "@MobileNo", "@LandLineNo", "@Dob", "@typeofmember", "@Pincode", "@address", "@country", "@State", "@District", "@Area", "@Emailid", "@Password", "@joindate", "@userid", "@account_no", "@status", "@verifycode" };
            string[] strarrvalues = { dreg.title.ToString(),dreg.name.ToString(),dreg.mobileno.ToString(),dreg.landlineno.ToString(),dreg.dob.ToString(),dreg.typeofmembr.ToString(),dreg.pincode.ToString(),dreg.address.ToString(),dreg.country.ToString(),dreg.state.ToString(),dreg.district.ToString(), dreg.area.ToString(),dreg.emailid.ToString(),dreg.password.ToString(),dreg.joindate.ToString(),dreg.userid.ToString(), dreg.accountno.ToString(),dreg.status.ToString(),dreg.verifycode.ToString()};
            int intRowAffect = fnRunProcedure("sp_pinregdelr", strarrlist, strarrvalues,true);


        }
        catch(Exception EX)
        {
            throw EX;
        }
    }

    public string accountno(int  accountno1)
    {
        string str = "9,8,7,6,5,4,3,2,1,0,9,8,7,6,5,4,3,2,1";
        string[] strore = str.Split(',');
        string random = "";
        int temp = -1;
        Random ran = new Random();
        for (int i = 0; i < accountno1; i++)
        {
            if (temp != -1)
            {
                ran = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(19);
            if (temp != -1 && temp == t)
            {
                return accountno(accountno1);
            }
            temp = t;
            random += strore[t];
        }
        return random;

        }

    public string userid(int uid)
    {
        string str = "0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8";
        string[] strore = str.Split(',');
        string random = "";
        int temp = -1;
        Random ran = new Random();
        for (int i = 0; i < uid; i++)
        {
            if (temp != -1)
            {
                ran = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(19);
            if (temp != -1 && temp == t)
            {
                return userid(uid);
            }
            temp = t;
            random += strore[t];
        }
        return random;

    }

    public string verificationcode(int verify)
    {
        string str = "0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9";
        string[] varray = str.Split(',');
        string codevrify = "";
        int tem = -1;
        Random ran = new Random();
        for (int i = 0; i < verify; i++)
        {
            if (tem != -1)
            {
                ran = new Random(i * tem * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(20);
            if (tem != -1 && tem == t)
            {
                return verificationcode(verify);

            }
            tem = t;
            codevrify += varray[t];

        }
        return codevrify;


    }
    public string pswd(int verify)
    {
        string str = "0,9,1,8,2,7,3,6,4,5,9,0,8,1,7,2,6,3,5,4";
        string[] varray = str.Split(',');
        string codevrify = "";
        int tem = -1;
        Random ran = new Random();
        for (int i = 0; i < verify; i++)
        {
            if (tem != -1)
            {
                ran = new Random(i * tem * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(19);
            if (tem != -1 && tem == t)
            {
                return pswd(verify);

            }
            tem = t;
            codevrify += varray[t];

        }
        return codevrify;


    }

    public string transactionid(int verify)
    {
        string str = "0,9,1,8,2,7,3,6,4,5,9,0,8,1,7,2,6,3,5,4";
        string[] varray = str.Split(',');
        string codevrify = "";
        int tem = -1;
        Random ran = new Random();
        for (int i = 0; i < verify; i++)
        {
            if (tem != -1)
            {
                ran = new Random(i * tem * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(19);
            if (tem != -1 && tem == t)
            {
                return transactionid(verify);

            }
            tem = t;
            codevrify += varray[t];

        }
        return codevrify;


    }

    public DataTable getdate()
    {
        try
        {
            string SqlQuery="Select * from tbl_date";
            return GetDataTable(SqlQuery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable getmonth()
    {
        try
        {
            string SqlQury = "Select * from tbl_month";
            return GetDataTable(SqlQury,true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
    public DataTable getyear()
    {
        try
        {
            string sqlquery = "Select * from tbl_year order by birth_year ASC";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw  Ex;
        }
    }


    public DataTable  Getddlstates()
    {
        try
        {
            string sqlquery = "Select * from tbl_indianstates";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddldistrict(string statename)
    {
        try
        {
            string sqlquery = "Select * from tbl_district where id= '" +statename + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable duplicateuser(string mobilenam, string emailid)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where MobileNo='" + mobilenam + "' or Emailid = '" + emailid + "' ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable Zverifycheck(string code, string mobile, string email)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where MobileNo='" + mobile + "' and  Emailid = '" + email + "' and verifycode='" + code + "' ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

       
    }

    public DataTable Zdelarpin(string mobile, string emailid)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where MobileNo='" + mobile + "' and  Emailid = '" + emailid + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable Zactive(string mobile, string password)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where MobileNo='" + mobile + "' and  Password = '" + password + "' and status=0 ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
       
    }

    public DataTable Zpaid(string mobile, string password)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where MobileNo='" + mobile + "' and  Password = '" + password + "' and status=1 ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public DataTable Zbindtextdata(string userdata)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where MobileNo='" + userdata + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Zupdatedata(string name, string mobileno, string emailid, string country, string state, string district, string area, string pincode, string mobileno1)
    {
        try
        {

          // string sqlquery="update tbl_pindealerregistration set Name='" + name + "', MobileNo='" + mobileno + "',Emailid='" + emailid + "',country='" + country + "',State='" + state + "',District='" + district + "',Area='" + area + "',Pincode = '" + pincode + "' where MobileNo='" + mobileno1 + "'";

            string sqlquery = "USP_updatedata   '" + name + "','" + mobileno + "','" + emailid + "','" + country + "','" + state + "','" + district + "','" + area + "','" + pincode + "','" + mobileno1 + "'";



           int rowaffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch(Exception EX)
        {
            throw EX;
        }
    }

    public DataTable Zgetstate()
    {
        try
        {
            string sqlquery = "Select * from tbl_indianstates";
            return GetDataTable(sqlquery,true);
        }
        catch(Exception EX)
        {
            throw EX;

        }
        
    }

    public DataTable Zgetpassword(string uid, string password)
    {
        try
        {
            string sqlquery = "Select  * from tbl_pindealerregistration where id='" + uid + "' and Password='" + password + "'";
            return GetDataTable(sqlquery, true);
        }
        catch(Exception EX)
        {
            throw EX;

        }

    }

    public void Zupdatepassword(string pswd, string uid)
    {
        try
        {
            string sqlquery="update tbl_pindealerregistration set Password='" + pswd + "' where id='" + uid + "'";
            int rowaffect = fnExecuteNonQuery(sqlquery,true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public void Zinsertdlrdata(string dealerid,string name,string emailid,string mobile,string amount, string pino, string generatedate,string userid,string accountno,string pswd,string verificationcode,string status)
    {
        try
        {
            string[] paramvalue = { "@dealerid", "@name", "@emailid", "@mobile", "@amount", "@pinno", "@generatedate", "@userid", "@accountno", "@pswd", "@vaerification_code", "@status","@bit2byteuserid","@transactionid","@Description","@Remainingamt","@amountdeduct","@commission"};
            string[] stringvalu = { dealerid.ToString(), name.ToString(), emailid.ToString(), mobile.ToString(), amount.ToString(), pino.ToString(), generatedate.ToString(), userid.ToString(), accountno.ToString(), pswd.ToString(), verificationcode.ToString(), status.ToString(),null,null,null,null,null,null };
            int intRowAffect = fnRunProcedure("sp_dlrpintransfer", paramvalue, stringvalu, true);
        }
        catch(Exception EX)
        {
            throw EX;
        }


    }
    public DataTable Zdisplayuserpin(string accountno)
    {
        try
        {
            string SQLQuery = "select * from tbl_admingenerate_pin where accountno = '" + accountno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zdisplaydelearusers(string dealerid)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where dealerid = '" + dealerid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zdelearamount(string accountno)
    {
        try
        {
            string SQLQuery = "select sum(cast(Amount as float)) as amount from tbl_admingenerate_pin where accountno = '" + accountno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zdelear_users(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as float)) as amount from tbl_delrpintransfer where dealerid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Zuserpin(string delid)
    {
        try
        {
            string SQLQuery = "select * from tbl_userpin where userid = '" + delid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

}