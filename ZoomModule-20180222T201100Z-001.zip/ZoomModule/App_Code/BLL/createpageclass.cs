﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;


/// <summary>
/// Summary description for createpage
/// </summary>
public class createpageclass : BaseClass
{
    public createpageclass()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /*************Get interest from tbl_interest_level_1*******/
    public DataTable getcategoriesfirsthalf()
    {
        try
        {
            string sqlquery = "select * from  tbl_interest_level_1 where sno between 1 and 6";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriesfirsthalf(string sUserIntrest)
    {
        try
        {
            string sqlquery = "select CASE WHEN CHARINDEX(','  + CAST(SNO AS VARCHAR(30)) + ',', ',' +'" + sUserIntrest + "'+ ',') > 0 THEN 1 ELSE 0 END Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1 where sno between 1 and 6";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriesfirsthalf_byUserID(string sUserID)
    {
        try
        {
            string sqlquery = "";
            if (sUserID == "")
            {
                sqlquery = "select 0 Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1 where sno between 1 and 6";
            }
            else
            {
                home clsHome = new home();
                string sSelectedCategories = clsHome.GetDetailsByUserID(sUserID, "USER_INTEREST_IDS");

                if (sSelectedCategories.Trim().Replace(",", "").Length <= 0)
                {
                    sSelectedCategories = "1,2";
                }
                //sqlquery = "select case when charindex(',' + cast(sno as varchar(10)) + ',' , (SELECT distinct ',' + checkeditem + ',' FROM TBL_EDITPROFILE WHERE userid = '" + sUserID + "')) > 0 then 1 else 0 end Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 1 and 6";
                //sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , ',' + (DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', 'USER_INTEREST_IDS') + ',')) > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 1 and 6";
                sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , '," + sSelectedCategories + ",') > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 1 and 6";
            }
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetAllcategoriesByUserID(string sUserID)
    {
        try
        {
            string sqlquery = "";
            if (sUserID == "")
            {
                sqlquery = "select 0 Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1";
            }
            else
            {
                home clsHome = new home();
                string sSelectedCategories = clsHome.GetDetailsByUserID(sUserID, "USER_INTEREST_IDS");

                if (sSelectedCategories.Trim().Replace(",", "").Length <= 0)
                {
                    sSelectedCategories = "1,2";
                }
                //sqlquery = "select case when charindex(',' + cast(sno as varchar(10)) + ',' , (SELECT distinct ',' + checkeditem + ',' FROM TBL_EDITPROFILE WHERE userid = '" + sUserID + "')) > 0 then 1 else 0 end Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 1 and 6";
                //sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , ',' + (DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', 'USER_INTEREST_IDS') + ',')) > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1";
                sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , '," + sSelectedCategories +",') > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1";
            }
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getCategoriesWithAds()
    {
        try
        {
            string sQry = "";
            sQry = "SELECT DISTINCT L1_CATEGORY_SNO  FROM TBL_INTEREST_LEVEL_2  WHERE L2_CATEGORY_ID IN (SELECT CATEGORY FROM TBL_ADS_SMSPRODUCTS WHERE VISIBILITY_STATUS = 1)";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getcategoriessecondhalf()
    {
        try
        {
            string sqlquery = "select * from  tbl_interest_level_1 where sno between 7 and 12";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriessecondhalf(string sUserIntrest)
    {
        try
        {
            string sqlquery = "select CASE WHEN CHARINDEX(','  + CAST(SNO AS VARCHAR(30)) + ',', ',' +'" + sUserIntrest + "'+ ',') > 0 THEN 1 ELSE 0 END Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1 where sno between 7 and 12";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriesSecondHalf_byUserID(string sUserID)
    {
        try
        {
            string sqlquery = "";
            if (sUserID == "")
            {
                sqlquery = "select 0 Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1 where sno between 7 and 12";
            }
            else
            {
                home clsHome = new home();
                string sSelectedCategories = clsHome.GetDetailsByUserID(sUserID, "USER_INTEREST_IDS");

                if (sSelectedCategories.Trim().Replace(",", "").Length <= 0)
                {
                    sSelectedCategories = "1,2";
                }
                //sqlquery = "select case when charindex(',' + cast(sno as varchar(10)) + ',' , (SELECT distinct ',' + checkeditem + ',' FROM TBL_EDITPROFILE WHERE userid = '" + sUserID + "')) > 0 then 1 else 0 end Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 7 and 12";
                //sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , ',' + (DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', 'USER_INTEREST_IDS') + ',')) > 0 THEN 1 ELSE 0 END Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 7 and 12";
                sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , '," + sSelectedCategories + ",') > 0 THEN 1 ELSE 0 END Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 7 and 12";
            }
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void EditUserInterest(string sUserID, string sUserInterests)
    {
        try
        {
            string sQry = "UPDATE TBL_EDITPROFILE SET CHECKEDITEM = '" + sUserInterests + "' WHERE USERID = '" + sUserID + "'";

            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetUserInteret(string sUserID)
    {
        try
        {
            string sQry = "SELECT CHECKEDITEM FROM TBL_EDITPROFILE WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable getcategoriesAll()
    {
        try
        {
            string sqlquery = "select SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriesAll(string sUserIntrest)
    {
        try
        {
            string sqlquery = "select CASE WHEN CHARINDEX(','  + CAST(SNO AS VARCHAR(30)) + ',', ',' +'" + sUserIntrest + "'+ ',') > 0 THEN 1 ELSE 0 END Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getcategoriesAll_byUserID(string sUserID)
    {
        try
        {
            string sqlquery = "";
            if (sUserID == "")
            {
                sqlquery = "select 0 Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from  tbl_interest_level_1";
            }
            else
            {
                home clsHome = new home();
                string sSelectedCategories = clsHome.GetDetailsByUserID(sUserID, "USER_INTEREST_IDS");

                if (sSelectedCategories.Trim().Replace(",", "").Length <= 0)
                {
                    sSelectedCategories = "1,2";
                }

                //sqlquery = "select case when charindex(',' + cast(sno as varchar(10)) + ',' , (SELECT distinct ',' + checkeditem + ',' FROM TBL_EDITPROFILE WHERE userid = '" + sUserID + "')) > 0 then 1 else 0 end Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1  where sno between 1 and 6";
                //sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , ',' + (DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', 'USER_INTEREST_IDS') + ',')) > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1";
                sqlquery = "select CASE WHEN CHARINDEX(',' + CAST(SNO AS VARCHAR(10)) + ',' , '," + sSelectedCategories + ",') > 0 THEN 1 ELSE 0 END  Check_value, SNO, L1_CATEGORY_NAME, L1_CATEGORY_DESCRIPTION, L1_CATEGORY_IMAGE, L1_CATEGORY_TYPE from tbl_interest_level_1";
            }
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetLevel2Categories()
    {
        try
        {
            string sQry = "SELECT L1_CATEGORY_SNO,L2_CATEGORY_ID,L2_CATEGORY_NAME, L2_CATEGORY_DESCRIPTION, IS_ACTIVE FROM TBL_INTEREST_LEVEL_2";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public DataTable GetLevel2Categories(int L1_CategoryID)
    {
        try
        {
            string sQry = "SELECT L2_CATEGORY_ID,L2_CATEGORY_NAME, L2_CATEGORY_DESCRIPTION, IS_ACTIVE FROM TBL_INTEREST_LEVEL_2 WHERE L1_CATEGORY_SNO = " + L1_CategoryID.ToString();
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

}