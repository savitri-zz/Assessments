﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Calculations
/// </summary>
public class clsBankWallet : BaseClass
{
    public clsBankWallet()
	{
		
	}

    
    public DataTable calculateWalletBankAmount(string userid, string columnName, string tblname)
    {
        try
        {
            string SQLQuery = "select sum(cast(" + columnName + " as bigint)) as amount from " + tblname + "  where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertBankWalletAmount(string userid, string name, string mobile,string transferamt,string tds, string netamt)
    {
        try
        {
          //  string SQLQuery = "insert into tbl_BWTransferAmt (userid,name,mobileno,Tranferamt,TDS,Netamt,date,Tranferdate,status) values ('" + userid + "','" + name + "','" + mobile + "','" + transferamt + "','" + tds + "','" + netamt + "','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','UB')";


            string SQLQuery = "USP_insertBankWalletAmount  '" + userid + "','" + name + "','" + mobile + "','" + transferamt + "','" + tds + "','" + netamt + "'";



            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable alreadytransferbank(string strUserid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Tranferamt as float)) as amount from tbl_BWTransferAmt  where userid = '" + strUserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable alreadytransferproduct(string strUserid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Tranferamt as bigint)) as amount from tbl_PWTransferAmt  where userid = '" + strUserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertProductWalletAmount(string userid, string name, string mobile, string transferamt)
    {
        try
        {
           // string SQLQuery = "insert into tbl_PWTransferAmt (userid,name,mobileno,Tranferamt,date,Tranferdate,status) values ('" + userid + "','" + name + "','" + mobile + "','" + transferamt + "','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','UP')";

            string SQLQuery = "USP_insertProductWalletAmount  '" + userid + "','" + name + "','" + mobile + "','" + transferamt + "'" ;


            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectWalletBankAmount(string userid, string tblname)
    {
        try
        {
            string SQLQuery = "select * from " + tblname + "  where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertWalletAmountall(string userid,  string mobile,string creditamt,string debitamt,string date, string status)
    {
        try
        {
          //  string SQLQuery = "insert into tbl_walletalltransaction (userid,mobileno,creditedamount,debitedamt,date,status) values ('" + userid + "','" + mobile + "','" + creditamt + "','" + debitamt + "','" + date + "','" + status + "')";

            string SQLQuery = "USP_insertWalletAmountall    '" + userid + "','" + mobile + "','" + creditamt + "','" + debitamt + "','" + date + "','" + status + "'";

            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertWalletAmountproduct(string userid, string mobile, string creditamt, string debitamt, string date, string status)
    {
        try
        {

          string SQLQuery = "insert into tbl_walletalltransactionproductwallet (userid,mobileno,creditedamount,debitedamt,date,status) values ('" + userid + "','" + mobile + "','" + creditamt + "','" + debitamt + "','" + date + "','" + status + "')";

          //string SQLQuery = "USP_insertWalletAmountproduct  '" + userid + "','" + mobile + "','" + creditamt + "','" + debitamt + "','" + date + "','" + status + "'";

            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 

    public DataTable checkalreadexistcre(string userid, string mobile, string balance, string payoutdate, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransaction  where userid = '" + userid + "' and mobileno='" + mobile + "' and  creditedamount='" + balance + "'  and date='" + payoutdate + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable checkalreadexistcreprd(string userid, string mobile, string balance, string payoutdate, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransactionproductwallet  where userid = '" + userid + "' and mobileno='" + mobile + "' and  creditedamount='" + balance + "'  and date='" + payoutdate + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable checkalreadexistcreprd1(string userid, string payoutdate, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransactionproductwallet  where userid = '" + userid + "' and date='" + payoutdate + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable checkalreadexistdeb(string userid, string mobile, string balance, string payoutdate, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransaction  where userid = '" + userid + "' and mobileno='" + mobile + "' and  debitedamt='" + balance + "' and date='" + payoutdate + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable checkalreadexistdebprd(string userid, string mobile, string balance, string payoutdate, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransactionproductwallet  where userid = '" + userid + "' and mobileno='" + mobile + "' and  debitedamt='" + balance + "' and date='" + payoutdate + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataTable selectproductdetail(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransactionproductwallet  where userid = '" + userid + "' order by cast(date as date) desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable selectbankdetail(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_walletalltransaction  where userid = '" + userid + "' order by cast(date as date) desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable updatebankdetailcheck(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails  where userid = '" + userid + "' and status='1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

public DataTable GetPayoutwalletAmt(string userid)
    {

        try
        {
            string SQLQuery = "select sum(CAST(Amount as int)) as Amount from tbl_Debit_Wallet where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 public DataTable GetBankwallet(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_Userside_BW_PW_Amt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insert_BW_PW_Amount(string userid, string mobileno, string name, string Netamt, string DebitAmt, string Bankwallet, string Productwallet)
    {
        try
        {

            //string SQLQuery = "insert into tbl_Userside_BW_PW_Amt(userid,mobileno,name,Netamt,DebitAmt,Bankwallet,Productwallet) values ('" + userid + "','" + mobileno + "','" + name + "','" + Netamt + "','" + DebitAmt + "','" + Bankwallet + "','" + Productwallet + "')";

            string SQLQuery = "USP_Insert_BW_PW_Amount  '" + userid + "','" + mobileno + "','" + name + "','" + Netamt + "','" + DebitAmt + "','" + Bankwallet + "','" + Productwallet + "'";



            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Update_BW_PW_Amount(string userid, string Netamt, string DebitAmt, string Bankwallet, string Productwallet)
    {
        try
        {
           // string SQLQuery = "update tbl_Userside_BW_PW_Amt set Netamt = '" + Netamt + "', DebitAmt = '" + DebitAmt + "',Bankwallet = '" + Bankwallet + "',Productwallet = '" + Productwallet + "' where userid = '"+userid+"' ";

            string SQLQuery = "USP_Update_BW_PW_Amount  '" + Netamt + "','" + DebitAmt + "','" + Bankwallet + "','" + Productwallet + "','" + userid + "'";




            int introwaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetTotalwallet(string userid)
    {

        try
        {
            string SQLQuery = "select * from bankwallet where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetProductnBankWallet(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_FinalPay where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertorUpate_FinalPay(string userid, string mobileno, string credit, string debit, string must, string balance, string productWallet, string bankWallet)
    {
        try
        {
            string SQLQuery = string.Empty;
            int introwaffect = 0;
            SQLQuery = "select * from tbl_FinalPay where userid='" + userid + "'";
            DataTable dt = new DataTable();
            dt = GetDataTable(SQLQuery, true);

            if (dt.Rows.Count == 1)
            {
                SQLQuery = "update tbl_FinalPay set Debit = '" + debit + "', Credit = '" + credit + "',Must = '" + must + "',ProductWallet = '" + productWallet + "',BankWallet = '" + bankWallet + "',Balance = '" + balance + "' where userid = '" + userid + "' ";
                introwaffect = fnExecuteNonQuery(SQLQuery, true);
            }
            else
            {

                SQLQuery = "insert into tbl_FinalPay(UserID,MobileNo,Debit,Credit,Must,Balance,ProductWallet,BankWallet) values ('" + userid + "','" + mobileno + "','" + debit + "','" + credit + "','" + must + "','" + balance + "','" + productWallet + "','" + bankWallet + "')";
                introwaffect = fnExecuteNonQuery(SQLQuery, true);
            }
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable ZGetInvitationBonusAmount(string sUserID)
    {
        try
        {
            string sQry = " SELECT CAST(CURRENT_BALANCE AS NUMERIC(10,0)) CURRENT_BALANCE ,  CAST( ISNULL(AMOUNT_USED , 0) AS NUMERIC(10,0)) AMOUNT_USED FROM TBL_INVITATION_BONUS_POINTS_REDIM WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void zUpdateRedimBonusAmount(string sUserID, int iAmount)
    {
        try
        {
            string sQry = "UPDATE TBL_INVITATION_BONUS_POINTS_REDIM SET CURRENT_BALANCE = CURRENT_BALANCE - " + iAmount + " , AMOUNT_USED =  AMOUNT_USED + "+ iAmount +" WHERE USERID = '" + sUserID + "'";
            int introwaffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public void zUpdateRedimBonusPoints(string sUserID, int BonusPoints)
    {
        try
        {
            string sQry = "UPDATE TBL_INVITATION_BONUS_POINTS SET BONUS_POINTS_USED = ISNULL(BONUS_POINTS_USED , 0) + " + BonusPoints + "  WHERE USERID = '" + sUserID + "'";
            int introwaffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    public DataTable GetInvitationBonusPoints(string sUserID)
    {
        try
        {
            string sQry = "SELECT  ISNULL(BONUS_POINTS_GIVEN,0) - ISNULL(BONUS_POINTS_USED,0) INVITATION_BONUS_POINTS FROM TBL_INVITATION_BONUS_POINTS WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateUserWalletCurrentBalances(string sUserID)
    {
        try
        {
            string sQry = "Exec dbo.USP_UPDATE_USER_WALLET_CURRENT_BALANCES '"+ sUserID +"'";
            int introwaffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex) 
        {
            
            throw ex;
        }
    }

    public DataTable GetUserWalletCurrentBalances(string sUserID)
    {
        
        try
        {
            string sQry = "SELECT CAST(ISNULL(INVITATION_BONUS_AMT , 0) AS NUMERIC(10,0)) INVITATION_BONUS_AMT,  CAST(ISNULL(GIFT_AMOUNT, 0) AS NUMERIC(10,0)) GIFT_AMOUNT FROM TBL_USER_WALLET_CURRENT_BALANCES WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw;
        }
    }

    public DataTable ZGetUserInvitationBonusAmt(string sUserID)
    {
        try
        {
            string sQry = "SELECT CAST(ISNULL(CURRENT_BALANCE , 0) - ISNULL(AMOUNT_USED ,0) AS INT) INVITATION_BONUS_AMT FROM TBL_INVITATION_BONUS_POINTS_REDIM WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public void UpdateUserWalletCurrentBalances(string sUserId, string sAmountType, int iAmount)
    {
        try
        {
            string sQry = ""; 
            if (sAmountType == "InvitationBonusAmt")
            {
                sQry = "UPDATE TBL_USER_WALLET_CURRENT_BALANCES SET INVITATION_BONUS_AMT = "+ iAmount +" WHERE USERID = '"+ sUserId +"'";
                
            }
            if (sAmountType == "GiftAmount")
            {
                sQry = "UPDATE TBL_USER_WALLET_CURRENT_BALANCES SET INVITATION_BONUS_AMT = 0 AND GIFT_AMOUNT = " + iAmount + "  WHERE USERID = '" + sUserId + "'";
            }

            int introwaffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw;
        }
    }

    public DataTable GetInvitationsCreditAmount(string sUserID)
    {

        // This method is written by Sudhindra on 28-Jan. Purpose : getting the invitation bonus amount from product wallet table only... not from the current balances

        try
        {
            string sQry = "SELECT ISNULL( SUM( CAST(REPLACE(CREDITEDAMOUNT , '.00','') AS INT)) , 0) INVITATION_BONUS_AMT FROM TBL_WALLETALLTRANSACTIONPRODUCTWALLET WHERE USERID='" + sUserID + "' AND STATUS = 'IBA'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }
    
    
    public DataTable GetGiftCreditAmount(string sUserID)
    {

        // This method is written by Sudhindra on 28-Jan. Purpose : getting the gift bonus amount from product wallet table only... not from the current balances

        try
        {
            string sQry = "SELECT ISNULL(SUM( CAST(REPLACE(CREDITEDAMOUNT , '.00', '') AS INT)) , 0) GIFT_AMOUNT FROM TBL_WALLETALLTRANSACTIONPRODUCTWALLET WHERE USERID='" + sUserID + "' AND STATUS = 'GBA'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public void UpdateFinalPayBalance(string sUserid, string sConsumedAmt)
    {

        // This method is written by Sudhindra on 28-Jan. Purpose : updating the final pay values after successful recharge 

        try
        {
            string sQry = "UPDATE TBL_finalpay SET DEBIT = REPLACE(DEBIT , '.00','') - " + Convert.ToInt32(sConsumedAmt) + ", BALANCE = REPLACE(BALANCE , '.00', '') - " + Convert.ToInt32(sConsumedAmt) + ", PRODUCTWALLET  = REPLACE(PRODUCTWALLET , '.00', '') -  " + Convert.ToInt32(sConsumedAmt) + " WHERE USERID = '"+ sUserid +"'";
            int introwaffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

}