﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class userDetails : BaseClass
{
    public userDetails()
    {
    }

    public void Insertprofile(editProfileRegistration reg)
    {
        try
        {
            //StringBuilder sb = new StringBuilder();
            //sb.Append("INSERT INTO tbl_editprofile(gender,DOB_birth,country,state,district,[city/area],othercityarea,address,postalcode,mobileno,email,");
            //sb.Append("education,occupation,industry,incomerange,checkeditem,name,userid) values('" + reg.gender + "', '" + reg.dob + "',");
            //sb.Append("'" + reg.country + "',");
            //sb.Append("'" + reg.state + "',");
            //sb.Append("'" + reg.district + "',");
            //sb.Append("'" + reg.city + "',");
            //sb.Append("'" + reg.othercityarea + "',");
            //sb.Append("'" + StringValidation.checkString(reg.address) + "',");
            //sb.Append("'" + reg.pincode + "',");
            //sb.Append("'" + reg.mobileno + "',");
            //sb.Append("'" + reg.emailid + "',");
            //sb.Append("'" + reg.education + "',");
            //sb.Append("'" + reg.occupation + "',");
            //sb.Append("'" + reg.industry + "',");
            //sb.Append("'" + reg.incomerange + "',");
            //sb.Append("'" + reg.checkeditem + "',");
            //sb.Append("'" + reg.fname + "',");
            //sb.Append("'" + reg.userid + "')");
            //int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);


            string sQry = "EXEC USP_INSERT_UPDATE_EDITPROFILE '" + reg.fname + "' , '" + reg.gender + "' , '" + reg.dob + "' , '" + reg.country + "' , '" + reg.state + "' , ";
            sQry = sQry + "  '" + reg.district + "' , '" + reg.city + "' , '" + reg.othercityarea + "', '" + StringValidation.checkString(reg.address) + "' , '" + reg.pincode + "', ";
            sQry = sQry + " '" + reg.mobileno + "' , '" + reg.emailid + "' , '" + reg.occupation + "' , '" + reg.industry + "' , '" + reg.incomerange + "' , '" + reg.checkeditem + "' , ";
            sQry = sQry + " NULL , '" + reg.education + "' , '" + reg.userid + "' , '" + reg.dob + "' , NULL ";
            int intRowAffect = fnExecuteNonQuery(sQry, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataTable getUserDetails(string serialno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_editprofile where userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatetbl_userwallet(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_userwallet  ");
            sb.Append("set");
            sb.Append(" name = '" + reg.fname + "', ");
            sb.Append(" mboile = '" + reg.mobileno + "', ");
            sb.Append(" emailid = '" + reg.emailid + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getEducation()
    {
        try
        {
            string SQLQuery = "select * from tbl_education";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getOccupation()
    {
        try
        {
            //string SQLQuery = "select * from tbl_occupation";
            string SQLQuery = " SELECT ID, OCCUPATION FROM TBL_OCCUPATION ORDER BY ID";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getIndustry()
    {
        try
        {
            string SQLQuery = "select * from tbl_industry";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatetbl_userwalletstatus(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_Userwalletstatus  ");
            sb.Append("set");
            sb.Append(" mobileno = '" + reg.mobileno + "' where useid = '" + reg.userid + "'");



            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getIncome()
    {
        try
        {
            string SQLQuery = "select * from tbl_incomerange";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getRegistrationDetails(string serialno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getinvetation(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno= '" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getRegistrationDetailsfree(string serialno)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where  userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getinterest()
    {
        try
        {
            string SQLQuery = "select * from tbl_interest";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getdate()
    {
        try
        {
            string sqlquery = "Select * from tbl_date";
            return GetDataTable(sqlquery, true);


        }

        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getmonth()
    {
        try
        {
            string sqlquery = "Select * from tbl_month";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }


    }

    public DataTable getyr()
    {
        try
        {
            string sqlquery = "Select * from tbl_year order by id ASC";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }



    }

    public void zUpdateProfile(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_editprofile ");
            sb.Append("set");
            sb.Append(" name = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            sb.Append(" gender = '" + reg.gender + "', ");
            sb.Append(" DOB_birth = '" + reg.dob + "', ");
            sb.Append(" country = '" + reg.country + "', ");
            sb.Append(" state = '" + reg.state + "', ");
            sb.Append(" district = '" + reg.district + "', ");
            sb.Append(" [city/area] = '" + reg.city + "', ");
            sb.Append(" othercityarea = '" + reg.othercityarea + "', ");
            sb.Append(" address = '" + reg.address + "', ");
            sb.Append(" postalcode = '" + reg.pincode + "', ");
            sb.Append(" email = '" + reg.emailid + "', ");
            sb.Append(" education = '" + reg.education + "', ");
            sb.Append(" occupation = '" + reg.occupation + "', ");
            sb.Append(" industry = '" + reg.industry + "', ");
            sb.Append(" incomerange = '" + reg.incomerange + "', ");
            sb.Append(" checkeditem = '" + reg.checkeditem + "' where userid = '" + reg.userid + "'");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updateRegistration(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_registration ");
            sb.Append("set");
            sb.Append(" fullname = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            // This below line is added by Sudhindra on 12-Aug-2014. Purpose : updating the state and city also after changing the edit profile
            sb.Append(" STATE = '" + reg.state + "', CITY = '" + reg.city + "',  ");
            sb.Append(" emailid = '" + reg.emailid + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updateBankdetails(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_updatebankdetails ");
            sb.Append("set");
            sb.Append(" Payeename = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            sb.Append(" emailid = '" + reg.emailid + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updateinvetation(editProfileRegistration reg, string mobile)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_invitefriends ");
            sb.Append("set");
            sb.Append(" fname = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            sb.Append(" emailid = '" + reg.emailid + "' where mobileno = '" + mobile + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateInviteFriends(editProfileRegistration regDto)
    {
        try
        {
            string sQry = " UPDATE TBL_INVITEFRIENDS  SET FNAME = '" + regDto.fname.Replace("'", "''") + "', GENDER = '" + regDto.gender + "' , EMAILID = '" + regDto.emailid + "' ,";
            sQry = sQry + " /*AREA = '" + regDto.area + "', */ ADDRESS = '" + regDto.address + "', PINCODE = '" + regDto.pincode + "', STATE = '" + regDto.state + "', 	DISTRICT = '" + regDto.district + "' , CITY = '" + regDto.city + "', OCCUPATION = '" + regDto.occupation + "', CHECKEDITEM = '" + regDto.checkeditem + "'";
            sQry = sQry + " WHERE userid = '" + regDto.userid + "'";
            //sQry = sQry + " WHERE MOBILENO = '" + regDto.mobileno + "'";

            int iRowsAffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    /**** Add liked category ***/
    public void UpdateCategoryToInvFriends(string sUid, string CategoryIds)
    {
        try
        {
            string sQry = "UPDATE TBL_INVITEFRIENDS SET CHECKEDITEM = '" + CategoryIds + "' WHERE USERID = '" + sUid + "' ";
            
            int iRowsAffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateLikedCategoryToEditprofile(string sUid, string CategoryIds)
    {
        try
        {
            string sQry = "UPDATE TBL_EDITPROFILE SET CHECKEDITEM = '" + CategoryIds + "' WHERE USERID = '" + sUid + "'";

            int iRowsAffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    /*** add liked category ***/
    /******* Remove category *******/
    public void RemoveLikedcategoryByUserID(string sUserID, int CategoryId)
    {
        try
        {
            string sqlquery = "EXEC DBO.USP_REMOVE_USER_INTEREST_CATEGORY '" + sUserID + "', " + CategoryId + "";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    /****** End of remove category ********/
    public DataTable getpaid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfree(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetails1(string serialno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_freeditprofile where userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updateProfile1(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_freeditprofile ");
            sb.Append("set");
            //sb.Append(" name = '" + reg.fname + "', ");
            sb.Append(" gender = '" + reg.gender + "', ");
            sb.Append(" DOB_birth = '" + reg.dob + "', ");
            sb.Append(" country = '" + reg.country + "', ");
            sb.Append(" state = '" + reg.state + "', ");
            sb.Append(" district = '" + reg.district + "', ");
            sb.Append(" [city/area] = '" + reg.city + "', ");
            sb.Append(" othercityarea = '" + reg.othercityarea + "', ");
            sb.Append(" address = '" + reg.address + "', ");
            sb.Append(" postalcode = '" + reg.pincode + "', ");
            //sb.Append(" email = '" + reg.emailid + "', ");
            sb.Append(" education = '" + reg.education + "', ");
            sb.Append(" occupation = '" + reg.occupation + "', ");
            sb.Append(" industry = '" + reg.industry + "', ");
            sb.Append(" incomerange = '" + reg.incomerange + "', ");
            sb.Append(" checkeditem = '" + reg.checkeditem + "' where userid = '" + reg.userid + "'");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updateRegistration1(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_freememreg ");
            sb.Append("set");
            sb.Append(" name = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            sb.Append(" emailid = '" + reg.emailid + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertprofile1(editProfileRegistration reg)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO tbl_freeditprofile(gender,DOB_birth,country,state,district,[city/area],othercityarea,address,postalcode,");
            sb.Append("education,occupation,industry,incomerange,checkeditem,userid) values('" + reg.gender + "', '" + reg.dob + "',");
            sb.Append("'" + reg.country + "',");
            sb.Append("'" + reg.state + "',");
            sb.Append("'" + reg.district + "',");
            sb.Append("'" + reg.city + "',");
            sb.Append("'" + reg.othercityarea + "',");
            sb.Append("'" + reg.address + "',");
            sb.Append("'" + reg.pincode + "',");
            //sb.Append("'" + reg.mobileno + "',");
            //sb.Append("'" + reg.emailid + "',");
            sb.Append("'" + reg.education + "',");
            sb.Append("'" + reg.occupation + "',");
            sb.Append("'" + reg.industry + "',");
            sb.Append("'" + reg.incomerange + "',");
            sb.Append("'" + reg.checkeditem + "',");
            sb.Append("'" + reg.userid + "')");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public void updatefreemam(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_freememreg ");
            sb.Append("set");
            sb.Append(" name = '" + reg.fname + "', ");
            sb.Append(" mobileno = '" + reg.mobileno + "', ");
            // This below line added By Sudhindra on 12-Aug-2014. Purpose : state and city are not getting updated after changing in edit profile.
            sb.Append(" state = '" + reg.state + "', city = '" + reg.city + "',");
            sb.Append(" emailid = '" + reg.emailid + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable interestdisplay(string status)
    {
        try
        {
            string sqlquery = "Select sno as sno, items as differentstatus from tbl_dynamicstatus where status='" + status + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updateinterset(editProfileRegistration reg)
    {
        try
        {

            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_editprofile ");
            sb.Append("set");
            sb.Append(" checkeditem = '" + reg.checkeditem + "' where userid = '" + reg.userid + "'");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getUserDetailsMobilebno(string mobileno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where mobileno= '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetailsfreeMobilebno(string mobileno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_freememreg where mobileno= '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetailsnonMobilebno(string mobileno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_nonmemreg where mobileno= '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetailseditMobilebno(string mobileno, string serialno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_editprofile where mobileno= '" + mobileno + "' or userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetailseditMobilebno2(string mobileno, string serialno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_editprofile where mobileno= '" + mobileno + "' and userid= '" + serialno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getUserDetailseditMobilebno1(string mobileno)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_editprofile where mobileno= '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getstatuswallet(string mobileno)
    {
        try
        {
            string sql = "Select * from tbl_Userwalletstatus  where useid='" + mobileno + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }



    public void UpdateMobileChange(string UserID, string NewMobileNo)
    {
        string SQLquery = "Exec USP_CHANGE_MOBILE_NUMBER'" + UserID + "','" + NewMobileNo + "'";
        int intRowAffect = fnExecuteNonQuery(SQLquery, true);
    }


    public DataTable GetServerDatetime()
    {
        try
        {
            string SQLquery = "Select GetDate() ServerDate, DATENAME(DW,GETDATE()) SERVER_DAY";
            return GetDataTable(SQLquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetSongs(string UserId)
    {
        try
        {
            string SQLquery = "EXEC DBO.USP_GET_SONGS_BY_USERID'" + UserId + "'";
            return GetDataTable(SQLquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetSongsOnBasedLang(string LanguageId)
    {
        try
        {
            string SQLquery = "Select * from tbl_Songs Where LanguageID ='" + LanguageId + "'";
            return GetDataTable(SQLquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetTestmonials()
    {
        try
        {
            string SQLQUERy = "select top 1 * from tbl_testmonials order by newid()";
            return GetDataTable(SQLQUERy, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetLang4Songs()
    {
        try
        {
            string SQLQUERy = "SELECT LANGUAGE_ID, LANGUAGE_NAME FROM TBL_LANGUAGE_MASTER WHERE LANGUAGE_ID IN (SELECT LANGUAGEID FROM TBL_SONGS)";
            return GetDataTable(SQLQUERy, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetLang4TVchannels()
    {
        try
        {
            string SQLQUERy = "SELECT TOP 6 LANGUAGE_ID, LANGUAGE_NAME FROM TBL_LANGUAGE_MASTER ORDER BY LANGUAGE_ID ";
            return GetDataTable(SQLQUERy, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetDefaultLanguageByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT LANGUAGE_ID, LANGUAGE_NAME FROM TBL_LANGUAGE_MASTER WHERE CHARINDEX( DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', 'STATE_ID') , REGIONS ) > 0";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetAgeGroup()
    {
        try
        {
            string sQry = "SELECT ID, AGE_GROUP FROM TBL_AGE_GROUP ORDER BY ID";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateCompleteCPdata(string sGender, string sAgeGroup, string sArea, string sAddress, string sPinCode, string sState, string sDistrict, string sCity, string sOccupation, string sMobileno, string sRefID, string sUserID, string sEmailID)
    {
        try
        {
            string sQry = "";

            sQry = "UPDATE TBL_INVITEFRIENDS SET GENDER = '" + sGender + "', AGEGROUP = '" + sAgeGroup + "', AREA = '" + sArea + "', ADDRESS = '" + sAddress + "', PINCODE = '" + sPinCode + "', ";
            sQry = sQry + " STATE = '" + sState + "', DISTRICT = '" + sDistrict + "', CITY = '" + sCity + "', OCCUPATION = '" + sOccupation + "' , EMAILID = '" + sEmailID + "' WHERE MOBILENO = '" + sMobileno + "' AND INIVTED_USER = '" + sRefID + "'";

            int intRowAffect = fnExecuteNonQuery(sQry, true);

            sQry = "";
            sQry = sQry + "UPDATE TBL_FREEMEMREG SET EMAILID = '" + sEmailID + "' , STATE = '" + sState + "', CITY = '" + sCity + "' WHERE USERID = '" + sUserID + "' ";

            intRowAffect = fnExecuteNonQuery(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool bIsValidEmailDomain(string sEmailID)
    {
        try
        {
            bool bRetVal = false;

            string sQry = "EXEC DBO.USP_IS_VALID_EMAIL_DOMAIN '"+ sEmailID +"'";
            DataTable dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                bRetVal = Convert.ToBoolean(dt.Rows[0]["RETVAL"].ToString());
            }

            return bRetVal;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public DataTable GetActivationsByIP(string sIP)
    {
        try
        {
            string sQry = "SELECT * FROM TBL_SQL_TRACE WHERE ACTIVITY = 'ACTIVATION PROCESS'";
            sQry = string.Concat(sQry, " AND REPLACE(TRACE, 'Activation from ip :','') = '"+ sIP +"'");
            sQry = string.Concat(sQry, " AND TRACE_TIME > DATEADD(DAY, -1, GETDATE())");

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public string GetConfigSettingValue(string sConfigID)
    {
        try
        {
            string sRetStr = "";
            string sQry = "SELECT CONFIG_VALUE FROM TBL_CONFIGURATION_SETTINGS WHERE CONFIG_SETTING = '"+ sConfigID +"'";
            DataTable dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                sRetStr = dt.Rows[0]["CONFIG_VALUE"].ToString();
            }

            return sRetStr;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

}