﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration ;
using System.Text;
using System.IO;

/// <summary>
/// Summary description for ExceptionLogging
/// </summary>
public class ExceptionLogging : BaseClass
{
	public ExceptionLogging()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void LogExceptions(string moduleName, string exceptionMessage, string methodName, string loggedBy)
    {
        try
        {
           
                string sqlQuery = string.Empty;
                sqlQuery = string.Concat("insert into tbl_MfloatExceptionLogs(modulename, exceptionmessage,methodname, loggedby) values('", moduleName, "','", exceptionMessage.Substring(0,200),"','", methodName, "','", loggedBy,"')");

                // Commented by Sudhindra on 10-Mar-2015. Purpose : Data is growing rapidly. Hence not inserting into the database table.
                //int intRowAffect = fnExecuteNonQuery(sqlQuery, true);
            
        }
        catch (Exception ex)
        {
            LogExceptionintoFile(moduleName, exceptionMessage, methodName, loggedBy);

        }
    }

    public static void LogExceptionintoFile(string moduleName, string exceptionMessage, string methodName, string loggedBy)
    {
        StreamWriter streamWriter = null;
        try
        {
            string folder= System.Web.HttpContext.Current.Server.MapPath("Default.aspx");
            folder=folder.Substring(0,folder.LastIndexOf('\\')+1);
            string errorFilesFolderPath =string.Concat(folder,ConfigurationManager.AppSettings["errorFileFolderPath"]);
            string toDayfile = DateTime.Today.ToString("dd-MM-yyyy");

            if (!Directory.Exists(errorFilesFolderPath))
            {
                Directory.CreateDirectory(errorFilesFolderPath);
            }

            string[] exceptionFiles = System.IO.Directory.GetFiles(errorFilesFolderPath, string.Concat(toDayfile, ".txt"));

            if (errorFilesFolderPath != null)
            {
                string errorFilePath = string.Concat(errorFilesFolderPath, "\\", toDayfile, ".txt");
                if (exceptionFiles.Length == 0)
                {
                    File.Create(errorFilePath).Close();

                }
                streamWriter = new StreamWriter(errorFilePath, true);
                streamWriter.WriteLine("===========================================================================================================");
                streamWriter.WriteLine(DateTime.Now.ToString("HH:mm tt"));
                streamWriter.WriteLine("New log");
                streamWriter.WriteLine("===========================================================================================================");

                if (!string.IsNullOrEmpty(moduleName))
                    streamWriter.WriteLine("moduleName=>" + moduleName);
                if (!string.IsNullOrEmpty(moduleName))
                    streamWriter.WriteLine("exceptionMessage=>" + exceptionMessage);
                if (!string.IsNullOrEmpty(moduleName))
                    streamWriter.WriteLine("methodName=>" + methodName);
                if (!string.IsNullOrEmpty(moduleName))
                    streamWriter.WriteLine("loggedBy=>" + loggedBy);
                streamWriter.Close();

            }
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }

    }
}