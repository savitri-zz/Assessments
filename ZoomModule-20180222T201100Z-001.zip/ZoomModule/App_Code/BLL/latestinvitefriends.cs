﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;



/// <summary>
/// Summary description for latestinvitefriends
/// </summary>
public class latestinvitefriends : BaseClass 
{
	public latestinvitefriends()
	{
		//
		// TODO: Add constructor logic here
		//
	}

     public DataTable freemobileupgrade(string mobile)
      {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno='" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable interestdisplay(string status)
    {
        try
        {
            string sqlquery = "Select sno as sno, items as differentstatus from tbl_dynamicstatus where status='" + status + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Nonmemlogininvite1(string mobileno, string userpwd, string name, string joindate, string emailid, string referid, string refmobile, 
        string userid, string placement, string placementID, string sponsorUserID, string referenceID)
    {
        try
        {
           /* string SQLQuery = "insert into tbl_freememreg(mobileno, userpwd, name,joindate,emailid,referal_id,referal_mobile,userid,activeuser,status) values ('" + mobileno + "', '" + userpwd + "', '" + name + "', '" + joindate + "','" + emailid + "','" + referid + "','" + refmobile + "','" + userid + "','NA','1')";*/
            string SQLQuery = "USP_Bite2Byte_login_Nonmemlogininvite1    '" + mobileno + "', '" + userpwd + "', '" + name + "', '" + joindate + "','"
                + emailid + "','" + referid + "','" + refmobile + "','" + userid + "','" + placement + "','" + placementID + "','" + sponsorUserID + "','" + referenceID + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            //Added By SAVITRI
            if (intRowAffect > 0)
            {
                //RunScheduler();
            }
            //Added By SAVITRI
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //Added By SAVITRI
  

    //Added By SAVITRI
   

    public string getAutoPlacementValue(string invitedUserID)
    {
        string autoPlacment = "0";
        DataTable dtDetails;
        try
        {
            string sqlquery = "select top 1 placement  from tbl_invitefriends where inivted_user='"+invitedUserID+"' order by sno desc";
           dtDetails=  GetDataTable(sqlquery, true);
           if (dtDetails.Rows.Count > 0)
           {
               if (string.IsNullOrEmpty(dtDetails.Rows[0][0].ToString() ))
               {
                   autoPlacment = "2";
               }
               else
                   autoPlacment = dtDetails.Rows[0][0].ToString();
           }
           else
           {
               autoPlacment = "2";
           }
           return autoPlacment;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public string getAutoPlacementValuefromFreeMemreg(string invitedUserID)
    {
        string autoPlacment = "0";
        DataTable dtDetails;
        try
        {
            string sqlquery = "select top 1 placement  from tbl_freememreg where referalID='" + invitedUserID + "' order by sno desc";
            dtDetails = GetDataTable(sqlquery, true);
            if (dtDetails.Rows.Count > 0)
            {
                if (string.IsNullOrEmpty(dtDetails.Rows[0][0].ToString()))
                {
                    autoPlacment = "2";
                }
                else
                    autoPlacment = dtDetails.Rows[0][0].ToString();
            }
            else
            {
                sqlquery = "select top 1 placement  from tbl_registration where referid='" + invitedUserID + "' order by sno desc";
                dtDetails = GetDataTable(sqlquery, true);
                if (dtDetails.Rows.Count > 0)
                {

                    if (string.IsNullOrEmpty(dtDetails.Rows[0][0].ToString()))
                    {
                        autoPlacment = "2";
                    }
                    else
                        autoPlacment = dtDetails.Rows[0][0].ToString();
                }
                else
                    autoPlacment = "2";
            }
            return autoPlacment;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    



 

    public DataTable Getddlstates()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddldistricts(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_district where id =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendagain(string inviteeno, string mobile, string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user='" + inviteeno + "' and mobileno='" + mobile + "' and invited_user_status='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpaidetail(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno= '" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getfreedetail(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno= '" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable paidinvitee(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where  mobileno='" + mobile + "' and invited_user_status='2'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable freeinvitee(string mobile)
    {
        try
        {
            string sqlquery = "select * from tbl_invitefriends where  mobileno='" + mobile + "' and invited_user_status='1'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updatepaidinvitee(editProfileRegistration reg1, string mobile)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" update tbl_invitefriends ");
            sb.Append("set");

            sb.Append(" inivted_user = '" + reg1.inivted_user + "', ");
            sb.Append(" fname = '" + reg1.fname + "', ");
            sb.Append(" lname = '" + reg1.lname + "', ");
            sb.Append(" gender = '" + reg1.gender + "', ");
            sb.Append(" agegroup = '" + reg1.agegroup + "', ");
            sb.Append(" emailid = '" + reg1.emailid + "', ");
            sb.Append(" area = '" + reg1.area + "', ");
            sb.Append(" address = '" + StringValidation.checkString(reg1.address) + "', ");
            sb.Append(" pincode = '" + reg1.pincode + "', ");
            sb.Append(" country = '" + reg1.country + "', ");
            sb.Append(" state = '" + reg1.state + "', ");
            sb.Append(" district = '" + reg1.district + "', ");
            sb.Append(" city = '" + reg1.city + "', ");
            sb.Append(" checkeditem = '" + reg1.checkeditem + "', ");
            sb.Append(" invited_date = '" + reg1.invited_date + "', ");
            sb.Append(" status = '" + reg1.status + "', ");
            sb.Append(" invited_user_status = '" + reg1.invited_user_status + "', ");
            sb.Append(" active_status = '" + reg1.active_status + "', ");
            sb.Append(" points = '" + reg1.points + "', ");
            sb.Append(" occupation = '" + reg1.occupation + "' where mobileno = '" + mobile + "'");

            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatecontactcountonly(string count, string uid)
    {
        try
        {
            string SQLQuery = "update tbl_invitecount set totalcount = '" + count + "' where uid = '" + uid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertcontactcount(string uid, string totalcount, string invitedate)
    {
        try
        {
            string SQLQuery = "insert into tbl_invitecount (uid, totalcount, invitedate) values ('" + uid + "', '" + totalcount + "', '" + invitedate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable invitefriendcountexits(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitecount where uid='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Zinvitefriends(editProfileRegistration reg1)
    {
        try
        {
            // Modified by Sudhindra on 08-Jul-2014. Purpose : inserting "invited through" also
            string[] strArrList = { "@inivted_user", "@fname", "@lname", "@gender", "@agegroup", "@mobileno", "@emailid", "@area", "@address", "@pincode", "@country", "@state", "@district", "@city", "@occupation", "@checkeditem", "@invited_date", "@status", "@invited_user_status", "@active_status", "@userid","@placement",
                                      "@placementid","@SponsorUserID","@referid", "@INVITED_THROUGH" };
            string[] strArrValues = { reg1.inivted_user.ToString(),reg1.fname.ToString(), reg1.lname.ToString(),reg1.gender.ToString(), reg1.agegroup.ToString(), reg1.mobileno.ToString(),reg1.emailid.ToString(), reg1.area.ToString(), StringValidation.checkString(reg1.address.ToString()),reg1.pincode.ToString(),
                                        reg1.country.ToString(), reg1.state.ToString(), reg1.district.ToString(), reg1.city.ToString(), reg1.occupation.ToString(),reg1.checkeditem.ToString(),reg1.invited_date.ToString(), reg1.status.ToString(),reg1.invited_user_status.ToString(), reg1.active_status.ToString(), reg1.userid.ToString() , reg1.Placement,
                                    reg1.PlacementID, reg1.SponsorUserID, reg1.ReferID , reg1.InvitedThrough};


           int intRowAffect = fnRunProcedure("sp_invitefriends", strArrList, strArrValues, true);


        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public string pwdGenerat(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return pwdGenerat(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public DataTable freemobileexits(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable paidmobileexits(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Nonmemlogininvite(string mobileno, string userpwd, string name, string joindate, string emailid, string referid, string userid)
    {
        try
        {
            string SQLQuery = "insert into tbl_nonmemreg(mobileno, userpwd, name,joindate,emailid,Referenceid,userid) values ('" + mobileno + "', '" + userpwd + "', '" + name + "', '" + joindate + "','" + emailid + "','" + referid + "','" + userid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable nonmemberdetail(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where mobileno='" + mobile + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable affiliatememdetail(string p)
    {
        throw new NotImplementedException();
    }

    public void updatemsgstatus(string smsStatus, string mobileno)
    {
        try
        {
            string SQLQuery = "update tbl_invitefriends set msgstatus = '" + StringValidation.checkString(smsStatus) + "' where mobileno = '" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateUserInvitationsData(string sUserID, string sReferID)
    {
        try 
	    {
            string sQry = "Exec dbo.USP_UPDATE_USER_INVITATIONS_DATA '"+ sUserID + "', '"+ sReferID +"','INVITE'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
	    }
	    catch (Exception ex)
	    {
		    throw ex;
	    }
    }
    public void zUpdateUserInvitationsData(string sReferID)
    {
        try
        {
            string sQry = "Exec dbo.USP_UPDATE_USER_INVITATIONS_DATA '" + sReferID + "','INVITE'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }   

}