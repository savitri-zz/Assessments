﻿using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public class mobileRecharge
{
    private WebProxy objProxy1 = null;

    public string mobilerec(string User, string password, string Mobile_Number, string operat, string circle, string amount,string transaction)
    {
        string stringpost = null;
        stringpost = "uid=" + User + "&pwd=" + password + "&cn=" + Mobile_Number + "&op=" + operat + "&cir=" + circle + "&amt=" + amount + "&reqid=" + transaction;

        HttpWebRequest objWebRequest = null;
        HttpWebResponse objWebResponse = null;
        StreamWriter objStreamWriter = null;
        StreamReader objStreamReader = null;

        try
        {

            string stringResult = null;

            objWebRequest = (HttpWebRequest)WebRequest.Create("https://www.mobikwik.com/recharge.do");
            objWebRequest.Method = "POST";

            if ((objProxy1 != null))
            {
                objWebRequest.Proxy = objProxy1;
            }


            objWebRequest.ContentType = "application/x-www-form-urlencoded";

            objStreamWriter = new StreamWriter(objWebRequest.GetRequestStream());
            objStreamWriter.Write(stringpost);
            objStreamWriter.Flush();
            objStreamWriter.Close();

            objWebResponse = (HttpWebResponse)objWebRequest.GetResponse();
            objStreamReader = new StreamReader(objWebResponse.GetResponseStream());
            stringResult = objStreamReader.ReadToEnd();

            objStreamReader.Close();
            return stringResult;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {

            if ((objStreamWriter != null))
            {
                objStreamWriter.Close();
            }
            if ((objStreamReader != null))
            {
                objStreamReader.Close();
            }
            objWebRequest = null;
            objWebResponse = null;
            objProxy1 = null;
        }

    }

    private void StreamReader(Stream stream)
    {
        throw new NotImplementedException();
    }



    public string mobilebalance(string User, string password)
    {
        string stringpost = null;
        stringpost = "uid=" + User + "&pwd=" + password;

        HttpWebRequest objWebRequest = null;
        HttpWebResponse objWebResponse = null;
        StreamWriter objStreamWriter = null;
        StreamReader objStreamReader = null;

        try
        {

            string stringResult = null;

            objWebRequest = (HttpWebRequest)WebRequest.Create("http://www.mobikwik.com/getBalance.do");
            objWebRequest.Method = "POST";

            if ((objProxy1 != null))
            {
                objWebRequest.Proxy = objProxy1;
            }


            objWebRequest.ContentType = "application/x-www-form-urlencoded";

            objStreamWriter = new StreamWriter(objWebRequest.GetRequestStream());
            objStreamWriter.Write(stringpost);
            objStreamWriter.Flush();
            objStreamWriter.Close();

            objWebResponse = (HttpWebResponse)objWebRequest.GetResponse();
            objStreamReader = new StreamReader(objWebResponse.GetResponseStream());
            stringResult = objStreamReader.ReadToEnd();

            objStreamReader.Close();
            return stringResult;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {

            if ((objStreamWriter != null))
            {
                objStreamWriter.Close();
            }
            if ((objStreamReader != null))
            {
                objStreamReader.Close();
            }
            objWebRequest = null;
            objWebResponse = null;
            objProxy1 = null;
        }

    }

}






