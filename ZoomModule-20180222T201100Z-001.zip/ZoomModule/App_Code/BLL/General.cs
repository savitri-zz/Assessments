﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;
/// <summary>
/// Summary description for General
/// </summary>
public class General
{
    affilaitemember clsAffliate = new affilaitemember();
    home clsHome = new home();
    clsbit2byte clsB2b = new clsbit2byte();

	public General()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void SendGreetingMailToAffiliate(string sReferalID)  // referal ID means, the person who has given 20 data and becoming affiliate
    {
        DataTable dtReferalDetails = new DataTable();
        DataTable dtAffliateCount = new DataTable();
        DataTable dtRegistredUser = new DataTable();


        dtRegistredUser = clsHome.Enteridea(sReferalID);
        dtAffliateCount = clsAffliate.getAffliateCountOptin(sReferalID);
        dtReferalDetails = clsHome.GetMembersDetailsByUserID(sReferalID);

        if (dtAffliateCount.Rows.Count > 0)
        {
            int iDataGiven = int.Parse(dtAffliateCount.Rows[0]["CTR"].ToString());

            if (iDataGiven == 20)
            {

                if (dtRegistredUser.Rows.Count <= 0)
                {
                    clsHome.UpdateSqlTrace(sReferalID, "Sending Information Mail to Affiliate", "Record not found in registration table");
                }
                
                string Ref_emailid = dtReferalDetails.Rows[0]["emailid"].ToString();
                string Ref_mobileno = dtReferalDetails.Rows[0]["mobileno"].ToString();
                string Ref_name = dtReferalDetails.Rows[0]["name"].ToString();
                sendmail_toAffliate(Ref_mobileno, Ref_emailid, Ref_name, sReferalID);
            }
        }
    }

    protected void sendmail_toAffliate(string mobile, string emailid, string name, string referalID)
    {
        
        DataTable dtEmailTemplate = new DataTable();
        string Template_id = "4";
        dtEmailTemplate = clsB2b.EmailTemplateDetails(referalID, Template_id);


        if (emailid != "" && emailid != null && dtEmailTemplate.Rows.Count > 0)
        {
            SendMailFile email = new SendMailFile();
            
            string body = dtEmailTemplate.Rows[0]["Body"].ToString();
            body = body.Replace("{Name}", name);
            string email_Subject = dtEmailTemplate.Rows[0]["Email_Subject"].ToString();
            email.SendMailHTMLOutput("info@mfloat.in", emailid.ToString().Trim(), email_Subject, body.ToString());
            string sEmailSentLogTrace = "Referal ID : " + referalID + ";Mobile : " + mobile + ";User Name : " + name;
            clsHome.UpdateEmailSentLog("Congrats to become a Affliate", referalID, emailid, sEmailSentLogTrace);
        }

        SMSCAPI obj = new SMSCAPI();
        //obj.SendSMS("mfloat.in", "11124407", "91" + mobile.ToString(), "Dear " + name.ToString().Trim() + ", Thank you for became affiliate member with mfloat.in ");
        string message = "Dear " + name.ToString().Trim() + ", Congratulations on becoming affiliate member at mfloat.in";
        obj.SendSMS("mfloat.in", "11124407", "91" + mobile.ToString(), message);
    }

    public void sendWelcomeMail(string emailid, string name)
    {

        try
        {


            StringBuilder sb = new StringBuilder();
            sb.Append("Hey!" + name + ",");
            sb.AppendLine("<br>");
            sb.AppendLine(" I appreciate you showing interest in joining my user network.");
            sb.AppendLine("<br>");
            sb.AppendLine("<br>");
            sb.AppendLine("<span style='width:500px;height: auto;float: left;color:#000000;'>Now you can login by clicking the Activate button to complete your profile.  Enjoy your journey creating your personalized portal, getting local offers and much more. To know more about personalized portal click here.</span>");
            sb.AppendLine("<br>");
            sb.AppendLine("<br>");
            sb.AppendLine("For any further queries, contact us on care@mfloat.in 24x7 support");
            sb.AppendLine("<br>");
            sb.AppendLine("<br>");
            sb.AppendLine("<br>");
            sb.AppendLine("Best Regards,");
            sb.AppendLine("<br>");
            sb.AppendLine("mfloat Team");
            sb.AppendLine("<br>");
            sb.AppendLine("www.mfloat.in");
            sb.AppendLine("<br>");
            sb.AppendLine("<span style='width:500px;height: auto;float: left;margin-left:7px;margin-right: 70px;color:#525A72;font-size:11px;' >Now you are eligible to become a Free affliate member or Premium affliate member.</span>");

            if (emailid != "" && emailid != null)
            {
                SendMailFile email = new SendMailFile();
                email.SendMailHTMLOutput("info@mfloat.in", emailid.ToString().Trim(), "Welcome To mfloat.in ", sb.ToString());
                string sEmailSentLogTrace = "Name : " + name + ";Sample Content: Thank you for registering with mfloat.in as a registered user";
                clsHome.UpdateEmailSentLog("Welcome Maild", "", emailid, sEmailSentLogTrace);
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging exceptionLogObject = new ExceptionLogging();
            exceptionLogObject.LogExceptions(HttpContext.Current.Request.Url.AbsolutePath, "Error while sending the welcome mail -- " + ex.Message + "--" + (ex.StackTrace != null ? ex.StackTrace.ToString() : ""), System.Reflection.MethodBase.GetCurrentMethod().Name, HttpContext.Current.User.Identity.Name);
        }
    }



    public void invitationMailSend(string name, string userid, string email, string mobile, string ReferalID, string ImgPath, string Refname)
    {
        clsbit2byte clsEmailTemp = new clsbit2byte();
        DataTable dtemailtemp = new DataTable();
        string Template_id = "2";
        try
        {

            EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
            string sEncryptedUserID = objEncrypt.Encrypt(userid, "r0b1nr0y");
            sEncryptedUserID = sEncryptedUserID.Replace("+", "%2B");
            dtemailtemp = clsEmailTemp.EmailTemplateDetails(ReferalID, Template_id);

            string occupation = dtemailtemp.Rows[0]["OCCUPATION"].ToString();
            string city = dtemailtemp.Rows[0]["CITYNAME"].ToString();
            string activatelink = dtemailtemp.Rows[0]["LINK"].ToString();
            string EmailBody = dtemailtemp.Rows[0]["BODY"].ToString();
            string title = dtemailtemp.Rows[0]["EMAIL_SUBJECT"].ToString();
            string RefImage = ImgPath;
            if (dtemailtemp.Rows[0]["IMAGENAME"].ToString() != "")
            {
                RefImage = RefImage.Replace("{Imagename}", dtemailtemp.Rows[0]["IMAGENAME"].ToString());
            }
            else
            {
                RefImage = RefImage.Replace("{Imagename}", dtemailtemp.Rows[0]["IMAGENAME"].ToString());
            }


            MailMessage mailMessage = new MailMessage();

            StringBuilder palinBody = new StringBuilder(); 
            palinBody.Append("<html><head></head>");

           palinBody.Append("<body style='font-family: Sans-Serif;'>");
           palinBody.Append("<div id='main' style='float: left; width: 468px; height: 405px; margin-left: 95px; margin-bottom:20xp;'><div style='float: left; width: 468px; max-height:289px; border: 1px solid #999999;'>");
           palinBody.Append("<div style='background-color: rgb(240, 240, 240); height: 45px;'>");
           palinBody.Append("<div style='background-color: rgb(221, 221, 221); height: 42px;'>");
           palinBody.Append("<div style='height: 40px; padding-top: 0px; float: right; font-family: Arial; font-size: 18px; width: 75px; padding-right: 15px;'>");
           palinBody.Append("<img id='logo' src='http://www.mfloat.in/images/mflogo.png' style='height: 20px; width: 75px;'>");
           palinBody.Append("</div><div style='height: 40px; width: 453px; padding-left: 15px; font-family: Arial; font-size: 12px; margin-top: 5px; font-family: Sans-Serif; background-color: White;'>");
           palinBody.Append("<div style='width: 300px; height: 25px; float: left; font-weight: 700; font-size: 18px;'>" + title + "</div>");
           palinBody.Append("</div></div></div>");
           palinBody.Append("<div style='background-color: #f9f9f9; height: 238px;'><div style='height: 10px; width: 600px;'>");
           palinBody.Append("</div><div style='width: 450px; height: 65px; margin-left: 15px;float: left;'>");
           palinBody.Append("<div style='float: left; width: 56px; height: 63px;'>");

           StringBuilder imagebody = new StringBuilder();

            imagebody.Append("<img id='img_Refimg' src=cid:Refimg style='width: 55px; height: 55px; border: 2px; border-color: White;' /></div>");
            imagebody.Append("<div style='float: left; width: 290px; height: 63px; padding-left: 10px; padding-top: 10px;color: #8B8B8B'>");
            imagebody.Append("<span style='font-size: 13px; font-weight: bold; color: Black;'>" + Refname + "</span><br />");
            imagebody.Append("<span style='font-size: 11px;'>" + occupation + "</span><br />");
            imagebody.Append("<span style='font-size: 11px;'>" + city + "</span></div></div>");
            imagebody.Append("<div style='width: 425px; min-height: 52px; font-size: 11px; margin-left: 15px; margin-top: 24px; color: #8B8B8B; float: left;'>");
            imagebody.Append("<p style='margin:7px 0'>Dear &nbsp;" + name + ",<br />&nbsp;&nbsp;&nbsp;&nbsp;" + EmailBody);
            imagebody.Append("</div><div style='width: 100%; min-height: 20px; font-size: 11px; float: left; text-align: center; color: #8B8B8B'>");
            imagebody.Append("<p style='margin:10px 0'>For more details please activate</p></div>");
            imagebody.Append("<div style='width: 100%; text-align: center; margin: 6px auto; float:left'>");
            imagebody.Append("<a href='" + activatelink + userid + "' style='text-decoration:none;color: white;padding: 7px;font-weight: bold;font-size: 15px;margin-top: 0px;background-color: #0099cc;border-radius: 5px;'>Activate My Account</a>");
            imagebody.Append("</div></div></div><div style='width: 460px; padding: 0px; color: #393939; font-size: 10px; float: left; text-align: center;'><p>");
            imagebody.Append("This message was sent to <span>" + email + "</span> because " + Refname + "<br />added you as close friend in mfloat.in</p>");
            imagebody.Append("</div>");

            imagebody.Append("<div style='width: 460px; height: 22px; background: #e6e6e7; padding: 3px; color: #393939;font-size: 10px; float: left; text-align: center; border: 1px solid #e8e8e8'>");
            imagebody.Append("<p style='margin-bottom: 0px; margin-top: 0px'>If you don't want to receive these emails from <a href='http://www.mfloat.in' target='_blank'>mfloat.in</a> in future, please <a href='http://www.mfloat.in/Default.aspx?act=unsubscribe&status=" + sEncryptedUserID + "'");
            imagebody.Append("style='text-decoration: blink; font-weight: bold; font-size: 11px;' target='_blank'>unsubscribe</a>.</p>");
            imagebody.Append("</div><div style=width: 468px; height: 20px;'><span style='float: right; font-size: 11px; color: #939392; margin-top: 2px; margin-right: 0px; color: Black;'>Float Technologies Pvt. Ltd., Hyderabad</span></div>");
            imagebody.Append("</div></body></html>");

            System.Net.Mail.AlternateView htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(palinBody.ToString() + imagebody, null, "text/html");
            System.Net.Mail.AlternateView plainView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(palinBody.ToString(), null, "text/plain");
            System.Net.Mail.LinkedResource AddpostImage = new System.Net.Mail.LinkedResource(RefImage, "image/jpg");
            AddpostImage.ContentId = "Refimg";
            AddpostImage.TransferEncoding = TransferEncoding.Base64;
            htmlView.LinkedResources.Add(AddpostImage);
            mailMessage.AlternateViews.Add(plainView);
            mailMessage.AlternateViews.Add(htmlView);

            SendMailFile objMail = new SendMailFile();
            objMail.SendMailHTMLOutput("info@mfloat.in", email.ToString().Trim(), "Message From " + Refname, mailMessage);

            home clsHome = new home();
           string sEmailSentLogTrace = "Referal ID : " + ReferalID + ";Referal Name : " + Refname + ";Referal Occupation : " + occupation + ";Referal City : " + city;
            sEmailSentLogTrace = sEmailSentLogTrace + ";User Name : " + name + ";Activation Link : " + activatelink;

            clsHome.UpdateEmailSentLog("Invitation Mail - Resend", userid, email, sEmailSentLogTrace);
            mailMessage.Dispose();
        }
        catch (Exception ex)
        {
            ExceptionLogging exceptionLogObject = new ExceptionLogging();
            exceptionLogObject.LogExceptions(HttpContext.Current.Request.Url.AbsolutePath, "Error while sending the Resend Invitation mail -- " + ex.Message + "--" + (ex.StackTrace != null ? ex.StackTrace.ToString() : ""), System.Reflection.MethodBase.GetCurrentMethod().Name, HttpContext.Current.User.Identity.Name);
            clsHome.UpdateMailNotSentStatus(userid);
        }

    }

    public DateTime dtServerDateTime()
    {
        DateTime SrvDate = DateTime.Now;
        DataTable dtSvrDate = new DataTable();
        userDetails clsUserDtls = new userDetails();
        dtSvrDate = clsUserDtls.GetServerDatetime();

        if (dtSvrDate.Rows.Count > 0)
        {
            SrvDate = Convert.ToDateTime(dtSvrDate.Rows[0]["ServerDate"].ToString());
        }
        return SrvDate;
    }

    public string generateUserID()
    {
        /*
        string retnValue = "";
        uniquenumber newuniqu = new uniquenumber();
        retnValue = newuniqu.digspin16();
        home clsHome = new home();
        DataTable dtUserDetails=new DataTable();
        //dtUserDetails = clsHome.getMemberDetailsFromInvitation(retnValue);
        dtUserDetails = clsHome.GetMembersDetailsByUserID(retnValue);
        if (dtUserDetails.Rows.Count > 0)
        {
            this.generateUserID(); 
        }

        return retnValue;
        */


        try
        {

            Random sRandom = new Random();
            string retnValue = "";
            BaseClass bc = new BaseClass();

            string sQry = "EXEC DBO.USP_GENERATE_RANDOM_USERID '" + sRandom.Next(10000, 99999) + "'";
            DataTable dt = bc.GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                retnValue = dt.Rows[0]["RANDOM_NUMBER"].ToString();
            }
            else
            {
                uniquenumber newuniqu = new uniquenumber();
                retnValue = newuniqu.digspin16();
            }

            home clsHome = new home();
            DataTable dtUserDetails = new DataTable();
            dtUserDetails = clsHome.GetMembersDetailsByUserID(retnValue);
            if (dtUserDetails.Rows.Count > 0)
            {
                return this.generateUserID();
            }
            return retnValue;

        }
        catch (Exception ex)
        {
            ExceptionLogging exceptionLogObject = new ExceptionLogging();
            exceptionLogObject.LogExceptions(HttpContext.Current.Request.Url.AbsolutePath, "Error while generating the userid -- " + ex.Message + "--" + (ex.StackTrace != null ? ex.StackTrace.ToString() : ""), System.Reflection.MethodBase.GetCurrentMethod().Name, HttpContext.Current.User.Identity.Name);
            return this.generateUserID();

        }


    }

    public bool IsValidEmail(string email)
    {
        try
        {
            return Regex.IsMatch(email,"^([a-zA-Z0-9_.-])+\\@(([a-zA-Z0-9-])+\\.)+([a-zA-Z0-9]{2,4})+$");
        }
        catch
        {
            return false;
        }
    }


  

    public bool IsValidMobileNo(string sMobileNo)
    {
        try
        {

           ///////// modified by Uday - Purpose : to check is every char is numaric or not  ///////



            foreach (Char ch in sMobileNo)
            {
                if (!Char.IsDigit(ch))
                {
                    return false;

                }
            
            }
          

            if (sMobileNo.Trim().Length != 10)
            {
                return false;
            }
            
            string sFirstChar = sMobileNo.Trim().Substring(0,1);
            
            if( sFirstChar != "7" && sFirstChar != "8"  && sFirstChar != "9" )
            {
                return false;
            }

            return true;

        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public class Accounts_Manager
    {
        private string emailID;
        private string mobileNo;
        private string companyOrOrganisation;
        private string link;
        private string description;

        public string Email_ID
        {
            get { return emailID; }
            set { emailID = value; }
        }
        public string Mobile_No
        {
            get { return mobileNo; }
            set { mobileNo = value; }
        }
        public string CompanyOrOrganisation
        {
            get { return companyOrOrganisation; }
            set { companyOrOrganisation = value; }
        }
        public string Link
        {
            get { return link; }
            set { link = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
    }

    public class Affiliates_Manager
    {
        private string emailID;
        private string mobileNo;
        private string name;
        private string link;
        private string description;

        public string Email_ID
        {
            get { return emailID; }
            set { emailID = value; }
        }

        public string Mobile_No
        {
            get { return mobileNo; }
            set { mobileNo = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
    }

    public void UpdateUserInvitationLuckDraw(string sUserID)
    {
        DataTable dtLuckyDraw = new DataTable();
        dtLuckyDraw = clsHome.GetActiveLuckyDrawDetails();
        if (dtLuckyDraw.Rows.Count > 0)
        {
            string sDrawID = dtLuckyDraw.Rows[0]["DRAW_ID"].ToString();
            clsHome.UpdateLuckyDrawDetails(sDrawID, sUserID);
        }
    }

}