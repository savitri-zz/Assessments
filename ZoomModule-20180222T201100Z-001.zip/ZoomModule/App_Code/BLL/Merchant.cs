﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ScreenPermision
/// </summary>
public class Merchant : BaseClass
{
    public Merchant()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public DataSet InsertMerchant(EntMerchant entR)
    {

        DataSet ds = new DataSet();
        try
        {

            string SQLQuery = string.Format("SELECT COUNT(*) FROM S_Tbl_Merchant WHERE MerchantName= '" + entR.MerchantName + "'");


            int noOfUsers = fnExecuteScalar(SQLQuery, true);
            if (noOfUsers < 1)
            {
                SQLQuery = "INSERT INTO S_Tbl_Merchant(MerchantName,MerchantID,MerchantDesc,StatusID,MerchantUrl)VALUES('" + entR.MerchantName + "',(select max(MerchantID)+1 from S_Tbl_Merchant as MerchantID),'" + entR.MerchantDesc + "','" + entR.StatusID + "','" + entR.MerchantUrl + "')";
                 int intRowAffect = fnExecuteNonQuery(SQLQuery, true);      

            }
            return ds = GetCategories();
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
    public DataSet GetCategories()
    {
        try
        {
            string SQLQuery = "SELECT *  FROM S_Tbl_Merchant order by MerchantName";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet UpdatetMerchant(EntMerchant entR)
    {
        try
        {
            string SQLQuery = "UPDATE S_Tbl_Merchant SET MerchantName ='" + entR.MerchantName + "',MerchantID = '" + entR.MerchantID + "',MerchantDesc='" + entR.MerchantDesc + "',StatusID='" + entR.StatusID + "',MerchantUrl='" + entR.MerchantUrl + "' WHERE MerchantName= '" + entR.MerchantName + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            DataSet ds = new DataSet();
            return ds = GetCategories();
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}