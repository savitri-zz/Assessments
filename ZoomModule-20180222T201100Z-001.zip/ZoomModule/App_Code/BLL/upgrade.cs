﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for upgrade
/// </summary>
public class upgrade : BaseClass
{
	public upgrade()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable paidinfo(string upgrade)
    {

        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + upgrade + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable freeinfo(string upgrade)
    {

        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid='" + upgrade + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlcities(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_cities where stateid =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable upgradepakg(string mobileno)
    {
        try
        {
            string SQLQuery = "Select * from tbl_registration where  mobileno='" + mobileno + "' and upgrade='U'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void inserupgrade(string upgrade, string userid)
    {
        try
        {
            string SQLQuery = "update tbl_registration set upgrade='" + upgrade + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetProductsDetails(string sno)
    {
        try
        {
            string SQLQuery = "select sno,Code,Product_name,QTY,cost,tax,total,ROUND(mrp,0) as mrp from tbl_Products where sno = '" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void upgradepaiduser(string productype, string inipakg, string userid, string transid, string update)
    {
        try
        {

          /*  string SQLQuery = "update tbl_registration set producttype='" + productype + "', initpakg='" + inipakg + "',TransactionId='" + transid + "',upgradedate='" + update + "',upgrade='U' where userid='" + userid + "'"; */

            string SQLQuery = "USP_Bite2Byte_upgradepaiduser   '" + productype + "','" + inipakg + "','" + userid + "','" + transid + "','" + update+"'";


            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetoldPackages(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_updatereg where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void inserupprvs( string userid, string package, string transactionid)
    {
        try
        {

          /*  string SQLQuery = "insert into tbl_updatereg (userid,package,transactionid,date) values ('" + userid + "','" + package + "','" + transactionid + "','" + DateTime.Now.ToString() + "')";  */
            string SQLQuery = "USP_Bite2Byte_inserupprvs    '" + userid + "','" + package + "','" + transactionid + "','" + DateTime.Now.ToString() + "'"; 

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpopupstatus(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_popupdate where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void inserpopuplogindate(string userid, string logindate)
    {
        try
        {
            string SQLQuery = "insert into tbl_popupdate(userid,firstlogindate) values ('" + userid + "','" + logindate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatepopuplogindate(string userid, string logindate)
    {
        try
        {
            string SQLQuery = "update tbl_popupdate set firstlogindate ='" + logindate + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}