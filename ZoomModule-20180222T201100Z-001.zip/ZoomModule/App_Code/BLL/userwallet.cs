﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for userwallet
/// </summary>
public class userwallet:BaseClass
{
    public userwallet()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable getverifycode(string userid)
    {
        try
        {
            string sql = "Select * from tbl_userwallet where userid='" + userid + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable getpassword(string mobile)
    {
        try
        {
            string sql = "Select * from tbl_userwallet where mboile='" + mobile + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public void insertuserwallet(string name, string mobile, string emailid, string userid,string usertype, string status, string verifycode)
    {
        try
        {
            string sql = "insert into tbl_userwallet(name,mboile,emailid,userid,usertype,status,verifycode,date) values ('" + name + "','" + mobile + "','" + emailid + "','" + userid + "','" + usertype + "','" + status + "','" + verifycode + "','" + DateTime.Now.ToString() + "')";
            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
                 
        }

    }

    public void updateuserwallet(string password, string mobile,string userid)
    {
        try
        {
            string sql = "update tbl_userwallet set password='" + password + "' where mboile='" + mobile + "' and userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;

        }

    }
    public void updateregwallet(string mobile, string userid)
    {
        try
        {
            string sql = "update dbo.tbl_registration  set firstlog=1 where  mobileno='" + mobile + "' and userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;

        }

    }



    public DataTable selectpassword(string password,string userid, string mobile)
    {
        try
        {
            string sql = "Select * from tbl_userwallet where password='" + password + "' and mboile='" + mobile + "' and userid='" + userid + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public void insertresendcount(string userid, string mobile, string emailid, string userpassword, string name)
    {
        try
        {
            string sql = "insert into tbl_resendpwdcount(userid,mobile,emailid,userpassword,name) values ('" + userid + "','" + mobile + "','" + emailid + "','" + userpassword + "','" + name + "')";
            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;

        }

    }

    public string verificationcode(int verify)
    {
        string str = "0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9";
        string[] varray = str.Split(',');
        string codevrify = "";
        int tem = -1;
        Random ran = new Random();
        for (int i = 0; i < verify; i++)
        {
            if (tem != -1)
            {
                ran = new Random(i * tem * ((int)DateTime.Now.Ticks));
            }
            int t = ran.Next(20);
            if (tem != -1 && tem == t)
            {
                return verificationcode(verify);

            }
            tem = t;
            codevrify += varray[t];

        }
        return codevrify;


    }


    public DataTable selectverify(string verifycode, string userid, string mobileno)
    {
        try
        {
            string sql = "Select * from tbl_userwallet where verifycode='" + verifycode + "' and mboile='" + mobileno + "' and userid='" + userid + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
      
    }

    public void updateverify(string verifycode, string mobile, string userid)
    {
        try
        {
            string sql = "update tbl_userwallet set status='1' where mboile='" + mobile + "' and userid='" + userid + "' and verifycode='" + verifycode + "'";
            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;

        }

    }

    public DataTable selectbinary(string userid)
    {
        try
        {
            string sql = "Select   sum(cast(PW as int)) as PW,sum(cast(PayabeAmt as int)) as PayabeAmt from tbl_Binarypayoutdetails where userid='" + userid + "' ";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable referral(string userid)
    {
        try
        {
            string sql = "Select sum(cast(PW as int)) as PW,sum(cast(Balance as int)) as Balance from tbl_Referalpayoutdetails where userid='" + userid + "' ";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }


        
    }

    public DataTable datawallet(string userid)
    {
        try
        {
            string sql = "Select * from tbl_Datapayoutdetails  where userid='" + userid + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }



    }


    public void insertuserwalletststus(string mobile, string userid, string deelername, string deelermobile, string walletsttus,string activdate)
    {
        try
        {

           /* string sql = "insert into tbl_Userwalletstatus(mobileno,useid,Delearname,Delearmobile,walletstatus,Activatedate) values ('" + mobile + "','" + userid + "','" + deelername + "','" + deelermobile + "','" + walletsttus + "','" + activdate + "')";*/

            string sql = "USP_Bite2Byte_insertuserwalletststus '" + mobile + "','" + userid + "','" + deelername + "','" + deelermobile + "','" + walletsttus + "','" + activdate + "'";

            int intRowAffect = fnExecuteNonQuery(sql, true);
        }
        catch (Exception Ex)
        {
            throw Ex;

        }

    }
 public DataTable getstatus(string mobileno)
    {
        try
        {
            string sql = "Select * from tbl_Userwalletstatus  where mobileno='" + mobileno + "'";
            return GetDataTable(sql, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }



    }

 
// This function is written by Sudhindra on 01-July-2014. Purpose : At the time of login , to check whether he is Free affiliated member with Paid-Deactive state.  
 public DataTable CheckAsPaidDeactive(string MobileNo)
 {
     try
     {
         string sql = "SELECT * FROM TBL_FREEMEMREG where mobileno='" + MobileNo + "' AND UPGRADED_PAID_DEACTIVE = 1";
         return GetDataTable(sql, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }

 }



public DataTable getstatususerid(string refid)
 {
     try
     {
         string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
         SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
         SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
         SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and tbl_registration.referid='" + refid + "' ";
         return GetDataTable(SQLQuery, true);
     }
     catch (Exception EX)
     {
         throw EX;
     }



 }

 public DataTable getstatuswallet(string mobileno)
 {
     try
     {
         string sql = "Select * from tbl_Userwalletstatus  where useid='" + mobileno + "'";
         return GetDataTable(sql, true);
     }
     catch (Exception EX)
     {
         throw EX;
     }



 }

 public void InsertUserGiftAmount(string sUserID, string GiftDate, int dGiftAmount, int iNoOfPayments, decimal dAmountPerMonth, string sPurpose, out int intRowAffect)
 {
     try
     {
        // string sGiftDate_ymd = string.Format("{0:yyyy-MM-dd}", GiftDate);
         string sQry = "INSERT INTO TBL_USER_GIFT_AMOUNT (USER_ID, GIFT_GIVEN_DATE, TOTAL_AMOUNT, NO_OF_PAYMENTS, AMOUNT_PER_MONTH, PURPOSE) ";
         sQry = sQry + " VALUES ('" + sUserID + "', '" + GiftDate + "', " + dGiftAmount.ToString() + ", " + iNoOfPayments.ToString() + ", " + dAmountPerMonth.ToString() + ",'" + sPurpose + "')";

        intRowAffect = fnExecuteNonQuery(sQry, true);
     }
     catch (Exception ex)
     {
         
         throw ex;
     }
 }

 public void updateGiftTransactions(string sUserID, string GiftDate)
 {
     try
     {
         //string sGiftDate_ymd = string.Format("{0:yyyy-MM-dd}", GiftDate);
         string sQry = "Exec dbo.USP_UPDATE_GIFT_AMOUNT_TRANSACTIONS '" + sUserID + "', '" + GiftDate + "'";
         fnExecuteNonQuery(sQry, true);
     } 
     catch (Exception ex)
     {
         
         throw ex;
     }
 }
    //  Added By Ganga Purpose: Retreiving Wallet Summary Date:30-01-2015
 public DataSet getWalletDataSummary()
 {
     try
     {
         string sqlQry = "";
         sqlQry += "select r.userid, r.mobileno, r.fullname, sum(cast(replace(replace(creditedamount , '.00', ''), '.0','') as int)) - sum(cast(replace(replace(debitedamt , '.00',''),'.0','') as int)) balance from tbl_registration r";
         sqlQry += " left outer join tbl_walletalltransactionproductwallet w on w.userid = r.userid";
         sqlQry += " group by r.userid, r.mobileno, r.fullname order by r.userid";
             return GetDataSet(sqlQry, true);
         
     }
     catch (Exception EX)
     {
         throw EX;
     }
     
 }
 //  Added By Ganga Purpose: Retreiving Wallet Details Date:30-01-2015
 public DataSet getWalletDataDetails()
 {
     try
     {
             string sqlQry = "select r.userid, r.mobileno, r.fullname, w.creditedamount, w.debitedamt, w.date, w.status from tbl_registration r";
             sqlQry += " left outer join tbl_walletalltransactionproductwallet w on w.userid = r.userid";
             sqlQry += " order by r.userid, w.date";
             return GetDataSet(sqlQry, true);
         
     }
     catch (Exception EX)
     {
         throw EX;
     }

 }

}