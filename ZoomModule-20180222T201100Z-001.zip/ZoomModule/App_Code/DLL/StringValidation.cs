using System;
using System.Security.Cryptography;
using System.Text;


	public class StringValidation
	{
		public StringValidation()
		{
			
		}
		public static string checkStringOrigFormat(string input)
		{
			string text1=input.Trim();
			if (input!=null)
			{
				input=input.Trim();
			}
			if (input==null || input.Equals(""))
			{
				return "";
			}
			text1 = text1.Replace("'", "''");
			text1 = text1.Replace("&quot;", "\"");
			text1 = text1.Replace("&#39;", "''");
			text1 = text1.Replace("&lt;", "<");
			text1=text1.Replace("&gt;", ">");
				return  text1;

		}
		public static string checkString(object input)
		{
			if (input==null)
			{
				return "";
			}
			else
			{
				string text1=input.ToString();
				text1 = text1.Replace("''", "'");
				text1 = text1.Replace("\"", "&quot;");
				text1 = text1.Replace("''", "&#39;");
				text1 = text1.Replace("<", "&lt;");
				text1=text1.Replace(">", "&gt;");
				return  text1;
			}
			
		}
		public static string Encrypt(string input)
		{
			SHA1Managed Sham=new SHA1Managed();
			Convert.ToBase64String(Sham.ComputeHash(Encoding.ASCII.GetBytes(input)));
			byte[] eNC_Data=ASCIIEncoding.ASCII.GetBytes(input);
			string eNC_Str=Convert.ToBase64String(eNC_Data);
			return eNC_Str;
		}

		public static string Decrypt(string input)
		{
			byte[] eNC_Data=Convert.FromBase64String(input);
			string dEC_Str=ASCIIEncoding.ASCII.GetString(eNC_Data);
			return dEC_Str;

		}
	}

