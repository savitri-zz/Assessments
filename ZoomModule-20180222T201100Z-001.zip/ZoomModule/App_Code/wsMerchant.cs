﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.ServiceModel.Web;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for wsMerchat
/// </summary>

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class wsMerchant : System.Web.Services.WebService {


    [WebMethod]
    public string Mail(string mailid, string name, string btn, string sub, string key, string pwd)
    {

        string result = "";
        result = "Email successfully sent.";
        return result;
    }
              
    [WebMethod]
    //[ScriptMethod(UseHttpGet = true)]
    //[WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]
    public string Insert(string name1, string des1, string title1, string url1, string logo1,string mobile1, string email1, string password1 )
    {
        EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
        
        try
        {
            BaseClass BS = new BaseClass();
            string SQLQuery = " IF NOT EXISTS (SELECT MNAME FROM TBL_MRCHNT WHERE MNAME = '" + name1 + "') INSERT INTO TBL_MRCHNT (MNAME,MERCHANT_DETAILS,MERCHANT_DESCRIPTION,MRCHANT_URL,MRCHANT_LOGO,MOBILENO,EMAIL_ID,MERCHAT_PASSWORD) VALUES ('" + name1 + "','" + title1 + "','" + des1 + "','" + url1 + "','" + logo1 + "','" + mobile1 + "','" + email1 + "','" + objEncrypt.Encrypt(password1, "r0b1nr0y").ToString() +"')";
            SQLQuery = SQLQuery + "ELSE UPDATE TBL_MRCHNT SET MERCHANT_DETAILS='" + title1 + "' ,MERCHANT_DESCRIPTION='" + des1 + "' ,MRCHANT_URL='" + url1 + "' ,MRCHANT_LOGO='" + logo1 + "', MOBILENO='" + mobile1 + "', EMAIL_ID='" + email1 + "', MERCHAT_PASSWORD='" + objEncrypt.Encrypt(password1, "r0b1nr0y").ToString() + "' WHERE MNAME='" + name1 + "' ";
            int intRowAffect = BS.fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        return "SUCCESS";
    }

    public wsMerchant()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

     [WebMethod]
    public string generateButtonId(string mname)
    {
        mname = "quickpay";
        try
        {
            string s="";
            BaseClass BS = new BaseClass();
            string commandNAME = "DECLARE @btn_Code varchar(30),@PK_Uid varchar(30),@PK_Pwd varchar(30) ";
            commandNAME = commandNAME + "  EXEC USP_GENERATE_RANDOM_TRANSACTION_ID  '25', @btn_Code OUTPUT ";
            commandNAME = commandNAME + "  EXEC USP_GENERATE_RANDOM_TRANSACTION_ID  '25', @PK_Uid OUTPUT ";
            commandNAME = commandNAME + "  EXEC USP_GENERATE_RANDOM_TRANSACTION_ID  '25', @PK_Pwd OUTPUT ";
         //   commandNAME = commandNAME + " SELECT @btn_Code, @PK_Uid, @PK_Pwd ";
            commandNAME = commandNAME + " SELECT @btn_Code +'#'+ @PK_Uid  +'#'+  @PK_Pwd ";
            s = BS.GetSingleValue(commandNAME, true);

            string[] result = s.Split('#');
            //SqlDataReader dr ;//= new SqlDataReader();
            //dr = BS.fnExecuteReader(commandNAME, true);

            EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
            WalletCredentials response = new WalletCredentials
            {
                BTNID = objEncrypt.Encrypt(result[0].ToString(), "r0b1nr0y"),
                APIKEY = objEncrypt.Encrypt(result[1].ToString(), "r0b1nr0y"),
                APIPWD = objEncrypt.Encrypt(result[2].ToString(), "r0b1nr0y")
            };

            string SQLQuery = " IF NOT EXISTS (SELECT BUTTON_ID,API_WALLET_KEY, API_WALLET_PASSWORD FROM TBL_MRCHNT WHERE MNAME= '" + mname + "' AND BUTTON_ID = '" + result[0].ToString() + "' AND API_WALLET_KEY='" + result[1].ToString() + "' AND API_WALLET_PASSWORD='" + result[2].ToString() + "') UPDATE TBL_MRCHNT SET BUTTON_ID= '" + result[0].ToString() + "', BUTTON_STATUS =1 ,API_WALLET_KEY='" + result[1].ToString() + "', API_WALLET_PASSWORD = '" + result[2].ToString() + "', API_WALLET_KEY_STATUS = 1   WHERE MNAME= '" + mname + "'";
            int intRowAffect = BS.fnExecuteNonQuery(SQLQuery, true);

                string outputJson = string.Empty;
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);
                return outputJson;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
       
        
        
    }

     public class WalletCredentials
     {
         public string BTNID { get; set; }
         public string APIKEY { get; set; }
         public string APIPWD { get; set; }
     }
}
